# Aster Deck — Independent implementation rules (v1.0.0 RC1)

## 클린룸
- Microsoft PowerPoint 또는 타사 프레젠테이션 편집기의 비공개 코드, 디컴파일 결과, 복사된 디자인 리소스를 사용하지 않는다.
- ECMA-376/ISO/IEC 29500 공개 문서와 공식 사용 설명서, 테스트 목적으로 직접 생성·검사한 PPTX 구조만 참고한다.
- 범용 파일·이미지·테스트 라이브러리는 사용 가능하며, 기존 프레젠테이션 편집기 로직은 복사하지 않는다.

## 모듈
- `src/core.js` 모델·히스토리·명령 기반 업데이트
- `src/app.js` UI와 명령·단축키 디스패치
- `src/pptx.js` 자체 OOXML 직렬화·가져오기·유효성 검사
- `src/preserve.js` 외부 PPTX 파트 보존 조건 검사 및 제한적 원본 XML 부분 수정
- `src/text-layout.js` 글꼴 px/pt/EMU 변환 및 텍스트 박스 설정
- `src/diagnostics.js` 디자인·호환 위험 정적 검사
- `src/studios.js` 독립 디자인 테마·글꼴 집계/교체·데이터 필터·문서 버전 비교, UI는 `app.js`를 통해 단일 명령 레지스트리에 연결
- `src/native-chart.js`, `src/chart-data.js` 차트·CSV/XLSX 데이터
- `src/pptx-motion.js`, `src/timeline.js` 애니메이션
- `src/arrange.js`, `src/smart-layout.js` 도형 그룹·커넥터/정렬
- `src/zip.js` OPC ZIP 읽기/쓰기
- `build.py` 단일 HTML 번들 생성 (동일 내용을 루트/`dist/`에 출력)

## 빌드·테스트
- `npm test` 단위 테스트
- `python tests/studios_v093_browser.py` 신규 0.9.x 기능 브라우저 검사
- `python build.py` 단일 HTML 실행본 생성
- `python tests/compat_v083_browser.py` / `compat_v083_external.py` 보존/그룹/마스터 브라우저 호환 검사
- 다른 `tests/*browser*.py`는 기존 회귀 검증

## 완료의 정의
- 기능별 SPEC 완료 기준을 실제 검증하고 기존 기능 회귀 검사도 수행한다.
- 파일 보존 범위와 미지원 기능을 `docs/GAPS.md`에 명시한다.
- 원본을 손실시키는 재생성 경로는 자동으로 진입하지 않는다.
- 모든 편집은 가능한 범위에서 실행 취소·다시 실행을 지원하고 한국어 IME를 손상시키지 않는다.
- 배포 ZIP에 `samples` 및 임시 검증 결과물을 포함하지 않는다.

## v0.9.4~v0.9.6 개발 규칙 추가
- `src/workspace.js`: UI 환경설정/수동 복구 기록/축소판 창 계산/명령 검색 등 프레젠테이션 모델과 분리된 유틸리티. 모든 저장소 접근 예외를 처리할 것.
- `src/core.js` Store 히스토리: 최대 100단계 및 대략 24MiB 예산을 유지. 단일 큰 Undo 상태 최소 1건은 보존.
- `src/app.js`: 편집 변경은 공통 Store 명령을 이용. 복구용 로컬 저장은 앱 시작 시 **자동 불러오기 금지**; 사용자가 명시적으로 선택하도록 할 것. 파일 교체 전 미저장 작업 경고 유지.
- `index.template.html`, `src/style.css`, `src/app.js` 수정 후 `python build.py`를 실행해 두 독립 HTML이 일치하는지 검사.
- 테스트: `node --test tests/*.test.mjs`; Chromium 조작은 `python tests/workspace_v096_browser.py` 등. 실행 환경 `file://` 접근 차단 가능성을 기록하고 실제 더블클릭 검증 완료를 주장하지 않는다.
- 검증 샘플은 임시 생성·폐기. **배포 ZIP에 `samples/` 디렉터리, 데모 PPTX, 임시 이미지 추가 금지.**

## v1.0.0 RC1 릴리스 원칙
- `src/zip.js`는 ZIP 입력 CRC32, 중앙/로컬 헤더 일치, 경로 유효성, 압축 해제 크기 예산을 검증한다. 새 형식 지원 시 거부 기준을 약화하지 않고 테스트를 먼저 추가한다.
- `src/workspace.js` 복구 기록은 타임스탬프 충돌 시에도 이전 항목을 덮어쓰지 않도록 보장한다.
- `tests/release_rc1.test.mjs`, `tests/release_rc1_browser.py`로 파일 손상/기본 조작/기존 파일 검사 회귀를 유지한다.
- 실제 Windows/Mac PowerPoint/`file://` 직접 실행을 검증하지 않은 상태에서 RC1을 정식 1.0으로 홍보하지 않는다.
- 배포 ZIP에는 `samples/`, 테스트용 다운로드 결과, PNG 스크린샷을 넣지 않는다.


## Current RC2 UI rules
- v1.0.0 RC2: text click edits, narrow border drags move, selected text opens Quick Format.
- Formatting controls use `textFormat` and Store for undo; never rebuild fonts/formatting from external code.
- `samples/` stays excluded. Tests synthesize any presentation inputs on demand.
