"""Run locally: python tests/motion_v073_browser.py; no distributed fixtures."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from pptx import Presentation
import io, zipfile, xml.etree.ElementTree as ET, subprocess, tempfile, shutil
ROOT=Path(__file__).resolve().parents[1]
checks=0

def check(label, condition):
 global checks
 assert condition,label
 checks+=1;print('PASS',label,flush=True)

with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1660,'height':1000},accept_downloads=True)
 errs=[];page.on('pageerror',lambda exc:errs.append(str(exc)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 check('version label',page.locator('.version').inner_text()=='v1.0.0 RC3')
 page.locator('[data-tab="animations"]').click()
 check('timeline visible',page.locator('#timelinePanel').is_visible())
 page.locator('#stage .element.text').first.click(force=True)
 page.locator('[data-command="anim.fade"]').first.click()
 check('first animation created',page.locator('.timeline-track').count()==1)
 page.locator('[data-command="anim.path"]').first.click()
 check('second animation created',page.locator('.timeline-track').count()==2)
 check('path editor overlay visible',page.locator('#motionPathLayer [data-path-handle="end"]').count()==1)
 page.locator('[data-timeline-prop="pathType"]').select_option('curve')
 check('curve handle is visible',page.locator('[data-path-handle="curve"]').count()==1)
 before=page.evaluate('store.deck.slides[0].timeline[1].pathDx')
 handle=page.locator('[data-path-handle="end"]')
 bbox=handle.bounding_box()
 page.mouse.move(bbox['x']+bbox['width']/2,bbox['y']+bbox['height']/2)
 page.mouse.down();page.mouse.move(bbox['x']+90,bbox['y']+24,steps=7);page.mouse.up()
 after=page.evaluate('store.deck.slides[0].timeline[1].pathDx')
 check('path endpoint drag updates stored model',after!=before)
 page.locator('[data-command="edit.undo"]').first.click()
 check('undo restores path',page.evaluate('store.deck.slides[0].timeline[1].pathDx')==before)
 page.locator('.timeline-track').last.click()
 page.locator('[data-command="anim.reversePath"]').first.click()
 check('reverse path flips direction',page.evaluate('store.deck.slides[0].timeline[1].pathDx')==-before)
 page.locator('.timeline-track').first.click()
 page.locator('.timeline-track').last.click(modifiers=['Control'])
 check('control multiselect tracks',page.evaluate('motionSelectedIds.size')==2)
 page.locator('[data-command="anim.copy"]').first.click()
 check('multi clip copy',page.evaluate('motionClipboard.length')==2)
 page.locator('[data-command="anim.paste"]').first.click()
 check('multi paste duplicates effects',page.locator('.timeline-track').count()==4)
 page.locator('[data-command="anim.delete"]').first.click()
 check('multi delete removes copied effects',page.locator('.timeline-track').count()==2)
 page.locator('.timeline-track').first.click()
 bar=page.locator('.timeline-track').first.locator('.timeline-bar-resize')
 bar.scroll_into_view_if_needed()
 rect=bar.bounding_box();old_duration=page.evaluate('store.deck.slides[0].timeline[0].duration')
 page.mouse.move(rect['x']+rect['width']/2,rect['y']+rect['height']/2)
 page.mouse.down();page.mouse.move(rect['x']+rect['width']/2+70,rect['y']+rect['height']/2,steps=7);page.mouse.up()
 check('dragging timeline bar changes duration',page.evaluate('store.deck.slides[0].timeline[0].duration')!=old_duration)
 page.locator('[data-command="timeline.zoomIn"]').first.click()
 check('timeline zoom changes',page.evaluate('timelineZoom')>1)
 page.locator('#timelineScrub').fill('0.3')
 check('scrub position changes',abs(page.evaluate('timelineCursor')-.3)<.001)
 page.locator('.timeline-track').first.click()
 page.locator('[data-timeline-prop="trigger"]').select_option('click')
 page.locator('[data-command="anim.preview"]').first.click()
 check('slideshow opens',page.locator('#slideShow').is_visible())
 page.locator('[data-command="show.next"]').click()
 check('click advances motion',page.locator('#showCue').inner_text().startswith('클릭 1'))
 page.locator('[data-command="show.end"]').click()
 with page.expect_download(timeout=30000) as download:page.locator('[data-command="file.exportPptx"]').first.click()
 raw=download.value.path().read_bytes()
 with zipfile.ZipFile(io.BytesIO(raw)) as zipfile_obj:
  xml=zipfile_obj.read('ppt/slides/slide1.xml');root=ET.fromstring(xml)
  check('native animation timing exists',len(root.findall('.//{*}timing'))==1)
  check('PowerPoint animation shape targets exist',len(root.findall('.//{*}spTgt'))>=2)
  check('PowerPoint slide contains multiple animation effects',len(root.findall('.//{*}animEffect'))>=1 and len(root.findall('.//{*}animMotion'))>=1)
  check('regular export omits proprietary snapshot',not any(n.startswith('customXml/') for n in zipfile_obj.namelist()))
 check('independent PPTX parser reads exported deck',len(Presentation(io.BytesIO(raw)).slides)==5)
 page.locator('#openFile').set_input_files({'name':'roundtrip.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':raw})
 check('import restores native animation steps from standard PPTX',len(page.evaluate('store.deck.slides[0].timeline'))>=2)
 check('no page errors',not errs)
 b.close()
 # External rendering is a weaker compatibility signal than Microsoft PowerPoint.
 if shutil.which('libreoffice'):
  with tempfile.TemporaryDirectory(prefix='aster_motion_') as td:
   source=Path(td)/'exported.pptx';source.write_bytes(raw)
   done=subprocess.run(['libreoffice','-env:UserInstallation=file:///tmp/aster_motion_lo_07','--headless','--convert-to','pdf','--outdir',td,str(source)],capture_output=True,text=True,timeout=75)
   check('LibreOffice opens exported animation PPTX',done.returncode==0 and (Path(td)/'exported.pdf').exists())
print('TOTAL BROWSER/COMPAT CHECKS',checks)
