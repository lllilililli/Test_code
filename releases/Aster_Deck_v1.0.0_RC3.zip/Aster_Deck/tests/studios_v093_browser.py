"""Aster Deck 0.9.x browser integration tests. All fixtures in memory; no samples folder."""
from pathlib import Path
import json,io,zipfile
from playwright.sync_api import sync_playwright
from pptx import Presentation
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name);print('PASS',name,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
    page=b.new_page(viewport={'width':1650,'height':1000},accept_downloads=True)
    errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
    page.set_content((ROOT/'index.html').read_text(encoding='utf8'))
    check('v0.9.3 starts',page.locator('.version').inner_text()=='v1.0.0 RC3')
    check('existing slides render',page.locator('.thumbRow').count()==5)
    page.locator('[data-tab="design"]').click()
    check('design palette gallery',page.locator('[data-studio-theme]').count()==5)
    before=page.evaluate('store.deck.slides.map(s=>s.background)')
    page.locator('[data-studio-theme="midnight"]').click()
    after=page.evaluate('store.deck.slides.map(s=>s.background)')
    check('scope current applies only first slide',after[0]=='#15243d' and after[1:]==before[1:])
    page.locator('[data-command="edit.undo"]').first.click()
    check('theme Ctrl-Z restore',page.evaluate('store.deck.slides[0].background')==before[0])
    page.locator('[data-studio-scope="all"]').click()
    page.locator('[data-studio-theme="editorial"]').click()
    check('whole deck palette',all(x=='#fffaf3' for x in page.evaluate('store.deck.slides.map(s=>s.background)')))
    page.locator('[data-command="studio.typography"]').first.click()
    check('typography normalized title',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="text").fontSize')==44)
    page.locator('[data-tab="fontlab"]').click()
    check('font usage inventory',page.locator('.studio-font-row').count()>0)
    page.locator('#fontLabFrom').fill('Arial');page.locator('#fontLabTo').fill('Georgia')
    page.locator('[data-fontlab-replace]').click()
    check('fontlab font replacement',page.evaluate('store.deck.slides.some(s=>s.elements.some(e=>e.type==="text"&&e.fontFamily==="Georgia"))'))
    page.locator('[data-command="edit.undo"]').first.click()
    check('fontlab replace reversible',page.evaluate('store.deck.slides.some(s=>s.elements.some(e=>e.type==="text"&&e.fontFamily==="Arial"))'))
    # Place two text runs with different font names; targeted global replacement must not alter other run.
    page.evaluate('''() => {const d=makeDeck(),e=shape('text');e.text='오로라 English';e.fontFamily='Arial';e.runs=[{text:'오로라',fontFamily:'맑은 고딕'},{text:' English',fontFamily:'Arial'}];d.slides[0].elements=[e];store.load(d);active=d.slides[0].id;studioPanel='fontlab';tab='fontlab';render()}''')
    page.locator('#fontLabFrom').fill('Arial');page.locator('#fontLabTo').fill('Georgia')
    page.locator('[data-fontlab-replace]').click()
    check('partial rich-text replacement',page.evaluate('''() => {const a=store.deck.slides[0].elements[0].runs;return a[0].fontFamily==='맑은 고딕'&&a[1].fontFamily==='Georgia'}'''))
    # Local file import and refresh with explicit source confirmation.
    page.evaluate('''() => {const d=makeDeck();d.slides[0].elements=[makeChart()];store.load(d);active=d.slides[0].id;clearSelection();selectObject(d.slides[0].elements[0].id);studioPanel='data';tab='data';render()}''')
    check('live data panel active',page.locator('.studio-panel h3').inner_text()=='연결 데이터 관리')
    csv='항목,방문,구매\n1월,12,3\n2월,14,6\n3월,10,8\n'
    page.locator('#chartDataFile').set_input_files({'name':'metrics.csv','mimeType':'text/csv','buffer':csv.encode('utf8')})
    page.locator('#chartMapDialog').wait_for(state='visible')
    page.locator('#chartMapValue').select_option(['1','2'])
    page.locator('#chartMapApply').click()
    check('CSV mapping produces two series',page.evaluate('el().chartSeries.length')==2)
    check('source mapping saved',page.evaluate('el().chartSource.mapping.vals.length')==2)
    page.locator('[data-live-filter]').click() if page.locator('[data-live-filter]').count() else None
    page.locator('[data-tab="data"]').click()
    page.locator('#liveFilterMode').select_option('top')
    page.locator('#liveFilterCount').fill('2')
    page.locator('[data-live-filter]').click()
    check('filter top two',page.evaluate('el().chartData.length')==2)
    check('original chart data retained',page.evaluate('el().chartRaw.chartData.length')==3)
    page.locator('#liveFilterMode').select_option('all');page.locator('[data-live-filter]').click()
    check('filter reset',page.evaluate('el().chartData.length')==3)
    updated='항목,방문,구매\n1월,13,6\n2월,22,9\n3월,16,10\n4월,21,11\n'
    page.on('dialog',lambda d:d.accept())
    page.locator('#dataRefreshFile').set_input_files({'name':'metrics-new.csv','mimeType':'text/csv','buffer':updated.encode('utf8')})
    page.wait_for_function('el().chartData.length===4')
    check('explicit refresh updates all rows',page.evaluate('el().chartData.length')==4)
    check('source name updated',page.evaluate('el().chartSource.fileName')=='metrics-new.csv')
    page.locator('[data-command="edit.undo"]').first.click()
    check('refresh undo restores data',page.evaluate('el().chartData.length')==3)
    # Compare another JSON in-memory using existing document with modified title and object.
    original=page.evaluate('store.deck')
    different=json.loads(json.dumps(original));different['slides'][0]['elements'][0]['chartTitle']='변경된 실적';different['slides'][0]['name']='교체 테스트'
    page.locator('[data-tab="compare"]').click()
    page.locator('#compareFile').set_input_files({'name':'another.aster.json','mimeType':'application/json','buffer':json.dumps(different,ensure_ascii=False).encode('utf8')})
    check('version compare reports changes',page.locator('.studio-diff-row.changed').count()==1)
    check('compare does not alter original',page.evaluate('store.deck.slides[0].name')!=different['slides'][0]['name'])
    page.locator('[data-version-jump="0"]').click()
    page.locator('[data-version-apply="0"]').click()
    check('selective merge updates slide',page.evaluate('store.deck.slides[0].name')=='교체 테스트')
    page.locator('[data-command="edit.undo"]').first.click()
    check('compare merge is undoable',page.evaluate('store.deck.slides[0].name')!=different['slides'][0]['name'])
    # Export a real PPTX and make sure PowerPoint-compatible chart remains editable.
    with page.expect_download(timeout=25000) as dl:
        page.locator('[data-command="file.exportPptx"]').first.click()
    exported=Path(dl.value.path()).read_bytes()
    deck=Presentation(io.BytesIO(exported))
    check('exported PPTX readable',len(deck.slides)==1)
    check('exported chart editable',any(sh.has_chart for sh in deck.slides[0].shapes))
    with zipfile.ZipFile(io.BytesIO(exported)) as z:
        check('embedded spreadsheet present',any(x.startswith('ppt/embeddings/') and x.endswith('.xlsx') for x in z.namelist()))
    # Chart-to-table creation produces editable cells and supports undo.
    page.evaluate('''() => {const d=makeDeck();d.slides[0].elements=[makeChart()];store.load(d);active=d.slides[0].id;clearSelection();selectObject(d.slides[0].elements[0].id);studioPanel='data';tab='data';render()}''')
    page.locator('[data-command="data.toTable"]').first.click()
    check('chart data table on new slide',page.evaluate('store.deck.slides.length===2 && store.deck.slides[1].elements.length===10'))
    check('table cells editable as shapes',page.evaluate('store.deck.slides[1].elements.every(e=>e.type==="rounded"&&e.groupId)'))
    page.locator('[data-command="edit.undo"]').first.click()
    check('new table undoable',page.evaluate('store.deck.slides.length===1'))
    check('no uncaught browser errors',len(errors)==0)
    b.close()
print('TOTAL_CHECKS',len(checks))
