"""Real Chromium interaction tests for Aster v0.7 Motion Studio. All PPTX are held in memory."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from pptx import Presentation
import io,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
checks=0
def ok(label, truth):
 global checks
 assert truth, label
 checks+=1;print('PASS',label,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1500,'height':1000},accept_downloads=True)
 errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 ok('0.7 version header',page.locator('.version').inner_text()=='v1.0.0 RC3')
 ok('existing demo loads',page.locator('.thumbRow').count()==5)
 page.locator('[data-tab="animations"]').click()
 ok('motion dock visible',page.locator('#timelinePanel').is_visible())
 ok('empty timeline initially',page.locator('.timeline-track').count()==0)
 page.locator('#stage .element.text').first.click(force=True)
 page.locator('[data-command="anim.fade"]').first.click()
 ok('one animation created',page.locator('.timeline-track').count()==1)
 ok('animation model stored',len(page.evaluate('store.deck.slides[0].timeline'))==1)
 page.locator('[data-command="anim.pulse"]').first.click()
 ok('pulse is emphasis effect',page.evaluate('store.deck.slides[0].timeline[1].kind')=='emphasis')
 ok('two timeline rows',page.locator('.timeline-track').count()==2)
 page.locator('.timeline-track').first.click()
 page.locator('[data-timeline-prop="duration"]').fill('1.4')
 page.locator('[data-timeline-prop="duration"]').press('Tab')
 ok('duration changed',page.evaluate('store.deck.slides[0].timeline[0].duration')==1.4)
 page.locator('[data-timeline-prop="direction"]').select_option('left')
 ok('direction changed',page.evaluate('store.deck.slides[0].timeline[0].direction')=='left')
 page.locator('[data-timeline-prop="easing"]').select_option('linear')
 ok('easing changed',page.evaluate('store.deck.slides[0].timeline[0].easing')=='linear')
 page.locator('[data-timeline-prop="trigger"]').select_option('with')
 ok('with trigger starts automatically on slide entry',page.evaluate('Motion.schedule(store.deck.slides[0]).events[0].cue')==0)
 page.locator('[data-command="anim.moveDown"]').first.click()
 ok('move down changed step order',page.evaluate('store.deck.slides[0].timeline[1].effect')=='fade')
 page.locator('[data-command="edit.undo"]').first.click()
 ok('undo restores step order',page.evaluate('store.deck.slides[0].timeline[0].effect')=='fade')
 page.locator('[data-command="edit.redo"]').first.click()
 ok('redo reorders step',page.evaluate('store.deck.slides[0].timeline[1].effect')=='fade')
 # Undo to default two click cues, with an emphasis and entrance for same item
 page.locator('[data-timeline-prop="trigger"]').select_option('click')
 page.locator('[data-command="anim.preview"]').first.click()
 ok('slide show opens',page.locator('#slideShow').is_visible())
 ok('show cue label visible',page.locator('#showCue').inner_text().startswith('클릭 0'))
 page.locator('[data-command="show.next"]').click()
 ok('first presentation click increments cue',page.locator('#showCue').inner_text().startswith('클릭 1'))
 page.locator('[data-command="show.prev"]').click()
 ok('previous cue moves backward',page.locator('#showCue').inner_text().startswith('클릭 0'))
 page.locator('[data-command="show.replay"]').click()
 ok('replay keeps starting stage',page.locator('#showCue').inner_text().startswith('클릭 0'))
 page.locator('[data-command="show.end"]').click()
 ok('slide show closes',not page.locator('#slideShow').is_visible())
 page.locator('.timeline-track').last.click()
 page.locator('[data-command="anim.delete"]').first.click()
 ok('remove effect works',page.locator('.timeline-track').count()==1)
 # Transition controls on ribbon and props
 page.locator('[data-command="transition.wipe"]').first.click()
 ok('wipe transition changed',page.evaluate('store.deck.slides[0].transition')=='wipe')
 page.locator('[data-command="transition.dissolve"]').first.click()
 ok('dissolve transition changed',page.evaluate('store.deck.slides[0].transition')=='dissolve')
 page.locator('#stage').click(position={'x':250,'y':300},force=True)
 ok('slide transition settings available',page.locator('#propertiesBody [data-prop="transitionDuration"]').count()==1)
 page.locator('#propertiesBody [data-prop="transitionDuration"]').fill('1.5')
 page.locator('#propertiesBody [data-prop="transitionDuration"]').press('Tab')
 ok('slide transition duration persists',page.evaluate('store.deck.slides[0].transitionDuration')==1.5)
 # JSON export project keeps timeline
 with page.expect_download() as d:page.locator('[data-command="file.exportJson"]').first.click()
 project=d.value.path().read_bytes()
 import json
 data=json.loads(project)
 ok('project JSON carries timeline',len(data['slides'][0]['timeline'])==1)
 page.locator('#openFile').set_input_files({'name':'motion.aster.json','mimeType':'application/json','buffer':project})
 ok('project JSON restores timeline',len(page.evaluate('store.deck.slides[0].timeline'))==1)
 # Native PPTX carries advanced motion as Aster metadata.
 with page.expect_download(timeout=60000) as d:
  page.locator('[data-tab="file"]').click();page.locator('[data-command="file.exportPptxNative"]').first.click()
 native=d.value.path().read_bytes()
 with zipfile.ZipFile(io.BytesIO(native)) as z:
  filenames=z.namelist();ok('native PPTX contains Aster edit snapshot',any(x.startswith('customXml/') for x in filenames))
  ET.fromstring(z.read('ppt/slides/slide1.xml'))
  ok('slide XML remains well-formed',True)
 ok('presentation parses by independent library',len(Presentation(io.BytesIO(native)).slides)==5)
 page.locator('#openFile').set_input_files({'name':'motion-editable.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':native})
 ok('native PPTX restores motion timeline',len(page.evaluate('store.deck.slides[0].timeline'))==1)
 # Standard export strips custom motion, preserving slide content and transition.
 with page.expect_download(timeout=60000) as d:
  page.locator('[data-tab="file"]').click();page.locator('[data-command="file.exportPptx"]').first.click()
 standard=d.value.path().read_bytes()
 with zipfile.ZipFile(io.BytesIO(standard)) as z:
  xml=z.read('ppt/slides/slide1.xml').decode()
  ok('standard PPTX writes dissolve transition','<p:dissolve' in xml)
  ok('standard PPTX now writes native object animations','<p:timing>' in xml)
  ok('standard PPTX omits proprietary metadata','customXml/asterDeck1.xml' not in z.namelist())
 ok('standard PPTX parses',len(Presentation(io.BytesIO(standard)).slides)==5)
 ok('no JavaScript runtime errors',not errs)
 browser.close()
print('BROWSER TOTAL',checks)
