"""Browser integration test for multi-series, chart types, and native PPTX interoperability.
Artifacts are in-memory; no samples are added to the distribution.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from pptx import Presentation
import io, zipfile, tempfile
ROOT=Path(__file__).resolve().parents[1]
checks=0
def ok(msg, v):
 global checks
 assert v,msg
 checks+=1;print('PASS',msg,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1550,'height':930},accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 ok('new version header','v1.0.0 RC3' in page.locator('.version').inner_text())
 page.locator('[data-tab="insert"]').click();page.locator('[data-command="insert.chart"]').first.click()
 ok('chart inserted',page.locator('#stage .chart').count()==1)
 page.locator('#propertiesBody [data-command="chart.import"]').click()
 csv='항목,2025,2026\n봄,10,19\n여름,20,31\n가을,30,24\n겨울,40,45'
 page.locator('#chartDataFile').set_input_files({'name':'quarter.csv','mimeType':'text/csv','buffer':csv.encode()})
 ok('multi-select visible',page.locator('#chartMapValue').get_attribute('multiple') is not None)
 page.locator('#chartMapValue').select_option(['1','2']);page.locator('#chartMapApply').click()
 ok('two series created',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSeries.length')==2)
 ok('second series correct',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSeries[1].values[3]')==45)
 page.locator('#propertiesBody select[data-prop="chartType"]').select_option('stacked')
 ok('stacked SVG renders bars',page.locator('#stage .chart svg rect').count()>5)
 page.locator('#propertiesBody select[data-prop="chartLegend"]').select_option('right')
 page.locator('#propertiesBody input[data-prop="chartDataLabels"]').check()
 page.locator('#propertiesBody input[data-prop="chartShowYAxis"]').uncheck()
 ok('legend persisted',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartLegend')=='right')
 ok('labels toggled',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartDataLabels'))
 page.locator('#propertiesBody input[data-prop="chartAxisMin"]').fill('0');page.locator('#propertiesBody input[data-prop="chartAxisMin"]').press('Tab')
 page.locator('#propertiesBody input[data-prop="chartAxisMax"]').fill('110');page.locator('#propertiesBody input[data-prop="chartAxisMax"]').press('Tab')
 ok('custom max is model value',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartAxisMax')==110)
 # Rename a series by editing CSV-shaped table
 editor=page.locator('#propertiesBody textarea[data-prop="chartData"]');editor.fill('항목,매출,이익\n봄,10,4\n여름,20,7\n가을,30,8\n겨울,40,11');editor.press('Tab')
 ok('series renamed from table header',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSeries[1].name')=='이익')
 ok('two series still present',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSeries.length')==2)
 page.locator('#propertiesBody [data-series-color="1"]').fill('#c24897')
 page.locator('#propertiesBody [data-series-color="1"]').press('Tab')
 ok('series-specific color persisted',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSeries[1].color')=='#c24897')
 with page.expect_download(timeout=60000) as dl:page.locator('[data-command="file.exportPptx"]').first.click()
 ppt=dl.value.path().read_bytes();pptx=Presentation(io.BytesIO(ppt))
 charts=[x.chart for x in pptx.slides[0].shapes if x.has_chart]
 ok('PowerPoint parser recognizes chart',len(charts)==1)
 ok('PowerPoint parser sees two series',len(charts[0].series)==2)
 ok('PowerPoint parser sees stacked col type',charts[0].chart_type is not None)
 with zipfile.ZipFile(io.BytesIO(ppt)) as z:
  chart_path=next(path for path in z.namelist() if path.startswith('ppt/charts/chart') and path.endswith('.xml'))
  cxml=z.read(chart_path).decode()
  ok('XML has native stacked grouped type','grouping val="stacked"' in cxml)
  ok('native axis limits correct','max val="110"' in cxml)
  embed=next(path for path in z.namelist() if path.startswith('ppt/embeddings/') and path.endswith('.xlsx'))
  with zipfile.ZipFile(io.BytesIO(z.read(embed))) as wz:
   sheet=wz.read('xl/worksheets/sheet1.xml').decode()
   ok('embedded XLSX has second data series','C5' in sheet and '이익' in sheet)
 # One-click chart type swaps and SVG rendering
 for t in ['line','pie','doughnut','bar']:
  page.locator('#propertiesBody select[data-prop="chartType"]').select_option(t)
  ok(f'{t} SVG displays',page.locator('#stage .chart svg').count()==1)
 with page.expect_download() as dl:page.locator('#propertiesBody [data-command="chart.exportCsv"]').click()
 ok('export CSV includes both series headers','매출' in dl.value.path().read_text(encoding='utf-8-sig') and '이익' in dl.value.path().read_text(encoding='utf-8-sig'))
 # standard import uses XML caches (no private snapshot)
 page.on('dialog',lambda dlg:dlg.accept())
 page.locator('#openFile').set_input_files({'name':'external.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':ppt})
 page.wait_for_timeout(250)
 imported=page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart")')
 ok('import restored two series',len(imported['chartSeries'])==2)
 ok('import kept categories',imported['chartData'][0]['label']=='봄')
 ok('import kept stacked',imported['chartType']=='stacked')
 ok('browser has no errors',not errors)
 browser.close()
print('BROWSER CHECKS',checks)
