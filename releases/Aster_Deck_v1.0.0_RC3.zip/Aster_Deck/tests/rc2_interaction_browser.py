from pathlib import Path
from playwright.sync_api import sync_playwright
from io import BytesIO
from pptx import Presentation
import json,sys
ROOT=Path(__file__).resolve().parents[1]
results=[]
def check(name,ok):
    assert ok,name
    results.append(name); print('PASS:',name,flush=True)
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':1540,'height':920},accept_downloads=True)
    page=ctx.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
    page.set_content((ROOT/'index.html').read_text(),wait_until='load')
    page.wait_for_timeout(250)
    check('loads current RC3 label',page.locator('.version').inner_text()=='v1.0.0 RC3')
    page.locator('.addSlide').click()
    page.locator('[data-command="insert.text"]').first.click()
    model=lambda:page.evaluate('JSON.parse(JSON.stringify(store.deck))')
    e=model()['slides'][1]['elements'][0]
    tid=e['id']
    loc=page.locator('#stage .element.text')
    check('new text object selected',loc.count()==1)
    # Playwright locator click position uses scaled element CSS bounding rect.
    r=loc.bounding_box()
    page.mouse.click(r['x']+r['width']*.4,r['y']+r['height']*.5)
    check('single-click puts text into editing',page.evaluate('!!editing && editing.id===selected && editing.node.isContentEditable'))
    check('caret stays inside editor',page.evaluate('document.activeElement?.classList.contains("text")'))
    page.keyboard.insert_text('오로라 Hello world')
    check('inserted mixed text by one-click', '오로라 Hello world' in loc.inner_text())
    check('native selection caret present',page.evaluate('window.getSelection().rangeCount>0'))
    # select first 3 characters directly through browser Range, same API native drag selects.
    page.evaluate('''() => {const root=document.querySelector('#stage .element.text'),tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;while((n=tw.nextNode())&&!n.textContent.includes('오로라')){};const r=document.createRange();r.setStart(n,0);r.setEnd(n,3);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);document.dispatchEvent(new Event('selectionchange'));}''')
    check('drag range cached',page.evaluate('rangeCache?.end-rangeCache?.start===3'))
    check('contextual toolbar visible',page.locator('#quickFormat').is_visible())
    check('text selected not entire object',page.locator('#quickFormat').get_attribute('role')=='toolbar')
    # click toolbar bold; selection must stay after rerender
    page.locator('[data-qf-action="bold"]').dispatch_event('pointerdown',{'button':0,'pointerType':'mouse','isPrimary':True})
    runs=model()['slides'][1]['elements'][0].get('runs',[])
    check('only selected prefix bold',runs[0]['text']=='오로라' and runs[0]['bold'] and not any(x.get('bold') for x in runs[1:]))
    check('selection restored for second format',page.evaluate('!!editing && rangeCache?.start===0 && rangeCache?.end===3'))
    check('quick bar persists after format',page.locator('#quickFormat').is_visible())
    # now choose a font by opening toolbar custom menu
    page.locator('[data-qf-menu="font"]').dispatch_event('pointerdown',{'button':0,'pointerType':'mouse'})
    check('font dropdown visible',page.locator('#quickSubmenu').is_visible())
    page.locator('[data-qf-font="Georgia"]').dispatch_event('pointerdown',{'button':0,'pointerType':'mouse'})
    runs=model()['slides'][1]['elements'][0]['runs']
    check('partial prefix font changed',runs[0]['fontFamily']=='Georgia' and 'fontFamily' not in runs[-1])
    page.locator('[data-qf-menu="color"]').dispatch_event('pointerdown',{'button':0,'pointerType':'mouse'})
    page.locator('[data-qf-color="#e34747"]').dispatch_event('pointerdown',{'button':0,'pointerType':'mouse'})
    runs=model()['slides'][1]['elements'][0]['runs']
    check('partial prefix color changed',runs[0]['color']=='#e34747' and 'color' not in runs[-1])
    # native escape exits editing; object remains selected
    page.keyboard.press('Escape')
    check('Escape ends editing',page.evaluate('editing===null'))
    # apply undo and redo from ribbon
    page.locator('[data-command="edit.undo"]').first.click()
    check('undo color change',model()['slides'][1]['elements'][0]['runs'][0].get('color')!='#e34747')
    page.locator('[data-command="edit.redo"]').first.click()
    check('redo color change',model()['slides'][1]['elements'][0]['runs'][0].get('color')=='#e34747')
    # border pointer on top should start drag rather than text editing; use position within 3px from left, 1/2 height
    loc=page.locator('#stage .element.text');r=loc.bounding_box()
    page.mouse.move(r['x']+2,r['y']+r['height']/2)
    check('border hover move cursor',loc.evaluate('(e)=>e.style.cursor')=='move')
    page.mouse.move(r['x']+2,r['y']+r['height']/2)
    page.mouse.down();page.mouse.move(r['x']+45,r['y']+r['height']/2+15,steps=5);page.mouse.up()
    ee=model()['slides'][1]['elements'][0]
    check('dragging text border moves object',ee['x']!=e['x'] or ee['y']!=e['y'])
    check('drag not in typing mode',page.evaluate('editing===null'))
    # PPTX export sanity
    with page.expect_download() as info:page.locator('[data-command="file.exportPptx"]').first.click()
    data=info.value.path().read_bytes()
    pres=Presentation(BytesIO(data))
    check('PowerPoint-compatible export opens in python-pptx',len(pres.slides)>=2)
    check('PowerPoint exported rich formatting',any(getattr(sh,'has_text_frame',False) and '오로라' in sh.text for sh in pres.slides[1].shapes))
    check('no browser page errors',not errs)
    browser.close()
print('RC2 browser checks',len(results),'PASS')
