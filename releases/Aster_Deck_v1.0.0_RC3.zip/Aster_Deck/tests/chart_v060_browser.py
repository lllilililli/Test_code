"""Generate ephemeral CSV / XLSX fixtures in memory and test the real offline editor."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import zipfile, io, tempfile, json
from pptx import Presentation
ROOT=Path(__file__).resolve().parents[1]
count=0

def ok(label, result):
 global count
 assert result,label
 count+=1
 print('PASS',label,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1560,'height':900},accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 ok('v0.7.0 version visible','v1.0.0 RC3' in page.locator('.version').inner_text())
 page.locator('[data-tab="insert"]').click()
 page.locator('[data-command="insert.chart"]').first.click()
 ok('chart inserted on canvas',page.locator('#stage .chart').count()==1)
 ok('chart import button in properties',page.locator('#propertiesBody [data-command="chart.import"]').count()==1)

 page.locator('#propertiesBody [data-command="chart.import"]').click()
 page.locator('#chartDataFile').set_input_files({'name':'매출.csv','mimeType':'text/csv','buffer':'항목,값\n소금빵,15\n바게트,40\n크루아상,25'.encode()})
 page.locator('#chartMapDialog').wait_for(state='visible',timeout=10000)
 ok('column mapper dialog opens',page.locator('#chartMapDialog').is_visible())
 ok('preview contains incoming rows',page.locator('#chartMapTable tbody tr').count()==3)
 page.locator('#chartMapApply').click()
 page.wait_for_timeout(250)
 data=page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartData')
 ok('CSV content imported and changed to 3 rows',data==[{'label':'소금빵','value':15},{'label':'바게트','value':40},{'label':'크루아상','value':25}])
 ok('column selection persisted',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartSource.categoryColumn')=='항목')
 page.locator('#stage').focus();page.keyboard.press('Control+z')
 ok('undo restores former chart data',len(page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartData'))==4)
 page.keyboard.press('Control+y')
 ok('redo restores imported data',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartData[0].label')=='소금빵')
 with page.expect_download() as dl:page.locator('#propertiesBody [data-command="chart.exportCsv"]').click()
 text=dl.value.path().read_text(encoding='utf-8-sig')
 ok('export CSV contains imported label', '"크루아상",25' in text)
 with page.expect_download(timeout=60000) as dl:page.locator('[data-command="file.exportPptx"]').first.click()
 saved=dl.value.path().read_bytes()
 with zipfile.ZipFile(io.BytesIO(saved)) as z:
  ok('PPTX contains editable native chart',any(x.startswith('ppt/charts/chart1_') and x.endswith('.xml') for x in z.namelist()))
  wb=z.read(next(x for x in z.namelist() if x.startswith('ppt/embeddings/asterData1_') and x.endswith('.xlsx')))
 ppx=Presentation(io.BytesIO(saved))
 ok('PowerPoint chart object exists',any(x.has_chart for x in ppx.slides[0].shapes))
 ok('PowerPoint chart series has imported categories',list(next(x.chart for x in ppx.slides[0].shapes if x.has_chart).plots[0].categories)[0].label=='소금빵')
 page.locator('#propertiesBody [data-command="chart.import"]').click()
 page.locator('#chartDataFile').set_input_files({'name':'chart.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':wb})
 page.locator('#chartMapApply').click()
 page.wait_for_timeout(250)
 ok('embedded XLSX data reimported',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartData[1].value')==40)
 # Recompress workbook entries with DEFLATE, as ordinary Excel files normally are.
 with zipfile.ZipFile(io.BytesIO(wb)) as original:
  with io.BytesIO() as sink:
   with zipfile.ZipFile(sink,'w',zipfile.ZIP_DEFLATED) as compressed:
    for info in original.infolist():compressed.writestr(info.filename,original.read(info.filename))
   compressed_wb=sink.getvalue()
 page.locator('#propertiesBody [data-command="chart.import"]').click()
 page.locator('#chartDataFile').set_input_files({'name':'compressed.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':compressed_wb})
 page.locator('#chartMapApply').click();page.wait_for_timeout(200)
 ok('compressed XLSX via deflate import works',page.evaluate('store.deck.slides[0].elements.find(e=>e.type==="chart").chartData.length')==3)
 # Standard PPTX import (without private Aster snapshot) restores native chart caches.
 page.locator('#openFile').set_input_files({'name':'native-chart.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':saved})
 page.wait_for_timeout(300)
 ok('PPTX native chart import returns element with data',page.evaluate('store.deck.slides[0].elements.filter(e=>e.type==="chart").some(e=>e.chartData.some(x=>x.label==="크루아상"))'))

 ok('no browser exceptions',not errors)
 browser.close()
print('BROWSER CHECKS',count)
