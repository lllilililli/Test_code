import {zipRead,zipWrite,zipText,u8} from './zip.js';
import {makeDeck,makeSlide,shape,effectiveBg,allElements,W,H} from './core.js';
import {pxToPptFontSize,pptFontSizeToPx,pxToEmu,emuToPx,textLayout} from './text-layout.js';
import {textRuns,mergeRuns} from './rich-text.js';
import * as Smart from './smart-layout.js';
import * as NativeChart from './native-chart.js';
import * as NativeMotion from './pptx-motion.js';
const xml=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const E=9525,ns='http://schemas.openxmlformats.org/presentationml/2006/main',a='http://schemas.openxmlformats.org/drawingml/2006/main';
const emu=n=>Math.round(n*E),clamp=n=>Math.max(0,Math.round(n));
const safeFont=s=>String(s||'Arial').replace(/[\u0000-\u001f]/g,'').slice(0,120);
const hx=s=>{const v=String(s||'#000000').replace(/^#/,'').trim();
 if(/^[0-9a-f]{3}$/i.test(v))return [...v].map(c=>c+c).join('').toUpperCase();
 if(/^[0-9a-f]{6}$/i.test(v))return v.toUpperCase();
 if(/^[0-9a-f]{8}$/i.test(v))return v.slice(0,6).toUpperCase();
 return '000000';};
const attr=(node,name,fallback='')=>node?.getAttribute(name)??fallback;
const descendants=(root,local)=>Array.from(root?.getElementsByTagNameNS('*',local)||[]);
const firstDirect=(root,local)=>Array.from(root?.children||[]).find(x=>x.localName===local);
const dxml=t=>new DOMParser().parseFromString(t,'application/xml');
// Aster-authored PPTX contains an optional private editing snapshot. It is NOT
// used when any native PPTX presentation/content part has been changed.
const ASTER_PART='customXml/asterDeck1.xml';
const ASTER_NS='https://aster-deck.local/schema/2026/document';
function signature(entries){
 let h=2166136261>>>0;
 for(const key of Object.keys(entries).filter(k=>k.startsWith('ppt/')).sort()){
  const val=entries[key],bytes=typeof val==='string'?u8(val):val;
  for(const b of u8(key)){h=Math.imul(h^b,16777619)>>>0}
  for(const b of bytes){h=Math.imul(h^b,16777619)>>>0}
 }
 return h.toString(16).padStart(8,'0');
}
function b64utf8(str){const data=u8(str);let result='';for(let i=0;i<data.length;i+=8192)result+=String.fromCharCode(...data.subarray(i,i+8192));return btoa(result);}
function deb64utf8(encoded){const str=atob(encoded),arr=Uint8Array.from(str,c=>c.charCodeAt(0));return new TextDecoder('utf-8',{fatal:true}).decode(arr)}
function readAsterSnapshot(entries){
 const raw=zipText(entries,ASTER_PART);if(!raw)return null;
 try{
  const root=dxml(raw).documentElement;
  if(root.namespaceURI!==ASTER_NS||root.localName!=='document'||attr(root,'fingerprint')!==signature(entries))return null;
  const model=JSON.parse(deb64utf8(root.textContent.trim()));
  if(model?.format!=='aster-deck'||!Array.isArray(model.slides)||!model.slides.length)return null;
  return model;
 }catch(error){console.warn('Ignoring invalid or outdated native snapshot:',error);return null}
}

function elementXml(e,i,slideIndex,media){const x=emu(e.x),y=emu(e.y),cx=emu(e.w),cy=emu(e.h),label=xml(e.type+' '+i);const xfrm=`<a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>`;
 if(e.type==='image'&&e.src){let m=e.src.match(/^data:(image\/(?:png|jpeg));base64,(.*)$/);if(m){const ext=m[1]==='image/png'?'png':'jpeg',ref=`rId${media.length+1+(slideIndex===0?2:0)}`,name=`image_${slideIndex}_${i}.${ext}`;media.push({ref,name,data:Uint8Array.from(atob(m[2]),c=>c.charCodeAt(0))});return `<p:pic><p:nvPicPr><p:cNvPr id="${i}" name="${label}"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${ref}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr>${xfrm}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`;}}
 const isText=e.type==='text',geo=({ellipse:'ellipse',rounded:'roundRect',star:'star5',arrow:'rightArrow'})[e.type]||'rect',fill=!isText&&(e.fill!=='transparent'||e.type==='line')?`<a:solidFill><a:srgbClr val="${hx(e.type==='line'?e.stroke:e.fill)}"/></a:solidFill>`:'<a:noFill/>',line=e.stroke&&e.stroke!=='transparent'?`<a:ln><a:solidFill><a:srgbClr val="${hx(e.stroke)}"/></a:solidFill></a:ln>`:'<a:ln><a:noFill/></a:ln>',metrics=textLayout(e);
 const segments=[[]];
 for(const run of textRuns(e)){
  const parts=String(run.text).split('\n');
  parts.forEach((part,j)=>{if(j)segments.push([]);if(part)segments.at(-1).push({...run,text:part})});
 }
 const paragraphs=segments.map(segmentsInParagraph=>{
  const runs=segmentsInParagraph.map(r=>{
   const name=xml(safeFont(r.fontFamily??e.fontFamily)),size=pxToPptFontSize(r.fontSize??e.fontSize??24);
   const color=hx(r.color??e.color),bold=r.bold??e.bold,italic=r.italic??e.italic,underline=r.underline??e.underline;
   return `<a:r><a:rPr lang="ko-KR" sz="${size}" b="${bold?1:0}" i="${italic?1:0}"${underline?' u="sng"':''}><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="${name}"/><a:ea typeface="${name}"/><a:cs typeface="${name}"/></a:rPr><a:t xml:space="preserve">${xml(r.text)}</a:t></a:r>`;
  }).join('');
  const font=xml(safeFont(e.fontFamily));
  return `<a:p><a:pPr algn="${e.align==='center'?'ctr':e.align==='right'?'r':'l'}"><a:lnSpc><a:spcPct val="${Math.round(metrics.lineSpacing*100000)}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:spcAft><a:spcPts val="0"/></a:spcAft></a:pPr>${runs}<a:endParaRPr lang="ko-KR"><a:latin typeface="${font}"/><a:ea typeface="${font}"/></a:endParaRPr></a:p>`;
 }).join('');
 return `<p:sp><p:nvSpPr><p:cNvPr id="${i}" name="${label}"/><p:cNvSpPr txBox="${isText?1:0}"/><p:nvPr/></p:nvSpPr><p:spPr>${xfrm}<a:prstGeom prst="${geo}"><a:avLst/></a:prstGeom>${fill}${line}</p:spPr><p:txBody><a:bodyPr wrap="${e.type==='star'?'none':'square'}" anchor="${metrics.verticalAlign==='middle'?'ctr':metrics.verticalAlign==='bottom'?'b':'t'}" lIns="${pxToEmu(metrics.marginX)}" tIns="${pxToEmu(metrics.marginY)}" rIns="${pxToEmu(metrics.marginX)}" bIns="${pxToEmu(metrics.marginY)}">${metrics.autoFit==='shrink'?'<a:normAutofit/>':metrics.autoFit==='resize'?'<a:spAutoFit/>':'<a:noAutofit/>'}</a:bodyPr><a:lstStyle/>${paragraphs}</p:txBody></p:sp>`;
}
// Native groups use an identity group transform in slide coordinates, so child
// DrawingML geometry remains editable individually by Office.
function groupXml(items,groupId,slideIndex,media){
 const bounds={x:Math.min(...items.map(v=>v.e.x)),y:Math.min(...items.map(v=>v.e.y))};
 bounds.w=Math.max(1,Math.max(...items.map(v=>v.e.x+v.e.w))-bounds.x);
 bounds.h=Math.max(1,Math.max(...items.map(v=>v.e.y+v.e.h))-bounds.y);
 const x=emu(bounds.x),y=emu(bounds.y),w=emu(bounds.w),h=emu(bounds.h);
 return `<p:grpSp><p:nvGrpSpPr><p:cNvPr id="${groupId}" name="Aster group"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/><a:chOff x="${x}" y="${y}"/><a:chExt cx="${w}" cy="${h}"/></a:xfrm></p:grpSpPr>${items.map(v=>elementXml(v.e,v.id,slideIndex,media)).join('')}</p:grpSp>`;
}
function nativeElementTree(elements,slideIndex,media){
 const emitted=new Set();let output='';
 for(let i=0;i<elements.length;i++){
  const e=elements[i];if(emitted.has(i))continue;
  if(e.groupId && ['text','rect','rounded','ellipse','image','star','arrow','line'].includes(e.type)){
   const members=elements.map((item,j)=>({e:item,j,id:j+2})).filter(v=>v.e.groupId===e.groupId && ['text','rect','rounded','ellipse','image','star','arrow','line'].includes(v.e.type));
   if(members.length>1){for(const m of members)emitted.add(m.j);output+=groupXml(members,50000+i,slideIndex,media);continue;}
  }
  if(e.type==='chart')output+=NativeChart.chartGraphic(e,i+2,'rId'+(200+i));
  else if(e.type==='connector'){
   const route=Smart.connectorPath(elements,e);
   if(route)output+=route.points.slice(1).map((pt,k)=>connectorLegXml(route.points[k],pt,10000+i*8+k,e,k===route.points.length-2)).join('');
  }else output+=elementXml(e,i+2,slideIndex,media);
  emitted.add(i);
 }
 return output;
}
// Flatten live Aster connectors to standard DrawingML connector shapes for PPTX.
// .aster.json / native PPTX retain the target-ID relationships; standard PPTX
// intentionally contains only editable line segments, not private metadata.
function connectorLegXml(a,b,id,e,last){
 const left=Math.min(a.x,b.x),top=Math.min(a.y,b.y),cx=Math.max(1,Math.abs(b.x-a.x)),cy=Math.max(1,Math.abs(b.y-a.y));
 const flipH=(b.x<a.x)?' flipH="1"':'',flipV=(b.y<a.y)?' flipV="1"':'';
 const stroke=hx(e.stroke||'#4b648b'),width=emu(Math.max(1,Math.min(12,e.strokeWidth||3)));
 return `<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="${id}" name="Aster smart connector"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr><p:spPr><a:xfrm${flipH}${flipV}><a:off x="${emu(left)}" y="${emu(top)}"/><a:ext cx="${emu(cx)}" cy="${emu(cy)}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:ln w="${width}"><a:solidFill><a:srgbClr val="${stroke}"/></a:solidFill>${last?'<a:tailEnd type="triangle"/>':''}</a:ln></p:spPr></p:cxnSp>`;
}
function slideXml(slide,i,media,deck){
 const elements=slide.elements;const shapes=nativeElementTree(elements,i,media);
 const timing=NativeMotion.timingXml(slide,Object.fromEntries(elements.map((e,j)=>[e.id,j+2]).filter(([id,n])=>elements[n-2].type!=='connector')));
 const transition=slide.transition&&slide.transition!=='none'?`<p:transition spd="${Number(slide.transitionDuration)<0.42?'fast':Number(slide.transitionDuration)>1?'slow':'med'}">${({fade:'<p:fade/>',slide:'<p:push dir="l"/>',zoom:'<p:zoom dir="in"/>',wipe:'<p:wipe dir="l"/>',dissolve:'<p:dissolve/>'})[slide.transition]||''}</p:transition>`:'';
 return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="${a}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="${ns}"${slide.hideMaster?' showMasterSp="0"':''}><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="${hx(effectiveBg(deck,slide))}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${shapes}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>${transition}${timing}</p:sld>`;
}
export function exportPptx(deck,editableSource=deck){if(deck.master?.elements?.some(e=>['chart','connector'].includes(e.type)))throw Error('현재 PPTX 공통 마스터에서는 차트와 스마트 연결선을 지원하지 않아. 마스터에서 제외하고 저장해 줘.');let entries={},mediaIndex=[];const types=['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>','<Default Extension="xml" ContentType="application/xml"/>','<Default Extension="png" ContentType="image/png"/>','<Default Extension="jpeg" ContentType="image/jpeg"/>','<Default Extension="xlsx" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/>'];const overrides=['<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>','<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>','<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>','<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'];
 const rels=(items)=>`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${items.join('')}</Relationships>`;
 const rel=(id,type,target)=>`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/${type}" Target="${target}"/>`;
 const ids=[];const pRels=[rel('rId1','slideMaster','slideMasters/slideMaster1.xml')];deck.slides.forEach((s,i)=>{const n=i+1,media=[];entries[`ppt/slides/slide${n}.xml`]=slideXml(s,n,media,deck);overrides.push(`<Override PartName="/ppt/slides/slide${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`);const srels=[rel('rId100','slideLayout','../slideLayouts/slideLayout1.xml')];
 s.elements.forEach((e,j)=>{if(e.type!=='chart')return;const index=n+'_'+j,chartName='chart'+index+'.xml',bookName='asterData'+index+'.xlsx';
 entries['ppt/charts/'+chartName]=NativeChart.chartXml(e,bookName);
 entries['ppt/charts/_rels/'+chartName+'.rels']=NativeChart.chartRelationship(bookName);
 entries['ppt/embeddings/'+bookName]=NativeChart.xlsxForChart(e);
 overrides.push(`<Override PartName="/ppt/charts/${chartName}" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`);
 srels.push(rel('rId'+(200+j),'chart','../charts/'+chartName));
 });
 media.forEach(m=>{entries['ppt/media/'+m.name]=m.data;srels.push(rel(m.ref,'image','../media/'+m.name))});entries[`ppt/slides/_rels/slide${n}.xml.rels`]=rels(srels);ids.push(`<p:sldId id="${256+i}" r:id="rId${i+2}"/>`);pRels.push(rel('rId'+(i+2),'slide',`slides/slide${n}.xml`));});
 entries['ppt/presentation.xml']=`<?xml version="1.0" encoding="UTF-8"?><p:presentation xmlns:a="${a}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="${ns}"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>${ids.join('')}</p:sldIdLst><p:sldSz cx="${emu(W)}" cy="${emu(H)}" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`;
 if(editableSource)pRels.push(rel('rId10000','customXml','../customXml/asterDeck1.xml'));
 entries['ppt/_rels/presentation.xml.rels']=rels(pRels);
 const masterMedia=[];
 entries['ppt/slideMasters/slideMaster1.xml']=`<?xml version="1.0" encoding="UTF-8"?><p:sldMaster xmlns:a="${a}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="${ns}"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${nativeElementTree(deck.master?.elements||[],0,masterMedia)}</p:spTree></p:cSld><p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>`;
 for(const m of masterMedia)entries['ppt/media/'+m.name]=m.data;
 entries['ppt/slideMasters/_rels/slideMaster1.xml.rels']=rels([rel('rId1','slideLayout','../slideLayouts/slideLayout1.xml'),rel('rId2','theme','../theme/theme1.xml'),...masterMedia.map((m,i)=>rel('rId'+(i+3),'image','../media/'+m.name))]);
 entries['ppt/slideLayouts/slideLayout1.xml']=`<?xml version="1.0" encoding="UTF-8"?><p:sldLayout xmlns:a="${a}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="${ns}" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${nativeElementTree(deck.master?.elements||[],0,masterMedia)}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`;
 entries['ppt/slideLayouts/_rels/slideLayout1.xml.rels']=rels([rel('rId1','slideMaster','../slideMasters/slideMaster1.xml')]);
 entries['ppt/theme/theme1.xml']=`<?xml version="1.0" encoding="UTF-8"?><a:theme xmlns:a="${a}" name="Aster Deck"><a:themeElements><a:clrScheme name="Aster"><a:dk1><a:srgbClr val="17263F"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="27334A"/></a:dk2><a:lt2><a:srgbClr val="F2F5FA"/></a:lt2>${['6C70F5','10B6A7','F4A340','D662A2','406BC6','43AB79'].map((c,i)=>`<a:accent${i+1}><a:srgbClr val="${c}"/></a:accent${i+1}>`).join('')}<a:hlink><a:srgbClr val="3867CF"/></a:hlink><a:folHlink><a:srgbClr val="9562A1"/></a:folHlink></a:clrScheme><a:fontScheme name="Aster"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Aster"><a:fillStyleLst>${["accent1","accent2","accent3"].map(c=>`<a:solidFill><a:schemeClr val="${c}"/></a:solidFill>`).join('')}</a:fillStyleLst><a:lnStyleLst>${["accent1","accent2","accent3"].map(c=>`<a:ln w="9525"><a:solidFill><a:schemeClr val="${c}"/></a:solidFill></a:ln>`).join('')}</a:lnStyleLst><a:effectStyleLst>${[1,2,3].map(()=>'<a:effectStyle><a:effectLst/></a:effectStyle>').join('')}</a:effectStyleLst><a:bgFillStyleLst>${["lt1","lt2","dk1"].map(c=>`<a:solidFill><a:schemeClr val="${c}"/></a:solidFill>`).join('')}</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>`;
 // The private snapshot is a supplementary, standards-compatible Custom XML part.
 // It allows exact Aster→PPTX→Aster editing, while Office reads editable native slides.
 if(editableSource){
 const fp=signature(entries);
 entries[ASTER_PART]=`<?xml version="1.0" encoding="UTF-8"?><ad:document xmlns:ad="${ASTER_NS}" fingerprint="${fp}" version="1">${b64utf8(JSON.stringify(editableSource))}</ad:document>`;
 types.push('<Default Extension="bin" ContentType="application/octet-stream"/>');
 overrides.push('<Override PartName="/customXml/asterDeck1.xml" ContentType="application/xml"/>');
 }
 entries['_rels/.rels']=rels([`<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>`]);entries['[Content_Types].xml']=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">${types.join('')}${overrides.join('')}</Types>`;return zipWrite(entries);}
function colorFrom(node,fallback){const clr=descendants(node,'srgbClr')[0];return clr?'#'+attr(clr,'val'):fallback}
export async function importPptx(bytes){const files=await zipRead(bytes),pres=zipText(files,'ppt/presentation.xml');
 const native=readAsterSnapshot(files);
 if(native){native._importFidelity='aster-native';return native;}
 if(!pres)throw Error('유효한 PPTX 프레젠테이션이 아닙니다.');const meta=dxml(pres),size=descendants(meta,'sldSz')[0],cw=Number(attr(size,'cx',emu(W))),ch=Number(attr(size,'cy',emu(H)));const relDoc=dxml(zipText(files,'ppt/_rels/presentation.xml.rels')),relMap={};for(const r of descendants(relDoc,'Relationship'))relMap[attr(r,'Id')]=attr(r,'Target');const result=makeDeck();result.title='PPTX 가져오기';result.slides=[];
 for(const idNode of descendants(meta,'sldId')){const id=idNode.getAttribute('r:id')||idNode.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');let path=relMap[id];if(!path)continue;path=path.replace(/^\.\.\//,'');const file=path.startsWith('/')?path.slice(1):'ppt/'+path;const doc=dxml(zipText(files,file));const slide=makeSlide('가져온 슬라이드 '+(result.slides.length+1));slide._pptxSlidePath=file;const bg=descendants(doc,'bgPr')[0];if(bg)slide.background=colorFrom(bg,'#ffffff');const tr=descendants(doc,'transition')[0];if(tr){if(descendants(tr,'fade').length)slide.transition='fade';else if(descendants(tr,'push').length)slide.transition='slide';else if(descendants(tr,'zoom').length)slide.transition='zoom';else if(descendants(tr,'wipe').length)slide.transition='wipe';else if(descendants(tr,'dissolve').length)slide.transition='dissolve';slide.transitionDuration=tr.getAttribute('spd')==='fast'?.3:tr.getAttribute('spd')==='slow'?1.3:.55;}const m=file.match(/slide(\d+)\.xml$/),n=m?.[1],sr= n?`ppt/slides/_rels/slide${n}.xml.rels`:'';let picMap={};if(files[sr]){const root=dxml(zipText(files,sr));for(const r of descendants(root,'Relationship'))picMap[attr(r,'Id')]=attr(r,'Target');}
 const tree=descendants(doc,'spTree')[0];const animationIds={};const sourceNodes=[];
 function visitGroup(node,groupId='',transform={sx:1,sy:1,dx:0,dy:0}){
  for(const child of Array.from(node?.children||[])){
   if(child.localName==='grpSp'){
    const id=attr(descendants(child,'cNvPr')[0],'id')||('grp-'+sourceNodes.length);
    const gp=Array.from(child.children).find(x=>x.localName==='grpSpPr');const xform=firstDirect(gp,'xfrm');
    const off=firstDirect(xform,'off'),ext=firstDirect(xform,'ext'),chOff=firstDirect(xform,'chOff'),chExt=firstDirect(xform,'chExt');
    let next=transform;
    if(off&&ext&&chOff&&chExt){
     const sx=Number(attr(ext,'cx'))/Math.max(1,Number(attr(chExt,'cx'))),sy=Number(attr(ext,'cy'))/Math.max(1,Number(attr(chExt,'cy')));
     next={sx:transform.sx*sx,sy:transform.sy*sy,dx:transform.sx*(Number(attr(off,'x'))-Number(attr(chOff,'x'))*sx)+transform.dx,dy:transform.sy*(Number(attr(off,'y'))-Number(attr(chOff,'y'))*sy)+transform.dy};
    }
    visitGroup(child,'pptx-group-'+id,next);
   }else if(['sp','pic','cxnSp','graphicFrame'].includes(child.localName))sourceNodes.push({child,groupId,transform});
  }
 }
 visitGroup(tree);for(const {child,groupId,transform} of sourceNodes){
 if(child.localName==='graphicFrame'){
  const cref=descendants(child,'chart')[0],cRid=cref?.getAttribute('r:id')||cref?.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
  let cpath=picMap[cRid];if(!cpath||!cpath.includes('/charts/'))continue;
  cpath='ppt/charts/'+cpath.split('/').pop();if(!files[cpath])continue;
  const cdoc=dxml(zipText(files,cpath)),chartNode=descendants(cdoc,'chart')[0],chartSeriesNodes=descendants(chartNode,'ser');if(!chartSeriesNodes.length)continue;
  const ctype=descendants(chartNode,'doughnutChart').length?'doughnut':descendants(chartNode,'pieChart').length?'pie':descendants(chartNode,'lineChart').length?'line':descendants(chartNode,'barChart').length?(attr(descendants(chartNode,'grouping')[0],'val')==='stacked'?'stacked':'bar'):'bar';
  const ptsOf=(root)=>{const pts=descendants(root,'pt'),max=Math.max(-1,...pts.map(p=>Number(attr(p,'idx',-1))));const vals=Array(Math.min(100,max+1)).fill(null);for(const p of pts){const i=Number(attr(p,'idx',-1));if(i>=0&&i<100)vals[i]=descendants(p,'v')[0]?.textContent??null;}return vals};
  const catNode=descendants(chartSeriesNodes[0],'cat')[0],catCache=descendants(catNode,'strCache')[0]||descendants(catNode,'numCache')[0];
  let categories=catCache?ptsOf(catCache).map(v=>String(v??'')):[];
  const chartSeries=chartSeriesNodes.map((sr,i)=>{const valNode=descendants(sr,'val')[0],numCache=descendants(valNode,'numCache')[0];const txNode=descendants(sr,'tx')[0],nm=descendants(txNode,'v')[0]?.textContent||`계열 ${i+1}`;const col=colorFrom(descendants(sr,'spPr')[0],['#367bda','#17a398','#905cdc','#ea8734'][i%4]);return {name:nm,color:col,values:numCache?ptsOf(numCache).map(v=>v===null?null:Number(v)):[]}});
  if(!categories.length)categories=chartSeries[0].values.map((_,i)=>`항목 ${i+1}`);
  const e=shape('chart');const xfrm=descendants(child,'xfrm')[0],off=descendants(xfrm,'off')[0],ext=descendants(xfrm,'ext')[0];if(!off||!ext)continue;
  e.x=+attr(off,'x',0)/cw*W;e.y=+attr(off,'y',0)/ch*H;e.w=+attr(ext,'cx',0)/cw*W;e.h=+attr(ext,'cy',0)/ch*H; if(groupId){e._pptxTransform=transform;e.x=(Number(attr(off,'x',0))*transform.sx+transform.dx)/cw*W;e.y=(Number(attr(off,'y',0))*transform.sy+transform.dy)/ch*H;e.w=Number(attr(ext,'cx',0))*transform.sx/cw*W;e.h=Number(attr(ext,'cy',0))*transform.sy/ch*H;}
  e.chartType=ctype;e.chartSeries=chartSeries;e.chartData=categories.map((label,i)=>({label,value:chartSeries[0]?.values[i]??null}));
  e.chartTitle=descendants(descendants(chartNode,'title')[0],'t').map(t=>t.textContent).join('')||'';
  e.chartColor=chartSeries[0].color;
  const lpos=attr(descendants(chartNode,'legendPos')[0],'val');e.chartLegend=descendants(chartNode,'legend').length?({t:'top',b:'bottom',l:'left',r:'right'}[lpos]||'bottom'):'none';
  e.chartDataLabels=descendants(chartNode,'dLbls').some(node=>attr(descendants(node,'showVal')[0],'val')==='1');
  const catAx=descendants(chartNode,'catAx')[0],valAx=descendants(chartNode,'valAx')[0];
  e.chartShowXAxis=attr(descendants(catAx,'delete')[0],'val')!=='1';e.chartShowYAxis=attr(descendants(valAx,'delete')[0],'val')!=='1';
  e.chartGridlines=!!descendants(valAx,'majorGridlines').length;
  const amin=descendants(valAx,'min')[0],amax=descendants(valAx,'max')[0];if(amin)e.chartAxisMin=Number(attr(amin,'val'));if(amax)e.chartAxisMax=Number(attr(amax,'val'));
  const cid=attr(descendants(child,'cNvPr')[0],'id');if(cid){e._pptxShapeId=cid;animationIds[cid]=e.id;}if(groupId)e.groupId=groupId;slide.elements.push(e);continue;
 }
 if(!['sp','pic','cxnSp'].includes(child.localName))continue;const xfrm=descendants(child,'xfrm')[0],off=descendants(xfrm,'off')[0],ext=descendants(xfrm,'ext')[0];if(!off||!ext)continue;const e=shape('text');e.x=+attr(off,'x',0)/cw*W;e.y=+attr(off,'y',0)/ch*H;e.w=+attr(ext,'cx',0)/cw*W;e.h=+attr(ext,'cy',0)/ch*H; if(groupId){e._pptxTransform=transform;e.x=(Number(attr(off,'x',0))*transform.sx+transform.dx)/cw*W;e.y=(Number(attr(off,'y',0))*transform.sy+transform.dy)/ch*H;e.w=Number(attr(ext,'cx',0))*transform.sx/cw*W;e.h=Number(attr(ext,'cy',0))*transform.sy/ch*H;}
 if(child.localName==='cxnSp'){
  e.type='line';e.stroke=colorFrom(descendants(child,'ln')[0],'#4b648b');e.fill='transparent';e.strokeWidth=3;
 }
 else if(child.localName==='pic'){const blip=descendants(child,'blip')[0],rid=blip?.getAttribute('r:embed'),target=picMap[rid];if(!target)continue;let name=target.split('/').pop(),data=files['ppt/media/'+name];if(!data)continue;const mime=name.toLowerCase().endsWith('.png')?'image/png':'image/jpeg';let bin='';for(let i=0;i<data.length;i+=8192)bin+=String.fromCharCode(...data.subarray(i,i+8192));e.type='image';e.src=`data:${mime};base64,${btoa(bin)}`;}
 else {const texts=descendants(child,'p').map(p=>descendants(p,'t').map(t=>t.textContent).join(''));e.text=texts.join('\n');const geom=descendants(child,'prstGeom')[0],preset=attr(geom,'prst','rect');e.type=descendants(child,'cNvSpPr')[0]?.getAttribute('txBox')==='1'?'text':({ellipse:'ellipse',roundRect:'rounded',star5:'star',rightArrow:'arrow'})[preset]||'rect';const spPr=descendants(child,'spPr')[0];e.fill=descendants(spPr,'noFill').length?'transparent':colorFrom(spPr,e.type==='text'?'transparent':'#6c70f5');const rPr=descendants(child,'rPr')[0];if(rPr){e.fontSize=pptFontSizeToPx(+attr(rPr,'sz',2250));e.bold=attr(rPr,'b')==='1';e.color=colorFrom(rPr,'#15243b');e.italic=attr(rPr,'i')==='1';e.fontFamily=attr(descendants(rPr,'ea')[0],'typeface')||attr(descendants(rPr,'latin')[0],'typeface')||'Arial';}const paragraphNodes=descendants(child,'p');const parsedRuns=[];
 paragraphNodes.forEach((para,pi)=>{
  if(pi)parsedRuns.push({text:'\n'});
  for(const rr of Array.from(para.children||[])){
   if(rr.localName==='br'){parsedRuns.push({text:'\n'});continue}
   if(rr.localName!=='r')continue;
   const textNode=descendants(rr,'t')[0];if(!textNode)continue;
   const run={text:textNode.textContent||''};const rp=descendants(rr,'rPr')[0];
   if(rp){if(rp.hasAttribute('sz'))run.fontSize=pptFontSizeToPx(+rp.getAttribute('sz'));
    if(rp.hasAttribute('b'))run.bold=rp.getAttribute('b')==='1';
    if(rp.hasAttribute('i'))run.italic=rp.getAttribute('i')==='1';
    if(rp.hasAttribute('u'))run.underline=rp.getAttribute('u')!=='none';
    const fam=attr(descendants(rp,'ea')[0],'typeface')||attr(descendants(rp,'latin')[0],'typeface');if(fam)run.fontFamily=fam;
    run.color=colorFrom(rp,e.color);
   }
   parsedRuns.push(run);
  }
 });
 if(parsedRuns.length>0){e.runs=mergeRuns(parsedRuns);e.text=e.runs.map(r=>r.text).join('');}
 const pPr=descendants(child,'pPr')[0];e.align=attr(pPr,'algn')==='ctr'?'center':attr(pPr,'algn')==='r'?'right':'left';
 const bodyPr=descendants(child,'bodyPr')[0];if(bodyPr){
  e.textMarginX=emuToPx(+attr(bodyPr,'lIns',e.type==='text'?38100:0));
  e.textMarginY=emuToPx(+attr(bodyPr,'tIns',e.type==='text'?19050:0));
  e.verticalAlign=attr(bodyPr,'anchor')==='ctr'?'middle':attr(bodyPr,'anchor')==='b'?'bottom':'top';
  e.textAutoFit=descendants(bodyPr,'normAutofit').length?'shrink':descendants(bodyPr,'spAutoFit').length?'resize':'none';
 }
 const spc=descendants(pPr,'spcPct')[0];if(spc)e.lineSpacing=Number(attr(spc,'val',120000))/100000;
}const cid=attr(descendants(child,'cNvPr')[0],'id');if(cid){e._pptxShapeId=cid;animationIds[cid]=e.id;}if(groupId)e.groupId=groupId;slide.elements.push(e);}
 slide.timeline=NativeMotion.readTiming(doc,animationIds);result.slides.push(slide);}
 if(!result.slides.length)result.slides=[makeSlide()];
 // Read basic master text/shape geometry independently; original master XML is
 // still preserved unchanged in the external package preservation path.
 const masterPath=Object.keys(files).find(k=>/^ppt\/slideMasters\/slideMaster\d+\.xml$/.test(k));
 if(masterPath){try{
  const mdoc=dxml(zipText(files,masterPath));const mtree=descendants(mdoc,'spTree')[0];
  for(const child of Array.from(mtree?.children||[])){
   if(child.localName!=='sp')continue;
   const xfrm=descendants(child,'xfrm')[0],off=descendants(xfrm,'off')[0],ext=descendants(xfrm,'ext')[0];if(!off||!ext)continue;
   const e=shape('text');e.x=Number(attr(off,'x'))/cw*W;e.y=Number(attr(off,'y'))/ch*H;e.w=Number(attr(ext,'cx'))/cw*W;e.h=Number(attr(ext,'cy'))/ch*H;
   const text=descendants(child,'p').map(p=>descendants(p,'t').map(t=>t.textContent).join('')).join('\n');e.text=text;
   const preset=attr(descendants(child,'prstGeom')[0],'prst','rect');e.type=attr(descendants(child,'cNvSpPr')[0],'txBox')==='1'?'text':({ellipse:'ellipse',roundRect:'rounded',star5:'star',rightArrow:'arrow'})[preset]||'rect';
   e.fill=descendants(descendants(child,'spPr')[0],'noFill').length?'transparent':colorFrom(descendants(child,'spPr')[0],e.type==='text'?'transparent':'#6c70f5');
   const rp=descendants(child,'rPr')[0];if(rp){e.fontSize=pptFontSizeToPx(Number(attr(rp,'sz',1800)));e.fontFamily=attr(descendants(rp,'latin')[0],'typeface','Arial');e.color=colorFrom(rp,e.color);e.bold=attr(rp,'b')==='1';}
   const cid=attr(descendants(child,'cNvPr')[0],'id');if(cid)e._pptxShapeId=cid;
   result.master.elements.push(e);
  }
 }catch(e){console.warn('Master basic import skipped:',e)}}
 result._importFidelity='external-approximate';return result;}


// Basic end-to-end package safety check before offering an exported PPTX download.
export async function verifyPptx(bytes,expectedSlides){
 const entries=await zipRead(bytes);
 for(const part of ['[Content_Types].xml','_rels/.rels','ppt/presentation.xml','ppt/_rels/presentation.xml.rels','ppt/slideMasters/slideMaster1.xml','ppt/theme/theme1.xml']){
  if(!entries[part])throw Error('PPTX 필수 구성요소 누락: '+part);
 }
 const parsable=Object.entries(entries).filter(([path])=>path.endsWith('.xml')||path.endsWith('.rels')||path==='[Content_Types].xml');
 for(const [path,contents] of parsable){const doc=dxml(new TextDecoder().decode(contents));if(doc.querySelector('parsererror'))throw Error('PPTX XML 형식 오류: '+path)}
 const presentation=dxml(zipText(entries,'ppt/presentation.xml'));
 const count=descendants(presentation,'sldId').length;
 if(count!==expectedSlides)throw Error(`PPTX 슬라이드 수 불일치: ${count} / ${expectedSlides}`);
 // Validate the OPC part graph: broken relationships are a common reason Office
 // offers to repair or refuses to open a downloaded PPTX.
 const resolvePart=(base,target)=>{
  const parts=(target.startsWith('/')?[]:base.split('/').slice(0,-1)).concat(target.split('/'));
  const stack=[];for(const part of parts){if(part==='.'||!part)continue;if(part==='..')stack.pop();else stack.push(part)}
  return stack.join('/');
 };
 for(const [relsPath,reldata] of Object.entries(entries).filter(([name])=>name.endsWith('.rels'))){
  const relFile=relsPath==='_rels/.rels'?'':relsPath.replace(/(^|\/)\_rels\//,'$1').replace(/\.rels$/,'');
  const doc=dxml(new TextDecoder().decode(reldata));
  const ids=new Set();
  for(const r of descendants(doc,'Relationship')){
   const id=attr(r,'Id'),target=attr(r,'Target');
   if(!id||ids.has(id))throw Error('PPTX 관계 ID 중복 또는 누락: '+relsPath);
   ids.add(id);
   if(attr(r,'TargetMode')==='External')continue;
   if(!entries[resolvePart(relFile,target)])throw Error(`PPTX 관계 대상 누락: ${relsPath} → ${target}`);
  }
 }
 // Validate key ECMA-376 constraints; these are semantic constraints, not merely well-formed XML.
 const theme=dxml(zipText(entries,'ppt/theme/theme1.xml'));
 const scheme=descendants(theme,'fmtScheme')[0];
 if(!scheme)throw Error('PPTX 테마의 형식 지정 정보 누락');
 for(const [listName,required] of [['fillStyleLst',3],['lnStyleLst',3],['effectStyleLst',3],['bgFillStyleLst',3]]){
  const list=descendants(scheme,listName)[0];
  if(!list||list.children.length<required)throw Error(`PPTX 테마 스키마 오류: ${listName}은 최소 ${required}개 필요`);
 }
 for(const [path,payload] of Object.entries(entries).filter(([path])=>/^ppt\/slides\/slide\d+\.xml$/.test(path))){
  const root=dxml(new TextDecoder().decode(payload)).documentElement;
  const order=Array.from(root.children,c=>c.localName);
  const clr=order.indexOf('clrMapOvr'),trans=order.indexOf('transition');
  if(trans>=0&&(clr<0||clr>trans))throw Error(`PPTX 요소 순서 오류: ${path} transition 앞에 clrMapOvr 필요`);
 }
 const slides=Object.keys(entries).filter(k=>/^ppt\/slides\/slide\d+\.xml$/.test(k));
 if(slides.length!==count)throw Error('PPTX 슬라이드 구성요소 누락');
 for(const path of slides){
  const xml=zipText(entries,path);
  if(!descendants(dxml(xml),'spTree').length)throw Error('PPTX 슬라이드 도형 구조 누락: '+path);
 }
 return {slides:count,bytes:bytes.length,hasNativeSnapshot:!!readAsterSnapshot(entries)};
}
