import {loadPrefs,savePrefs,createRecovery,matchCommands,thumbnailRange,contextActions} from './workspace.js';
import {Store,makeDeck,makeDemoDeck,makeChart,clone,shape,uid,addSlide,removeSlide,moveSlide,effectiveBg,allElements,downloadBlob,safeFileName,W,H} from './core.js';
import {exportPptx,importPptx,verifyPptx} from './pptx.js';
import {exportPreservedPptx,preservationReport} from './preserve.js';
import * as ChartData from './chart-data.js';
import * as NativeChart from './native-chart.js';
import {textLayout} from './text-layout.js';
import {textRuns,patchElement,setUniform,runStyle,mergeRuns} from './rich-text.js';
import * as Arrange from './arrange.js';
import * as Smart from './smart-layout.js';
import * as Diagnostics from './diagnostics.js';
import * as Motion from './timeline.js';
import * as Studios from './studios.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const limit=(v,a,b)=>Math.max(a,Math.min(b,v));
const store=new Store(makeDemoDeck());const selectedIds=new Set();let active=store.deck.slides[0].id,selected=null,tab='home',zoom=.7,autoFit=true,grid=false,isShowing=false,showIndex=0,drag=null,clipboard=null,composition=false,slideFocused=false,masterMode=false,showReveal=0,motionSelected=null,motionSelectedIds=new Set(),motionClipboard=[],timelineZoom=1,timelineCursor=null,timelineOpen=true,showAnimations=[],sourcePptx=null,editing=null,rangeCache=null,fontOpen=false,fontQuery='',fontFilter='all', inspectorVisible=false,inspectorFilter='all',inspectorSlideOnly=false,pendingIssueId=null,studioPanel=null,studioScope='current',compareReference=null,compareName='',studioFilter='all';
let browserStore=null;try{browserStore=window.localStorage}catch{}
const blockedStore={getItem:()=>null,setItem:()=>{throw Error('storage unavailable')},removeItem:()=>{throw Error('storage unavailable')}};
const prefs=loadPrefs(browserStore||blockedStore),recovery=createRecovery(browserStore||blockedStore);
let recoveryTimer=null,recoveryDirty=false,recoveryError='',dirtySinceExport=false,suppressRecovery=false,recoveryIndex=0,thumbRowHeight=121,thumbWindow='',diagnosticDeck=null,diagnosticIssues=[];
function updateRecoveryIndicator(){const count=recovery.list().length;const b=$('#recoveryIndicator');if(b){b.hidden=!count;b.textContent='↺ 복구 '+count;}}
function persistPreferences(){savePrefs(browserStore||blockedStore,prefs)}
function applyPreferences(){document.body.dataset.asterTheme=prefs.theme;const ws=$('.workspace');ws.style.setProperty('--left-pane',prefs.leftWidth+'px');ws.style.setProperty('--right-pane',prefs.rightWidth+'px');ws.classList.toggle('slides-collapsed',prefs.slidesCollapsed);const toggle=$('#slidesToggle');toggle.setAttribute('aria-expanded',String(!prefs.slidesCollapsed));toggle.setAttribute('aria-label',prefs.slidesCollapsed?'슬라이드 패널 펼치기':'슬라이드 패널 접기');}
function flushRecovery(){clearTimeout(recoveryTimer);recoveryTimer=null;if(!recoveryDirty||!prefs.recoveryEnabled)return;
 const result=recovery.write(store.deck);if(result.ok){recoveryDirty=false;recoveryError='';updateRecoveryIndicator()}else{recoveryError=result.reason==='too-large'?'문서가 커서 복구 기록을 저장하지 못했어. 프로젝트를 직접 저장해 줘.':'브라우저 저장 공간 부족 · 파일로 직접 저장해 줘.';$('#footLeft').textContent=recoveryError;}}
function scheduleRecovery(){if(!prefs.recoveryEnabled||suppressRecovery)return;recoveryDirty=true;clearTimeout(recoveryTimer);recoveryTimer=setTimeout(flushRecovery,1100)}
function renderRecovery(){const entries=recovery.list();$('#recoveryList').innerHTML=entries.length?entries.map((x,i)=>`<div class="recovery-row"><div class="recovery-info"><b>${esc(x.title)}</b><small>${new Date(x.savedAt).toLocaleString('ko-KR')} · 슬라이드 ${x.slideCount}장 · ${(x.bytes/1024).toFixed(1)}KB</small></div><button class="recovery-restore" data-recovery-open="${esc(x.id)}">복구</button><button data-recovery-export="${esc(x.id)}">백업</button><button data-recovery-delete="${esc(x.id)}">삭제</button></div>`).join(''):'<div class="command-empty">저장된 복구 기록이 없어.</div>';$('#enableRecovery').checked=prefs.recoveryEnabled;}
function showRecoveries(){flushRecovery();renderRecovery();updateRecoveryIndicator();$('#recoveryDialog').showModal()}
const COMMAND_OPTIONS=[
 ['file.new','새 프레젠테이션','Ctrl+N'],['file.open','파일 불러오기','Ctrl+O'],['file.exportJson','Aster 프로젝트 저장'],['file.exportPptx','PowerPoint 파일로 저장','Ctrl+S'],['file.exportPptxNative','편집용 PPTX 저장'],['file.exportPng','슬라이드 PNG 내보내기'],
 ['slide.add','새 슬라이드 추가','Ctrl+M'],['slide.duplicate','현재 슬라이드 복제'],['slide.delete','슬라이드 삭제','Delete'],['edit.undo','실행 취소','Ctrl+Z'],['edit.redo','다시 실행','Ctrl+Y'],
 ['insert.text','텍스트 상자 삽입'],['insert.rect','사각형 삽입'],['insert.image','이미지 삽입'],['insert.chart','차트 삽입'],['object.group','그룹화','Ctrl+G'],['object.ungroup','그룹 해제','Ctrl+Shift+G'],['object.alignCenter','개체 가로 중앙 정렬'],['object.distributeX','개체 가로 간격 배분'],
 ['font.explorer','글꼴 탐색기'],['studio.open','디자인 스튜디오'],['fontlab.open','Font Lab'],['data.open','Live Data'],['review.open','호환성 및 디자인 검사'],['view.fit','캔버스 맞춤'],['view.grid','그리드 표시'],['show.start','슬라이드 쇼','F5'],['ui.theme','다크 / 라이트 모드'],['ui.recovery','작업 복구 및 복구 설정'],['ui.slides','슬라이드 패널 접기 / 펼치기']
].map(([id,label,shortcut])=>({id,label,shortcut}));
let paletteItems=[],paletteIndex=0;
function renderPalette(){paletteItems=matchCommands(COMMAND_OPTIONS,$('#commandQuery').value);paletteIndex=Math.min(paletteIndex,Math.max(0,paletteItems.length-1));$('#commandResults').innerHTML=paletteItems.length?paletteItems.map((x,i)=>`<button type="button" class="command-result" data-palette-idx="${i}" role="option" aria-selected="${i===paletteIndex}"><span>${esc(x.label)}</span><kbd>${esc(x.shortcut||'↵')}</kbd></button>`).join(''):'<div class="command-empty">일치하는 명령이 없어.</div>'}
function openPalette(){const dlg=$('#commandPalette');if(dlg.open)return;dlg.showModal();$('#commandQuery').value='';paletteIndex=0;renderPalette();$('#commandQuery').focus()}
function paletteRun(idx){const x=paletteItems[idx];if(!x)return;$('#commandPalette').close();command(x.id)}
const currentSlide=()=>store.deck.slides.find(s=>s.id===active)||store.deck.slides[0];
const slide=()=>masterMode?store.deck.master:currentSlide(), el=()=>slide()?.elements.find(e=>e.id===selected);
const selection=()=>Arrange.picked(slide()?.elements||[],selectedIds);
const canChangeSelection=()=>Arrange.canEdit(selection());
function selectObject(id,extend=false){
 const target=slide()?.elements.find(e=>e.id===id);if(!target)return;
 const bundle=Arrange.picked(slide().elements,[id]).map(e=>e.id);
 if(!extend){selectedIds.clear();bundle.forEach(k=>selectedIds.add(k));selected=id}
 else {const remove=bundle.every(k=>selectedIds.has(k));for(const k of bundle)remove?selectedIds.delete(k):selectedIds.add(k);selected=selectedIds.has(id)?id:([...selectedIds].at(-1)||null)}
 rangeCache=null;
}
function clearSelection(){selected=null;selectedIds.clear();rangeCache=null}
function ensureSelected(){const available=new Set(slide()?.elements.map(e=>e.id)||[]);for(const id of selectedIds)if(!available.has(id))selectedIds.delete(id);
 if(selected&&!available.has(selected))selected=null;
 if(selected&&!selectedIds.has(selected))selectedIds.add(selected);
 if(!selected&&selectedIds.size)selected=[...selectedIds].at(-1)}
function selectAllObjects(){selectedIds.clear();for(const e of slide().elements)selectedIds.add(e.id);selected=[...selectedIds].at(-1)||null;renderStage();renderProps();renderRibbon()}
function objectOperation(action,required=1){if(selection().length<required){statusMsg(required===3?'개체 3개 이상을 선택해 줘':'개체를 먼저 선택해 줘');return false}if(!canChangeSelection()){statusMsg('잠긴 개체가 포함돼 있어. 잠금을 먼저 해제해 줘.');return false}
 let result=false;editCurrent(s=>{result=action(s)});return result}

const update=fn=>store.execute(d=>{fn(d);for(const slide of d.slides)Motion.cleanTimeline(slide)});const editCurrent=fn=>update(d=>{const s=masterMode?d.master:d.slides.find(s=>s.id===active);if(s)fn(s,d)});
const iconPaths={
 plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',redo:'<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
 folder:'<path d="M3 8V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 10h18"/>',save:'<path d="M4 4h13l3 3v13H4z"/><path d="M8 4v7h8V4M8 20v-6h8v6"/>',download:'<path d="M12 3v12m-5-5 5 5 5-5M4 18v3h16v-3"/>',play:'<path d="m8 5 11 7-11 7z"/>',
 slide:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 13h7M7 16h4"/>',duplicate:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16H3V4h12v1"/>',trash:'<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 10v7M14 10v7"/>',
 text:'<path d="M4 6V4h16v2M12 4v16m-5 0h10"/>',rect:'<rect x="4" y="5" width="16" height="14" rx="1"/>',rounded:'<rect x="4" y="5" width="16" height="14" rx="5"/>',ellipse:'<ellipse cx="12" cy="12" rx="9" ry="7"/>',star:'<path d="m12 2 3 7 7 .5-5.3 5 1.7 7-6.4-3.6-6.4 3.6 1.7-7-5.3-5L9 9z"/>',arrow:'<path d="M3 9h11V5l7 7-7 7v-4H3z"/>',line:'<path d="M4 18 20 6"/>',image:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m3 18 6-6 4 4 3-3 5 5"/>',
 front:'<rect x="7" y="4" width="13" height="13" rx="1"/><path d="M4 9H2v12h13v-2"/>',back:'<rect x="2" y="4" width="13" height="13" rx="1"/><path d="M17 7h4v14H8v-2"/>',bold:'<path d="M6 4h7a4 4 0 0 1 0 8H6zm0 8h8a4 4 0 0 1 0 8H6z"/>',italic:'<path d="M11 4h9M4 20h9M15 4 9 20"/>',alignleft:'<path d="M4 6h15M4 10h10M4 14h15M4 18h10"/>',aligncenter:'<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>',alignright:'<path d="M5 6h15M10 10h10M5 14h15M10 18h10"/>',
 palette:'<path d="M12 3a9 9 0 0 0 0 18h2a2 2 0 0 0 1.5-3.3A2.6 2.6 0 0 1 17 13h1a3 3 0 0 0 3-3c0-4-4.2-7-9-7z"/><circle cx="7" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="16" cy="7" r="1"/>',grid:'<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M9 3v18m6-18v18M3 9h18M3 15h18"/>',fit:'<path d="M9 3H3v6m12-6h6v6m0 6v6h-6M3 15v6h6"/>',note:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 9h8M8 13h8M8 17h5"/>',
 close:'<path d="M5 5 19 19M19 5 5 19"/>','arrow-right':'<path d="M5 12h14m-6-6 6 6-6 6"/>','arrow-left':'<path d="M19 12H5m6-6-6 6 6 6"/>',up:'<path d="M12 19V5m-6 6 6-6 6 6"/>',down:'<path d="M12 5v14m-6-6 6 6 6-6"/>',
 layout:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M11 10v10"/>',new:'<path d="M12 4H4v16h16v-8M13 7h8m-4-4v8"/>',check:'<path d="m4 12 5 5L20 6"/>',png:'<path d="M4 4h12l4 4v12H4zM16 4v4h4M7 16l3-3 3 3 3-2 3 3"/>',lock:'<rect x=5 y=10 width=14 height=11 rx=2/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',unlock:'<rect x=5 y=10 width=14 height=11 rx=2/><path d="M8 10V7a4 4 0 0 1 8 0m0-2V7"/>',group:'<rect x=2 y=8 width=10 height=10/><rect x=12 y=5 width=10 height=10/>',rotate:'<path d="M4 11a8 8 0 1 1 4 7M4 5v6h6"/>'
};
function icon(n){return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${iconPaths[n]||iconPaths.rect}</svg>`}
function tool(label,cmd,ico,extra=''){return `<button class="tool ${extra}" data-command="${cmd}" title="${esc(label)}">${icon(ico)}<span>${esc(label)}</span></button>`}
function group(label,content){return `<div class="ribbon-group" data-label="${esc(label)}">${content}</div>`}
function field(label,prop,value,type='text'){return `<div class="field"><label>${esc(label)}</label><input data-prop="${prop}" type="${type}" value="${esc(value)}"></div>`}
const FONT_KO=['맑은 고딕','맑은 고딕 Semilight','나눔고딕','나눔명조','Noto Sans KR','Noto Serif KR','Pretendard','본고딕','바탕','굴림','돋움','궁서','함초롬바탕','Apple SD Gothic Neo'];
const FONT_EN=['Arial','Arial Narrow','Calibri','Aptos','Aptos Display','Segoe UI','Verdana','Tahoma','Georgia','Times New Roman','Trebuchet MS','Courier New','Consolas','Garamond','Cambria','Impact','Helvetica','Roboto','Inter','Montserrat'];
const FONT_CHOICES=[...FONT_KO,...FONT_EN];
let favoriteFonts=new Set(),recentFonts=[];
try{favoriteFonts=new Set(JSON.parse(localStorage.getItem('aster.fonts.favorite')||'[]'));recentFonts=JSON.parse(localStorage.getItem('aster.fonts.recent')||'[]')}catch{}
const rememberFont=()=>{try{localStorage.setItem('aster.fonts.favorite',JSON.stringify([...favoriteFonts]));localStorage.setItem('aster.fonts.recent',JSON.stringify(recentFonts))}catch{}};

const fontCss=f=>"'"+String(f||'Arial').replace(/[\'"\\;{}]/g,'').slice(0,120)+"'";
const colorPalette=['#ffffff','#203653','#3779d1','#23aa86','#ee7626','#9560d8','#ef6389','#f3ca55','#17263f','#64748b'];
function colorDots(prop){return `<div class="quick-colors">${colorPalette.map(c=>`<button style="background:${c}" title="${c}" data-color-prop="${prop}" data-color="${c}"></button>`).join('')}<button class="no-fill" title="색상 없음 (투명)" data-color-prop="${prop}" data-color="transparent">없음</button></div>`}
const statusMsg=msg=>{const t=$('#toast');t.textContent=msg;t.classList.add('visible');clearTimeout(statusMsg.timer);statusMsg.timer=setTimeout(()=>t.classList.remove('visible'),2700)};
function auditIssues(){if(diagnosticDeck!==store.deck){diagnosticDeck=store.deck;diagnosticIssues=Diagnostics.scanDeck(store.deck)}return diagnosticIssues}
function filteredIssues(){return auditIssues().filter(x=>(inspectorFilter==='all'||x.category===inspectorFilter)&&(!inspectorSlideOnly||x.slideId===active))}
function activateInspector(filter='all'){
 studioPanel=null;inspectorVisible=true;inspectorFilter=filter;
 render();statusMsg('문서 진단 완료 · 오른쪽 패널에서 문제를 선택해 봐');
}
function inspectGo(id){const item=auditIssues().find(x=>x.id===id);if(!item)return;
 masterMode=false;active=item.slideId;clearSelection();if(item.elementId)selectObject(item.elementId);
 render();const row=[...document.querySelectorAll('[data-diag-jump]')].find(x=>x.dataset.diagJump===id);row?.scrollIntoView({block:'nearest'});
 statusMsg(item.elementId?'문제 개체를 선택했어':'해당 슬라이드로 이동했어');
}
function renderInspector(p){
 const oldScroll=p.scrollTop;
 const issues=filteredIssues(),all=auditIssues(),totals=Diagnostics.summary(all),itemCounts={compat:all.filter(x=>x.category==='compat').length,design:all.filter(x=>x.category==='design').length};
 $('#propsTitle').textContent='문서 진단';$('#inspectorToggle').textContent='속성';
 const chips=`<div class="audit-filters">${[['all','전체'],['compat','PPTX 호환'],['design','디자인']].map(([k,l])=>`<button data-diag-filter="${k}" class="${inspectorFilter===k?'active':''}">${l}${k==='all'?'':` ${itemCounts[k]}`}</button>`).join('')}</div>`;
 const issueRows=issues.map(item=>{const index=store.deck.slides.findIndex(x=>x.id===item.slideId)+1;const name=store.deck.slides[index-1]?.name||'슬라이드';return `<article class="audit-issue ${item.severity}" data-issue-id="${esc(item.id)}"><div class="audit-issue-meta"><span class="severity-tag">${{error:'높음',warning:'주의',info:'안내'}[item.severity]}</span><span>${esc(Diagnostics.groups?.[item.category]|| (item.category==='compat'?'PPTX 호환성':'디자인'))}</span><span>슬라이드 ${index}</span></div><button class="audit-issue-title" data-diag-jump="${esc(item.id)}">${esc(item.title)} ↗</button><p>${esc(item.detail)}</p><div class="audit-issue-buttons"><button data-diag-jump="${esc(item.id)}">위치 보기</button>${item.fix?`<button class="audit-fix" data-diag-fix="${esc(item.id)}">수정 적용</button>`:''}<button data-diag-ignore="${esc(item.id)}">제외</button></div></article>`}).join('');
 const preserved=sourcePptx&&!sourcePptx.native?preservationReport(sourcePptx.deck,store.deck):null;
 p.innerHTML=`${preserved?`<div class="audit-preservation"><b>원본 PPTX 보존 검사: ${preserved.safe?'안전한 부분 수정 가능':'호환본 재생성 필요'}</b><p>${preserved.safe?'변경하지 않은 PPTX 파트를 원본 데이터로 유지해.':esc(preserved.issues.slice(0,2).join(' / '))}</p></div>`:''}<div class="audit-overview"><div class="audit-eyebrow">ASTER / DOCUMENT HEALTH</div><h3>Compatibility Inspector</h3><p>슬라이드 전체를 분석해 PPTX 출력 위험과 디자인 문제를 확인해. 이 검사는 추정값이며 PowerPoint의 실제 렌더링 검증을 대체하지 않아.</p><div class="audit-score"><div><strong>${totals.total}</strong><small>검토 항목</small></div><div><strong class="audit-error">${totals.error}</strong><small>높음</small></div><div><strong class="audit-warning">${totals.warning}</strong><small>주의</small></div><div><strong>${totals.info}</strong><small>안내</small></div></div></div><div class="audit-toolbar">${chips}<label class="audit-slide-only"><input type="checkbox" id="auditCurrentOnly" ${inspectorSlideOnly?'checked':''}> 현재 슬라이드만</label><div class="audit-inline-actions"><button data-command="review.recheck">다시 검사</button><button data-command="review.clearIgnored">제외 목록 초기화</button></div></div><div class="audit-results" aria-live="polite">${issueRows||`<div class="audit-clear"><span>✓</span><b>해당 조건의 검사 항목이 없어</b><p>문제를 찾지 못했다는 의미이며, 모든 PPTX 호환성을 보증하지는 않아.</p></div>`}</div><div class="audit-footer">※ 글꼴 사용 가능 여부·PowerPoint 줄바꿈은 환경에 따라 달라. 자동 수정은 누를 때만 적용되며 Ctrl+Z로 취소할 수 있어.</div>`;
 p.scrollTop=oldScroll;
}
function renderRibbon(){
 let r='';
 if(tab==='home')r=group('클립보드',tool('실행 취소','edit.undo','undo')+tool('다시 실행','edit.redo','redo')+tool('복사','edit.copy','duplicate')+tool('붙여넣기','edit.paste','new'))+
 group('슬라이드',tool('새 슬라이드','slide.add','slide','primary')+tool('복제','slide.duplicate','duplicate')+tool('삭제','slide.delete','trash')+tool('제목형','slide.addTitle','layout'))+
 group('텍스트 편집',tool('텍스트','insert.text','text')+tool('굵게','format.bold','bold')+tool('기울임','format.italic','italic')+tool('왼쪽','format.left','alignleft')+tool('가운데','format.center','aligncenter')+`<div class="ribbon-control font-choice"><label>글꼴 탐색기</label><button type="button" class="font-launcher" data-command="font.explorer" aria-label="글꼴 탐색기 열기" ${el()?'':'disabled'}><span>${esc(el()?.fontFamily||'글꼴 선택')}</span> ▾</button></div>`)+
 group('그리기',tool('사각형','insert.rect','rect')+tool('둥근 상자','insert.rounded','rounded')+tool('타원','insert.ellipse','ellipse')+tool('그림','insert.image','image')+tool('차트','insert.chart','grid')+tool('채우기 없음','format.noFill','close'))+
 group('배열',tool('앞으로','object.front','front')+tool('뒤로','object.back','back')+tool('개체 복제','object.duplicate','duplicate'));
 else if(tab==='insert')r=group('텍스트',tool('텍스트 상자','insert.text','text')+tool('제목형','slide.addTitle','layout'))+
 group('도형 갤러리',tool('사각형','insert.rect','rect')+tool('둥근 상자','insert.rounded','rounded')+tool('타원','insert.ellipse','ellipse')+tool('별','insert.star','star')+tool('화살표','insert.arrow','arrow')+tool('선','insert.line','line'))+
 group('스마트 다이어그램',tool('두 도형 연결','connector.add','line')+tool('그리드 자동 배치','smart.grid','grid'))+
 group('데이터와 미디어',tool('이미지','insert.image','image')+tool('차트','insert.chart','grid')+tool('CSV / XLSX 가져오기','chart.import','folder'))+group('레이아웃',tool('빈 슬라이드','slide.add','slide')+tool('2열 콘텐츠','slide.addTwocol','layout')+tool('섹션 표지','slide.addSection','new'));
 else if(tab==='design')r=group('Design Studio',tool('테마 갤러리','studio.open','palette','primary')+tool('타이포그래피 정리','studio.typography','text'))+group('슬라이드 테마',`<div class="ribbon-presets">${[['snow','#ffffff','#203653'],['night','#192e50','#ffffff'],['ocean','#eaf4fe','#284c7c'],['peach','#fff0e5','#a6532b'],['mint','#e6fbf3','#237d68']].map(t=>`<button class="theme-swatch" data-command="design.${t[0]}" style="background:${t[1]};color:${t[2]}" title="${t[0]}"></button>`).join('')}</div>`)+group('배경',`<div class="ribbon-control"><label>선택 슬라이드 배경</label><input type="color" id="ribbonColor" value="${esc(slide().background)}"></div>`)+group('레이아웃',tool('표지','slide.addTitle','layout')+tool('2열','slide.addTwocol','slide')+tool('섹션','slide.addSection','new'));
 else if(tab==='fontlab')r=group('글꼴 관리',tool('사용 현황','fontlab.open','text','primary')+tool('글꼴 탐색기','font.explorer','palette'))+group('글꼴 교체 안내',`<div class="ribbon-helper">오른쪽 패널에서 현재 문서에 사용된 글꼴을 확인하고 모든 슬라이드에서 일괄 교체해.</div>`);
 else if(tab==='data')r=group('Live Data 2.0',tool('데이터 패널','data.open','grid','primary')+tool('CSV / XLSX 가져오기','chart.import','folder')+tool('파일 다시 선택','data.refresh','rotate')+tool('차트를 표로 만들기','data.toTable','grid')+tool('차트 CSV 내보내기','chart.exportCsv','download'));
 else if(tab==='compare')r=group('버전 비교',tool('비교 파일 열기','compare.open','folder','primary')+tool('비교 결과','compare.show','layout')+tool('비교 종료','compare.clear','close'))+group('버전 비교 안내',`<div class="ribbon-helper">원본 문서를 바꾸지 않고 비교해. 오른쪽에서 차이를 확인한 뒤 선택한 슬라이드만 가져올 수 있어.</div>`);
 else if(tab==='animations')r=group('효과 추가',tool('페이드','anim.fade','palette','primary')+tool('날아오기','anim.fly','arrow-right')+tool('확대','anim.zoom','plus')+tool('드러나기','anim.wipe','slide')+tool('회전','anim.spin','rotate')+tool('강조','anim.pulse','star')+tool('흔들기','anim.shake','group')+tool('모션 경로','anim.path','line'))+
 group('시간표 편집',tool('타임라인 표시','timeline.toggle','layout')+tool('현재 효과 삭제','anim.delete','trash')+tool('복사','anim.copy','duplicate')+tool('붙여넣기','anim.paste','new')+tool('반전','anim.reversePath','rotate')+tool('순서 올리기','anim.moveUp','up')+tool('순서 내리기','anim.moveDown','down')+tool('현재 슬라이드 재생','anim.preview','play'))+
 group('슬라이드 전환',tool('없음','transition.none','close')+tool('페이드','transition.fade','palette')+tool('밀어내기','transition.slide','arrow-right')+tool('확대','transition.zoom','plus')+tool('닦아내기','transition.wipe','layout')+tool('디졸브','transition.dissolve','grid'));
 else if(tab==='master')r=group('공통 마스터',tool(masterMode?'슬라이드 편집으로':'마스터 편집으로','master.toggle','layout','primary')+tool('전체 배경 적용','master.backgroundAll','palette')+tool('마스터 배경 해제','master.backgroundOff','close'))+group('마스터 개체',tool('공통 텍스트','insert.text','text')+tool('공통 사각형','insert.rect','rect')+tool('공통 이미지','insert.image','image'))+group('안내',`<div class="ribbon-helper">마스터 편집 모드에서 삽입한 개체가 모든 슬라이드에 표시돼요.</div>`);
 else if(tab==='arrange')r=group('선택·그룹',tool('모두 선택','object.selectAll','group')+tool('그룹화 Ctrl+G','object.group','group')+tool('그룹 해제 Ctrl+Shift+G','object.ungroup','group')+tool('잠금','object.lock','lock')+tool('잠금 해제','object.unlock','unlock'))+
 group('정렬',tool('왼쪽','object.alignLeft','alignleft')+tool('가로 가운데','object.alignCenter','aligncenter')+tool('오른쪽','object.alignRight','alignright')+tool('위쪽','object.alignTop','layout')+tool('세로 가운데','object.alignMiddle','layout')+tool('아래쪽','object.alignBottom','layout'))+
 group('간격 배분',tool('가로 간격','object.distributeX','aligncenter')+tool('세로 간격','object.distributeY','layout'))+
 group('Smart Layout',tool('가로 자동 배치','smart.horizontal','aligncenter')+tool('세로 자동 배치','smart.vertical','layout')+tool('그리드 자동 배치','smart.grid','grid'))+
 group('스마트 연결선',tool('선택한 두 도형 연결','connector.add','line')+tool('직선 연결','connector.straight','line')+tool('직각 연결','connector.elbow','arrow'))+
 group('레이어 순서',tool('한 단계 앞으로','object.forward','front')+tool('한 단계 뒤로','object.backward','back')+tool('맨 앞으로','object.front','front')+tool('맨 뒤로','object.back','back'))+
 group('개체 작업',tool('복제','object.duplicate','duplicate')+tool('삭제','object.delete','trash'));
 else if(tab==='review')r=group('문서 진단',tool('전체 검사','review.open','check','primary')+tool('PPTX 호환성','review.compat','folder')+tool('Design Doctor','review.design','palette'))+group('품질 점검',tool('현재 슬라이드만','review.onlySlide','slide')+tool('다시 검사','review.recheck','rotate'))+group('작업 도움말',`<div class="ribbon-helper">PPTX 출력 전 잠재적 문제를 검사하고 오른쪽에서 개체를 찾아 수정할 수 있어.</div>`);
 else if(tab==='view')r=group('작업 공간',tool('명령 검색 Ctrl+K','ui.palette','folder')+tool('다크 / 라이트','ui.theme','palette')+tool('복구 기록','ui.recovery','save')+tool('슬라이드 패널','ui.slides','layout')+tool('패널 초기화','ui.resetPanes','layout'))+group('편집 화면',tool('화면 맞춤','view.fit','fit')+tool('확대','view.zoomIn','plus')+tool('축소','view.zoomOut','minus')+tool('격자 토글','view.grid','grid',grid?'active':''))+group('슬라이드 쇼',tool('처음부터','show.start','play')+tool('현재부터','show.current','slide'))+group('내보내기',tool('PNG 이미지','file.exportPng','png')+tool('PPTX','file.exportPptx','download'));
 else if(tab==='file')r=group('프레젠테이션',tool('새 문서','file.new','new')+tool('샘플 열기','file.demo','slide')+tool('열기','file.open','folder'))+group('저장 및 내보내기',tool('PPTX 저장 전 검사','review.compat','check')+tool('프로젝트','file.exportJson','save')+tool('PPTX 호환본','file.exportPptx','download')+tool('Aster 편집용 PPTX','file.exportPptxNative','save')+tool('원본 PPTX 백업','file.exportOriginal','folder')+tool('슬라이드 PNG','file.exportPng','png'))+group('안전 복구',tool('복구 기록 보기','ui.recovery','save')+tool('이전 작업 복구 (선택)','file.recoverLegacy','undo')+tool('이전 복구 데이터 삭제','file.clearLegacy','trash'))+group('발표',tool('슬라이드 쇼','show.start','play'));
 $('#ribbon').innerHTML=r;
 $('#ribbonColor')?.addEventListener('change',e=>editCurrent(s=>s.background=e.target.value));

}
function pstyle(e){const metrics=textLayout(e);const isLine=e.type==='line';const fill=e.fill||'transparent',stroke=e.stroke||'transparent';const sh=e.shadow?'0 7px 9px #1527393b':'none';let rule=`left:${e.x}px;top:${e.y}px;width:${e.w}px;height:${e.h}px;opacity:${e.opacity??1};color:${e.color||'#243045'};font-size:${e.fontSize||24}px;line-height:${metrics.lineSpacing};padding:${metrics.marginY}px ${metrics.marginX}px;justify-content:${metrics.verticalAlign==='top'?'flex-start':metrics.verticalAlign==='bottom'?'flex-end':'center'};font-family:${fontCss(e.fontFamily)},'Malgun Gothic',sans-serif;font-weight:${e.bold?'700':'400'};font-style:${e.italic?'italic':'normal'};text-align:${e.align||'left'};align-items:${e.align==='center'?'center':e.align==='right'?'flex-end':'flex-start'};background:${isLine?stroke:fill};border-radius:${e.type==='rounded'?(e.radius??18)+'px':e.type==='ellipse'?'50%':'0'};box-shadow:${sh};transform:rotate(${e.rotation||0}deg);`;if(isLine)rule+='min-height:3px;';if(e.stroke&&e.stroke!=='transparent'&&!isLine)rule+=`border:${e.strokeWidth||2}px solid ${stroke};`;return rule}
function richMarkup(e){
 return `<span class="rich-body">${textRuns(e).map(r=>{
  const f=runStyle(e,r),safeStyle=`font-family:${fontCss(f.fontFamily)};font-size:${Number(f.fontSize)||24}px;color:${f.color||'#243045'};font-weight:${f.bold?700:400};font-style:${f.italic?'italic':'normal'};text-decoration:${f.underline?'underline':'none'}`;
  const attrs=Object.fromEntries(['fontFamily','fontSize','color','bold','italic','underline'].filter(k=>r[k]!==undefined).map(k=>[k,r[k]]));
  return `<span data-run-style="${esc(JSON.stringify(attrs))}" style="${safeStyle}">${esc(r.text)}</span>`;
 }).join('')}</span>`;
}
function paintRichText(ctx,e){
 const rows=[[]];for(const r of textRuns(e)){
  const parts=String(r.text).split('\n');for(let i=0;i<parts.length;i++){
   if(i)rows.push([]);if(parts[i])rows.at(-1).push({text:parts[i],style:runStyle(e,r)});
  }
 }
 const metrics=textLayout(e),spacing=metrics.lineSpacing;
 const measureFont=st=>`${st.italic?'italic ':''}${st.bold?'bold ':''}${Number(st.fontSize||e.fontSize||24)}px ${fontCss(st.fontFamily)},sans-serif`;
 const infos=rows.map(row=>{let width=0,size=e.fontSize||24;
  for(const part of row){ctx.font=measureFont(part.style);width+=ctx.measureText(part.text).width;size=Math.max(size,Number(part.style.fontSize)||0)}return {row,width,size};
 });
 const blockH=infos.reduce((h,x)=>h+x.size*spacing,0);
 let y=metrics.verticalAlign==='top'?metrics.marginY:metrics.verticalAlign==='bottom'?e.h-metrics.marginY-blockH:(e.h-blockH)/2;
 ctx.textBaseline='top';ctx.textAlign='left';
 for(const {row,width,size} of infos){let x=e.align==='center'?(e.w-width)/2:e.align==='right'?e.w-metrics.marginX-width:metrics.marginX;
  for(const part of row){const st=part.style;ctx.font=measureFont(st);ctx.fillStyle=st.color||'#243045';ctx.fillText(part.text,x,y);x+=ctx.measureText(part.text).width}
  y+=size*spacing;
 }
}
function chartSvg(e){
 const spec=NativeChart.chartSpec(e),{categories,series,type}=spec,palette=NativeChart.chartPalette;
 const w=600,h=310,isPie=['pie','doughnut'].includes(type),limit=categories.slice(0,18),n=limit.length;
 const plot={left:spec.legend==='left'?138:58,top:spec.legend==='top'?82:58,right:spec.legend==='right'?138:18,bottom:spec.legend==='bottom'?72:39};
 let body=`<rect width="600" height="310" rx="15" fill="#ffffff"/><text x="24" y="30" font-family="Arial,sans-serif" font-size="21" font-weight="700" fill="#263650">${esc(e.chartTitle||'차트')}</text>`;
 const label=(x,y,txt,extra='')=>`<text x="${x}" y="${y}" font-family="Arial,sans-serif" font-size="12" fill="#52637b" ${extra}>${esc(String(txt))}</text>`;
 const legends=(items,colors)=>{if(spec.legend==='none')return '';return items.slice(0,9).map((name,i)=>{const side=['left','right'].includes(spec.legend),x=side?(spec.legend==='left'?9:470):20+(i%5)*116,y=side?80+i*21:spec.legend==='top'?54+Math.floor(i/5)*17:287-Math.floor((items.length-1)/5)*17+Math.floor(i/5)*17;return `<rect x="${x}" y="${y-10}" width="10" height="10" rx="2" fill="${colors[i]}"/>${label(x+15,y,String(name).slice(0,13))}`}).join('')};
 if(isPie){
  const items=series[0].values.slice(0,n).map(v=>Math.max(0,Number(v)||0)),sum=items.reduce((a,b)=>a+b,0);
  const cx=spec.legend==='left'?353:spec.legend==='right'?242:300,cy=spec.legend==='top'?186:170,r=spec.legend==='top'||spec.legend==='bottom'?92:100;
  let start=-Math.PI/2;
  if(!sum)body+=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="#d5ddeb"/>`;
  else items.forEach((v,i)=>{if(!v)return;const sweep=v/sum*Math.PI*2,end=start+sweep,col=palette[i%palette.length];
   if(v===sum){body+=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${col}"/>`}
   else{const x1=cx+r*Math.cos(start),y1=cy+r*Math.sin(start),x2=cx+r*Math.cos(end),y2=cy+r*Math.sin(end);body+=`<path d="M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${sweep>Math.PI?1:0} 1 ${x2} ${y2} Z" fill="${col}" stroke="white" stroke-width="1.5"/>`}
   if(spec.labels&&v/sum>.055){const mid=start+sweep/2;body+=label(cx+r*.72*Math.cos(mid),cy+r*.72*Math.sin(mid),Math.round(v/sum*100)+'%',`font-weight="bold" text-anchor="middle" fill="#ffffff"`)}start=end;
  });
  if(type==='doughnut')body+=`<circle cx="${cx}" cy="${cy}" r="57" fill="white"/>${label(cx,cy+5,'합계 '+Math.round(sum*100)/100,'text-anchor="middle" font-weight="bold" font-size="15"')}`;
  body+=legends(limit,limit.map((_,i)=>palette[i%palette.length]));
 }else{
  const left=plot.left,top=plot.top,right=w-plot.right,bottom=h-plot.bottom,pw=right-left,ph=bottom-top;
  const vals=series.flatMap(s=>s.values.slice(0,n).filter(v=>v!==null));
  const values=type==='stacked'?Array.from({length:n},(_,i)=>series.reduce((a,s)=>a+Math.max(0,Number(s.values[i])||0),0)):vals;
  const negValues=type==='stacked'?Array.from({length:n},(_,i)=>series.reduce((a,s)=>a+Math.min(0,Number(s.values[i])||0),0)):vals;
  let max=spec.max??Math.max(1,...values)*1.12,min=spec.min??Math.min(0,...negValues);
  if(max<=min)max=min+1;
  const py=v=>top+(max-v)/(max-min)*ph,zero=py(Math.max(min,Math.min(max,0))),centers=limit.map((_,i)=>left+pw*(i+.5)/Math.max(n,1));
  if(spec.showYAxis){for(let i=0;i<=4;i++){const value=min+(max-min)*(4-i)/4,y=top+ph*i/4;body+=`<line x1="${left}" y1="${y}" x2="${right}" y2="${y}" stroke="${e.chartGridlines===false?'transparent':'#e4eaf2'}"/>${label(left-10,y+4,Number(value.toFixed(1)),'text-anchor="end"')}`}}
  if(spec.showXAxis){limit.forEach((cat,i)=>body+=label(centers[i],bottom+19,String(cat).slice(0,12),'text-anchor="middle"'))}
  const barWidth=Math.min(60,pw/n*.75);
  series.forEach((s,j)=>{const col=s.color;
   if(type==='line'){
    let points=[];const flush=()=>{if(points.length>1)body+=`<polyline points="${points.map(p=>p.join(',')).join(' ')}" fill="none" stroke="${col}" stroke-width="3" stroke-linejoin="round"/>`;points=[]};
    for(let i=0;i<n;i++){const v=s.values[i];if(v===null){flush();continue}const x=centers[i],y=py(v);points.push([x,y]);body+=`<circle cx="${x}" cy="${y}" r="4" fill="${col}" stroke="white" stroke-width="1.5"/>`;if(spec.labels)body+=label(x,y-10,v,'text-anchor="middle"')};flush();
   }else for(let i=0;i<n;i++){const v=s.values[i];if(v===null)continue;
    let x,from=0,to=v,bw;
    if(type==='stacked'){const prev=series.slice(0,j).reduce((a,other)=>a+(v>=0?Math.max(0,other.values[i]||0):Math.min(0,other.values[i]||0)),0);from=prev;to=prev+v;x=centers[i]-barWidth/2;bw=barWidth;}
    else{bw=barWidth/series.length;x=centers[i]-barWidth/2+j*bw;}
    const y=Math.min(py(from),py(to)),height=Math.max(1,Math.abs(py(to)-py(from)));body+=`<rect x="${x}" y="${y}" width="${Math.max(bw-1,1)}" height="${height}" rx="2" fill="${col}"/>`;
    if(spec.labels)body+=label(x+bw/2,y-6,v,'text-anchor="middle"');
   }
  });
  body+=legends(series.map(s=>s.name),series.map(s=>s.color));
 }
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 310" preserveAspectRatio="none" role="img" aria-label="데이터 차트">${body}</svg>`;
}

function requiredTextHeight(e){
 if(e.type!=='text'||!e.text)return 0;
 const node=document.createElement('div');
 node.className='element text';node.innerHTML=richMarkup(e);
 // Measure with the identical font, width, wrap, line spacing and padding as
 // the canvas, but without the visible object's fixed height and clipping.
 node.style.cssText=pstyle(e)+'position:fixed;left:-20000px;top:0;height:auto;min-height:0;display:block;overflow:visible;visibility:hidden;transform:none;box-shadow:none;';
 document.body.appendChild(node);
 const value=Math.ceil(node.getBoundingClientRect().height+1);node.remove();return value;
}
function connectorHtml(e,interactive,all){
 const path=Smart.connectorPath(all,e);
 if(!path)return '';
 const chosen=interactive&&selectedIds.has(e.id),locked=interactive&&e.locked;
 // The transparent hit path is interactive without obscuring the connected shapes.
 return `<svg class="element connector ${chosen?'selected':''} ${locked?'locked':''}" data-id="${esc(e.id)}" viewBox="0 0 960 540" style="position:absolute;left:0;top:0;width:960px;height:540px;overflow:visible;pointer-events:none;opacity:${e.opacity??1}" aria-label="스마트 연결선">
 <defs><marker id="arrow-${esc(e.id)}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${esc(e.stroke||'#4b648b')}"/></marker></defs>
 <path class="connector-visible" d="${path.d}" fill="none" stroke="${esc(e.stroke||'#4b648b')}" stroke-width="${Math.max(1,Math.min(12,e.strokeWidth||3))}" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#arrow-${esc(e.id)})" />
 <path class="connector-hit" d="${path.d}" fill="none" stroke="transparent" stroke-width="18" style="pointer-events:stroke;cursor:pointer"/>
 </svg>`;
}
function elementHtml(e,interactive=false,all=[]){if(e.type==='connector')return connectorHtml(e,interactive,all);const cls=`element ${e.type}${interactive&&selectedIds.has(e.id)?' selected':''}${interactive&&e.locked?' locked':''}${interactive&&e.groupId?' grouped':''}`;if(e.type==='chart')return `<div class="${cls}" data-id="${e.id}" style="${pstyle(e)}">${chartSvg(e)}</div>`;if(e.type==='image')return `<img class="${cls}" draggable="false" data-id="${e.id}" alt="삽입 이미지" src="${esc(e.src)}" style="${pstyle(e)}">`;return `<div class="${cls}" data-id="${e.id}" style="${pstyle(e)}">${richMarkup(e)}</div>`}
function contentHtml(s,interactive=false,withMaster=true){const elements=withMaster&&!masterMode?allElements(store.deck,s):s.elements;return elements.map(e=>elementHtml(e,interactive&&s.elements.includes(e),elements)).join('')}
function thumbnailScale(){for(const x of $$('.thumbnail')){const i=x.querySelector('.thumbContent');if(i)i.style.transform=`scale(${x.clientWidth/W})`}}
function renderSlides(){const list=$('#slideList'),oldScroll=list.scrollTop,slides=store.deck.slides;
 const {start,end}=thumbnailRange(slides.length,oldScroll,list.clientHeight,thumbRowHeight,8),key=start+'-'+end+'-'+slides.length;
 const problemCount={};if(inspectorVisible)for(const issue of auditIssues()){if(issue.severity==='info')continue;problemCount[issue.slideId]=(problemCount[issue.slideId]||0)+1;}
 list.innerHTML=slides.map((s,i)=>{const visible=slides.length<=18||(i>=start&&i<end)||s.id===active;
 return `<div class="thumbRow ${s.id===active?'selected':''}" data-slide="${s.id}" draggable="true" role="button" tabindex="0" title="${esc(s.name)}"><span class="num">${i+1}</span>${problemCount[s.id]?`<span class="audit-thumb-badge">${problemCount[s.id]}</span>`:''}<div class="thumbnail">${visible?`<div class="thumbContent" style="background:${esc(effectiveBg(store.deck,s))}">${contentHtml(s)}</div>`:'<div class="thumb-placeholder" title="스크롤하면 미리보기가 표시돼"></div>'}</div></div>`}).join('');
 list.scrollTop=oldScroll;const first=list.querySelector('.thumbRow');if(first){const box=first.getBoundingClientRect();const margin=parseFloat(getComputedStyle(first).marginBottom)||0;if(box.height>30)thumbRowHeight=box.height+margin;}
 thumbWindow=key;$('#slideCount').textContent=slides.length;$('#slidePosition').textContent=`슬라이드 ${slides.findIndex(s=>s.id===active)+1} / ${slides.length}`;$('#currentName').textContent=masterMode?'공통 마스터 편집':slide().name;thumbnailScale()}
let thumbRaf=0;
function updateVisibleThumbnails(){if(thumbRaf)return;thumbRaf=requestAnimationFrame(()=>{thumbRaf=0;const l=$('#slideList');const r=thumbnailRange(store.deck.slides.length,l.scrollTop,l.clientHeight,thumbRowHeight,8),key=r.start+'-'+r.end+'-'+store.deck.slides.length;if(key!==thumbWindow)renderSlides()})}

function renderStage(){const s=slide();if(!s)return;$('#stage').style.background=masterMode?s.background:effectiveBg(store.deck,s);$('#stage').innerHTML=contentHtml(s,true);if(inspectorVisible&&!masterMode){const ids=new Set(auditIssues().filter(x=>x.slideId===active&&x.elementId&&x.severity!=='info').map(x=>x.elementId));for(const node of $('#stage').querySelectorAll('[data-id]'))if(ids.has(node.dataset.id))node.classList.add('audit-outline')};
 const members=selection();if(members.length>1&&!members.some(Smart.isConnector)){const b=Arrange.box(members),frame=document.createElement('div');frame.className='selection-frame';frame.style.cssText=`left:${b.x-3}px;top:${b.y-3}px;width:${b.w+6}px;height:${b.h+6}px`;frame.innerHTML='<div class="selection-resize-handle" title="선택한 개체의 크기를 비례 조절"></div>';$('#stage').appendChild(frame)}
if(document.activeElement!==$('#notes'))$('#notes').value=s.notes||'';renderZoom();motionPathOverlay()}
function motionPathOverlay(){
 const layer=$('#stage'),step=timelineItem();layer.querySelector('#motionPathLayer')?.remove();
 if(tab!=='animations'||!timelineOpen||step?.effect!=='path'||masterMode)return;
 const target=slide().elements.find(e=>e.id===step.elementId);if(!target)return;
 const x=target.x+target.w/2,y=target.y+target.h/2,dx=Number(step.pathDx??180),dy=Number(step.pathDy??0),bend=step.pathType==='curve'?Number(step.pathCurve??-55):0;
 const path=step.pathType==='curve'?`M ${x} ${y} Q ${x+dx/2} ${y+dy/2+bend*2} ${x+dx} ${y+dy}`:`M ${x} ${y} L ${x+dx} ${y+dy}`;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 960 540');svg.id='motionPathLayer';svg.classList.add('motion-path-overlay');
 svg.innerHTML=`<path class="motion-guide" d="${path}"/><circle cx="${x}" cy="${y}" r="6" class="motion-origin"/><circle class="motion-drag-handle" data-path-handle="end" cx="${x+dx}" cy="${y+dy}" r="9"/>${step.pathType==='curve'?`<circle class="motion-drag-handle control" data-path-handle="curve" cx="${x+dx/2}" cy="${y+dy/2+bend*2}" r="8"/>`:''}<text x="${Math.min(875,x+dx+14)}" y="${Math.max(22,y+dy-12)}">끝점 드래그</text>`;
 layer.appendChild(svg);
}
let pathDrag=null;
function setPathPreview(handle,mouseX,mouseY){
 if(!pathDrag)return;
 const r=$('#stage').getBoundingClientRect(),xx=(mouseX-r.left)/zoom,yy=(mouseY-r.top)/zoom;
 const {x,y,dx,dy}=pathDrag;
 if(handle==='curve')pathDrag.curve=(yy-y-dy/2)/2;
 else{pathDrag.dx=xx-x;pathDrag.dy=yy-y;}
 const line=$('#motionPathLayer .motion-guide');if(!line)return;
 const d=pathDrag.type==='curve'?`M ${x} ${y} Q ${x+pathDrag.dx/2} ${y+pathDrag.dy/2+pathDrag.curve*2} ${x+pathDrag.dx} ${y+pathDrag.dy}`:`M ${x} ${y} L ${x+pathDrag.dx} ${y+pathDrag.dy}`;
 line.setAttribute('d',d);
 const end=$('#motionPathLayer [data-path-handle="end"]');end?.setAttribute('cx',x+pathDrag.dx);end?.setAttribute('cy',y+pathDrag.dy);
 const curve=$('#motionPathLayer [data-path-handle="curve"]');curve?.setAttribute('cx',x+pathDrag.dx/2);curve?.setAttribute('cy',y+pathDrag.dy/2+pathDrag.curve*2);
}
function previewConnectors(previews=[]){
 const replacements=new Map(previews.map(e=>[e.id,e]));
 const all=slide().elements.map(e=>replacements.has(e.id)?{...e,...replacements.get(e.id)}:e);
 for(const e of all.filter(Smart.isConnector)){
  const node=[...document.querySelectorAll('#stage .connector')].find(n=>n.dataset.id===e.id);
  const path=Smart.connectorPath(all,e);
  if(node&&path)node.querySelectorAll('.connector-visible,.connector-hit').forEach(p=>p.setAttribute('d',path.d));
 }
}
function previewGuides(guides=[]){
 $('#stage').querySelectorAll('.snap-guide').forEach(e=>e.remove());
 for(const guide of guides){const div=document.createElement('div');div.className='snap-guide '+(guide.axis==='x'?'guide-x':'guide-y');
  div.style[guide.axis==='x'?'left':'top']=guide.value+'px';div.title=guide.source;$('#stage').appendChild(div)}
}
function fitZoom(){const v=$('#stageViewport');return limit(Math.min((v.clientWidth-55)/W,(v.clientHeight-38)/H),.18,1.5)}
function renderZoom(){if(autoFit)zoom=fitZoom();$('#stageHost').style.width=W*zoom+'px';$('#stageHost').style.height=H*zoom+'px';$('#stage').style.transform=`scale(${zoom})`;$('#zoomLabel').textContent=Math.round(zoom*100)+'%';$('#footerZoom').textContent=Math.round(zoom*100)+'%';}
function selectOptions(current,list){return list.map(([value,label])=>`<option value="${value}" ${current===value?'selected':''}>${label}</option>`).join('')}
function layerListHtml(){
 const elems=[...slide().elements].reverse();
 const names={text:'텍스트',rect:'사각형',rounded:'둥근 사각형',ellipse:'원형',star:'별',arrow:'화살표',line:'선',image:'이미지',chart:'차트',connector:'연결선'};
 return `<div class="prop-section layer-section"><h4>레이어 <small>위쪽이 앞에 표시돼</small></h4><div class="layer-list">${elems.map((e,i)=>`<div class="layer-row ${selectedIds.has(e.id)?'layer-active':''}" data-layer-select="${e.id}" title="클릭하여 선택 · Ctrl/Shift 다중 선택"><span class="layer-kind">${e.type==='text'?'T':e.type==='image'?'▧':e.type==='chart'?'▥':e.type==='connector'?'⤳':'▣'}</span><span class="layer-name">${esc((e.text||'').trim().slice(0,22)||names[e.type]||'개체')}</span>${e.groupId?'<span class="group-tag">그룹</span>':''}<button type="button" data-layer-lock="${e.id}" title="${e.locked?'잠금 해제':'잠금'}">${e.locked?'🔒':'🔓'}</button></div>`).join('')}</div><small class="layer-help">맨 위 레이어가 가장 앞에 놓여. 클릭하여 개체를 선택할 수 있어.</small></div>`;
}
function studioScopeLabel(){return studioScope==='current'?'현재 슬라이드':'전체 슬라이드'}
function studioPanelHtml(){
 const panel=studioPanel;
 if(panel==='design')return `<div class="studio-panel"><span class="type-chip">ASTER DESIGN STUDIO</span><h3>테마 · 디자인 일관성</h3><p class="studio-intro">5가지 고유 팔레트를 미리 보고 적용해. 변경은 Ctrl+Z로 복원할 수 있어.</p><div class="studio-scope"><button data-studio-scope="current" class="${studioScope==='current'?'active':''}">현재 슬라이드</button><button data-studio-scope="all" class="${studioScope==='all'?'active':''}">전체 슬라이드</button></div><div class="studio-theme-grid">${Object.entries(Studios.THEMES).map(([key,t])=>`<button class="studio-theme" data-studio-theme="${key}" title="${esc(t.name)} 적용"><span class="studio-theme-preview" style="background:${t.bg};color:${t.text}"><span style="background:${t.accent}"></span><i style="background:${t.secondary}"></i><b style="background:${t.surface}"></b></span><strong>${esc(t.name)}</strong></button>`).join('')}</div><div class="prop-section"><h4>타이포그래피 계층</h4><p>제목·본문·작은 설명의 글자 크기를 규칙에 맞춰 정리해.</p><button class="studio-primary" data-command="studio.typography">${studioScopeLabel()} 글자 크기 정리</button></div><small>그림과 외부 파일은 그대로 유지해. 장식 도형 색상이 달라질 수 있어.</small></div>`;
 if(panel==='fontlab'){
  const records=Studios.scanFonts(store.deck);
  return `<div class="studio-panel"><span class="type-chip">ASTER FONT LAB</span><h3>글꼴 사용 현황</h3><p class="studio-intro">문서 전체와 마스터에 사용된 글꼴을 집계해. 설치 여부는 운영체제에 따라 확인 범위가 달라.</p><div class="studio-metric">${records.length}종의 글꼴 · ${records.reduce((n,r)=>n+r.objects,0)}개 글꼴 적용 개체</div><div class="studio-font-list">${records.map(r=>`<button class="studio-font-row" data-fontlab-from="${esc(r.name)}"><span><strong>${esc(r.name)}</strong><small>${r.objects}개 개체 · ${r.slides}개 슬라이드/마스터</small></span><b style="font-family:${fontCss(r.name)}">가Aa</b></button>`).join('')||'<p>텍스트가 없어.</p>'}</div><div class="prop-section"><h4>전체 문서 글꼴 교체</h4><div class="field"><label>바꿀 글꼴</label><input id="fontLabFrom" list="aster-font-list" placeholder="기존 글꼴 이름"></div><div class="field"><label>새 글꼴</label><input id="fontLabTo" list="aster-font-list" placeholder="예: Noto Sans KR"></div><button class="studio-primary" data-fontlab-replace>모든 슬라이드에서 일괄 교체</button><small>부분 서식(Run)과 마스터 글꼴도 변경돼. 없는 글꼴이거나 자간이 다르면 줄바꿈이 달라질 수 있어.</small></div></div>`;
 }
 if(panel==='data'){
 const chart=el()?.type==='chart'?el():slide().elements.find(e=>e.type==='chart');
 const charts=slide().elements.filter(e=>e.type==='chart');
 const src=chart?.chartSource,filter=chart?.chartFilter||{mode:'all',count:5};
 return `<div class="studio-panel"><span class="type-chip">ASTER LIVE DATA 2.0</span><h3>연결 데이터 관리</h3><p class="studio-intro">CSV/XLSX 파일을 다시 선택해 변경 내역을 확인하고 차트에 적용해. 파일을 자동으로 감시하거나 서버로 업로드하지 않아.</p>${charts.length?`<div class="studio-font-list">${charts.map(c=>`<button class="studio-font-row" data-chart-target="${esc(c.id)}" ${chart?.id===c.id?'style="border-color:#397acf"':''}><strong>${esc(c.chartTitle||'차트')}</strong><small>${c.chartData?.length||0}개 항목</small></button>`).join('')}</div>`:'<p class="studio-empty">현재 슬라이드에 차트가 없어. 삽입 메뉴에서 차트를 추가해.</p>'}${chart?`<div class="studio-metric">선택 차트: ${esc(chart.chartTitle||'이름 없음')}</div><div class="prop-section"><h4>데이터 출처</h4><p>${esc(src?.fileName||'아직 외부 파일 미연결')}</p>${src?`<small>시트: ${esc(src.sheet||'없음')} · 계열: ${esc((src.valueColumns||[]).join(', '))}</small>`:''}<div class="action-row"><button data-command="chart.import">처음 가져오기</button><button data-command="data.toTable">표로 변환</button><button data-command="data.refresh" ${src?.mapping?'':'disabled'}>다시 선택·갱신</button></div></div><div class="prop-section"><h4>데이터 정렬·필터</h4><label class="field">표시 항목<select id="liveFilterMode">${selectOptions(filter.mode,[['all','전체 항목'],['top','합계 상위 N개'],['bottom','합계 하위 N개'],['first','처음 N개']])}</select></label><label class="field">N개<input type="number" id="liveFilterCount" min="1" max="100" value="${filter.count||5}"></label><button class="studio-primary" data-live-filter>필터 적용</button><small>원본 목록은 차트 안에 따로 보존돼. 원본 파일의 자동 동기화는 지원하지 않아.</small></div>`:''}</div>`;
 }
 if(panel==='compare'){
 const result=compareReference?Studios.compareDecks(store.deck,compareReference):null;
 return `<div class="studio-panel"><span class="type-chip">ASTER VERSION COMPARE</span><h3>프레젠테이션 비교</h3><p class="studio-intro">다른 PPTX·Aster 프로젝트를 열어 현재 문서와 슬라이드별로 비교해. 작업 문서는 바꾸지 않아.</p><button class="studio-primary" data-command="compare.open">다른 버전 선택</button>${result?`<div class="studio-metric">${esc(compareName)} · ${result.changed}개 차이 / ${result.slides.length}장</div><div class="studio-diff-list">${result.slides.map((r,i)=>`<div class="studio-diff-row ${r.status}"><b>${i+1}. ${esc(r.title)}</b><span>${{same:'동일',changed:'변경',added:'추가',removed:'삭제'}[r.status]}</span><small>${esc(r.detail.join(' · ')||'변경 없음')}</small><div class="action-row"><button data-version-jump="${i}" ${i>=store.deck.slides.length?'disabled':''}>현재 슬라이드 보기</button><button data-version-apply="${i}" ${r.status==='same'||r.status==='removed'?'disabled':''}>이 슬라이드 가져오기</button></div></div>`).join('')}</div><button data-command="compare.clear">비교 종료</button>`:'<div class="studio-empty">비교할 파일을 선택하면 텍스트·크기·서식·차트의 변경 사항을 확인할 수 있어.</div>'}<small>개체는 슬라이드 내부 순서 기준으로 비교하므로 서로 다른 파일에서 개체 순서가 바뀐 경우 과도한 차이가 보고될 수 있어.</small></div>`;
 }
 return '';
}
function renderStudioPanel(p){$('#propsTitle').textContent=({design:'Design Studio',fontlab:'Font Lab',data:'Live Data',compare:'Version Compare'})[studioPanel]||'속성';$('#inspectorToggle').textContent='속성';p.innerHTML=studioPanelHtml()}
function renderProps(){let p=$('#propertiesBody'),e=el();$('#propsTitle').textContent='속성 패널';$('#inspectorToggle').textContent='진단';if(inspectorVisible){renderInspector(p);return;}if(studioPanel){renderStudioPanel(p);return;}const members=selection();
 if(members.length>1){const b=Arrange.box(members),g=members.every(e=>e.groupId&&e.groupId===members[0].groupId),locked=members.some(e=>e.locked);
  p.innerHTML=`<div class="prop-section"><span class="type-chip">${members.length}개 개체 선택</span><h4>${g?'그룹 선택':'다중 선택'}</h4><p class="selection-summary">${Math.round(b.w)} × ${Math.round(b.h)} px · ${locked?'잠긴 개체 포함':'이동·정렬 가능'}</p><div class="action-row"><button data-command="object.group">그룹화</button><button data-command="object.ungroup">그룹 해제</button></div><div class="action-row"><button data-command="object.lock">잠금</button><button data-command="object.unlock">잠금 해제</button></div></div><div class="prop-section"><h4>가로·세로 정렬</h4><div class="action-row"><button data-command="object.alignLeft">왼쪽</button><button data-command="object.alignCenter">가운데</button><button data-command="object.alignRight">오른쪽</button></div><div class="action-row"><button data-command="object.alignTop">위</button><button data-command="object.alignMiddle">중앙</button><button data-command="object.alignBottom">아래</button></div><div class="action-row"><button data-command="object.distributeX">가로 간격</button><button data-command="object.distributeY">세로 간격</button></div></div><div class="prop-section"><h4>레이어·개체</h4><div class="action-row"><button data-command="object.front">맨 앞으로</button><button data-command="object.back">맨 뒤로</button></div><div class="action-row"><button data-command="object.duplicate">복제</button><button data-command="object.delete" class="danger">삭제</button></div><div class="prop-tip">Shift/Ctrl 클릭으로 다중 선택 · Ctrl+G 그룹 · Ctrl+Shift+G 그룹 해제</div></div>`+layerListHtml();return;}
 if(e?.type==='connector'){
  const items=slide().elements.filter(x=>!Smart.isConnector(x));
  const options=selectedId=>items.map(x=>`<option value="${esc(x.id)}" ${x.id===selectedId?'selected':''}>${esc((x.text||x.type).slice(0,24))}</option>`).join('');
  p.innerHTML=`<div class="prop-section"><span class="type-chip">SMART CONNECTOR</span><h4>도형 자동 연결</h4><p class="selection-summary">도형 위치가 바뀌면 시작점과 끝점이 자동으로 움직여.</p><div class="field"><label>시작 도형</label><select data-prop="from">${options(e.from)}</select></div><div class="field"><label>끝 도형</label><select data-prop="to">${options(e.to)}</select></div><div class="field"><label>경로</label><select data-prop="route">${selectOptions(e.route||'elbow',[['elbow','직각 연결'],['straight','직선 연결']])}</select></div>${field('선 색상','stroke',e.stroke||'#4b648b','color')}${field('선 두께','strokeWidth',e.strokeWidth||3,'number')}<div class="action-row"><button data-command="object.delete" class="danger">연결선 삭제</button></div></div>`+layerListHtml();return;
 }
 if(e?.locked){p.innerHTML=`<div class="prop-section"><span class="type-chip">🔒 잠긴 개체</span><h4>편집이 잠겨 있어</h4><p>이 개체는 이동·크기 조절·서식 변경에서 보호돼. 아래 버튼으로 먼저 해제해 줘.</p><button data-command="object.unlock">🔓 잠금 해제</button></div>`+layerListHtml();return;}
 if(!e){p.innerHTML=`<div class="prop-intro">슬라이드 배경과 구성을 편집할 수 있어요. 캔버스의 요소를 선택하면 상세 설정이 나타나요.</div><div class="prop-section"><h4>슬라이드 설정</h4>${field('슬라이드 이름','slideName',slide().name)}${field('배경 색상','background',slide().background,'color')}<div class="field"><label>빠른 배경색</label>${colorDots('background')}</div>${!masterMode?`<div class="field"><label>슬라이드 전환</label><select data-prop="transition">${selectOptions(slide().transition||'none',[['none','없음'],['fade','페이드'],['slide','밀어내기'],['zoom','확대'],['wipe','닦아내기'],['dissolve','디졸브']])}</select></div>${field('전환 시간(초)','transitionDuration',slide().transitionDuration??0.55,'number')}<label class="field check-option"><input type="checkbox" data-prop="hideMaster" ${slide().hideMaster?'checked':''}> 이 슬라이드에서 마스터 개체 숨기기</label>`:`<div class="field"><label>공통 배경을 모든 슬라이드에 적용</label><input type="checkbox" data-prop="useBackground" ${slide().useBackground?'checked':''}></div>`}<div class="action-row"><button data-command="slide.duplicate">슬라이드 복제</button><button data-command="slide.delete" class="danger">삭제</button></div></div><div class="prop-section"><h4>슬라이드 레이아웃</h4><div class="action-row"><button data-command="slide.addTitle">제목형 추가</button><button data-command="slide.addTwocol">2열 추가</button><button data-command="slide.addSection">섹션 추가</button></div></div><div class="prop-section"><div class="prop-tip">TIP · <b>Ctrl + M</b>을 누르면 현재 슬라이드 뒤에 새 슬라이드가 추가돼요.</div></div>`+layerListHtml();return;}
 const labels={chart:'데이터 차트',text:'텍스트 상자',rect:'사각형',rounded:'둥근 사각형',ellipse:'원형',star:'별',arrow:'화살표',line:'선',image:'이미지'};
 let content=`<div class="prop-section"><span class="type-chip">${labels[e.type]||e.type}</span><h4>위치 및 크기</h4><div class="fieldrow">${field('X 위치','x',Math.round(e.x),'number')}${field('Y 위치','y',Math.round(e.y),'number')}</div><div class="fieldrow">${field('너비','w',Math.round(e.w),'number')}${field('높이','h',Math.round(e.h),'number')}</div><div class="fieldrow">${field('회전 °','rotation',e.rotation||0,'number')}${field('투명도 %','opacity',Math.round((e.opacity??1)*100),'number')}</div></div>`;
 if(e.type==='chart'){
  const table=ChartData.chartCsvMulti(e).replace(/^\uFEFF/,'').trim(),spec=NativeChart.chartSpec(e);
  const seriesColors=spec.series.map((series,i)=>`<div class="fieldrow chart-series-row"><div class="field"><label>계열 ${i+1}: ${esc(series.name)}</label><span class="series-count">${spec.categories.length}개 항목</span></div><div class="field"><label>계열 색상</label><input type="color" data-series-color="${i}" value="${esc(series.color)}"></div></div>`).join('');
  content+=`<div class="prop-section chart-props"><h4>차트 · 데이터 스튜디오</h4><div class="action-row"><button data-command="chart.import">CSV / XLSX 가져오기</button><button data-command="chart.exportCsv">CSV 내보내기</button></div><small class="chart-data-tip">첫 줄에는 계열 이름, 첫 열에는 항목명을 입력해. 여러 수치 열은 각각 별도 계열이 돼. PPTX에서는 실제 차트 객체로 저장돼.</small><div class="field"><label>차트 제목</label><input data-prop="chartTitle" value="${esc(e.chartTitle||'')}"></div><div class="field"><label>차트 유형</label><select data-prop="chartType">${selectOptions(e.chartType||'bar',[['bar','묶은 세로 막대'],['stacked','누적 세로 막대'],['line','꺾은선'],['pie','원형'],['doughnut','도넛']])}</select></div>${['pie','doughnut'].includes(e.chartType)?'<small class="chart-data-tip">원형·도넛은 첫 번째 계열만 표시해. 다른 계열은 데이터로 보관돼.</small>':''}<div class="field"><label>범례</label><select data-prop="chartLegend">${selectOptions(e.chartLegend||'bottom',[['bottom','아래'],['top','위'],['left','왼쪽'],['right','오른쪽'],['none','숨기기']])}</select></div><label class="field check-option"><input type="checkbox" data-prop="chartDataLabels" ${e.chartDataLabels?'checked':''}> 데이터 값 표시</label><label class="field check-option"><input type="checkbox" data-prop="chartShowXAxis" ${e.chartShowXAxis!==false?'checked':''}> 가로축 표시</label><label class="field check-option"><input type="checkbox" data-prop="chartShowYAxis" ${e.chartShowYAxis!==false?'checked':''}> 세로축 표시</label><label class="field check-option"><input type="checkbox" data-prop="chartGridlines" ${e.chartGridlines!==false?'checked':''}> 가로 격자선</label><div class="fieldrow"><div class="field"><label>세로축 최솟값</label><input type="number" step="any" data-prop="chartAxisMin" placeholder="자동" value="${e.chartAxisMin??''}"></div><div class="field"><label>세로축 최댓값</label><input type="number" step="any" data-prop="chartAxisMax" placeholder="자동" value="${e.chartAxisMax??''}"></div></div>${seriesColors}<div class="field"><label>데이터 표 (CSV · 첫 행은 계열명)</label><textarea class="chart-table-editor" data-prop="chartData" rows="7">${esc(table)}</textarea></div><small class="chart-data-tip">계열을 추가하려면 열을 추가하고, 삭제하려면 해당 열을 지워. 데이터 변경도 실행 취소 가능해.</small></div>`;
 }

 if(e.type!=='image'&&e.type!=='chart')content+=`<div class="prop-section"><h4>색상 및 도형</h4>${e.type!=='text'?field('채우기 색상','fill',e.fill&&e.fill!=='transparent'?e.fill:'#ffffff','color'):''}${e.type!=='text'?`<div class="field">${colorDots('fill')}<button class="clear-fill-btn" data-command="format.noFill">${e.fill==='transparent'?'✓ ':''}채우기 없음</button></div>`:''}${field('외곽선 색상','stroke',e.stroke&&e.stroke!=='transparent'?e.stroke:'#ffffff','color')}<div class="fieldrow">${field('외곽선 두께','strokeWidth',e.strokeWidth||0,'number')}${e.type==='rounded'?field('모서리 곡률','radius',e.radius??18,'number'):''}</div><label class="field" style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-prop="shadow" ${e.shadow?'checked':''} style="width:16px">그림자 효과</label></div>`;
 if(e.type!=='image'&&e.type!=='line'&&e.type!=='chart')content+=`<div class="prop-section"><h4>텍스트 및 서식</h4><div class="field"><label>텍스트 내용</label><textarea data-prop="text" rows="3" spellcheck="true">${esc(e.text||'')}</textarea></div><div class="field"><label>글꼴 (이름 직접 입력 가능)</label><button type="button" data-command="font.explorer" class="font-inspector-button"><span>${esc(e.fontFamily||'Arial')}</span><b>미리보기 · 검색 ▾</b></button><small class="font-hint">글자를 드래그한 상태면 선택 영역만, 개체 선택 상태면 전체를 변경해.</small></div><div class="fieldrow">${field('글자 크기 (px)','fontSize',e.fontSize||24,'number')}${field('글자 색상','color',e.color||'#29374a','color')}</div><div class="fieldrow">${field('줄 간격 (배)','lineSpacing',textLayout(e).lineSpacing,'number')}${field('좌우 여백 (px)','textMarginX',textLayout(e).marginX,'number')}</div><div class="fieldrow">${field('위아래 여백 (px)','textMarginY',textLayout(e).marginY,'number')}<div class="field"><label>세로 정렬</label><select data-prop="verticalAlign">${selectOptions(textLayout(e).verticalAlign,[['top','위'],['middle','가운데'],['bottom','아래']])}</select></div></div><div class="field"><label>텍스트 자동 맞춤 (PPTX 호환)</label><select data-prop="textAutoFit">${selectOptions(e.textAutoFit||'none',[['none','사용 안 함'],['shrink','상자 안에서 글자 축소'],['resize','글자에 맞춰 상자 확대']])}</select></div><div class="field"><label>정렬</label><select data-prop="align">${selectOptions(e.align||'left',[['left','왼쪽'],['center','가운데'],['right','오른쪽']])}</select></div>${e.type==='text'?`<div class="text-fit-hint">${requiredTextHeight(e)>e.h+1?`<span class="text-fit-warning">⚠ 글자 높이가 상자보다 커서 일부가 잘릴 수 있어.</span>`:'글자 높이와 상자 높이를 확인할 수 있어.'}<button data-command="text.fitHeight">글자에 맞게 높이 조절</button></div>`:''}<div class="action-row"><button data-command="format.bold">${e.bold?'✓ ':''}굵게</button><button data-command="format.italic">${e.italic?'✓ ':''}기울임</button></div></div>`;
 content+=`<div class="prop-section"><h4>애니메이션</h4><div class="field"><label>효과</label><select data-prop="animationEffect">${selectOptions((Motion.readSteps(slide()).find(x=>x.elementId===e.id)||e.animation)?.effect||'none',[['none','없음'],['fade','페이드'],['fly','날아오기'],['zoom','확대 등장'],['wipe','드러나기']])}</select></div><div class="field"><label>시작 조건</label><select data-prop="animationTrigger">${selectOptions((Motion.readSteps(slide()).find(x=>x.elementId===e.id)||e.animation)?.trigger||'click',[['click','클릭할 때'],['with','앞 효과와 함께'],['after','앞 효과 뒤']])}</select></div><div class="fieldrow">${field('지연(초)','animationDelay',(Motion.readSteps(slide()).find(x=>x.elementId===e.id)||e.animation)?.delay??0,'number')}${field('시간(초)','animationDuration',(Motion.readSteps(slide()).find(x=>x.elementId===e.id)||e.animation)?.duration??0.65,'number')}</div></div><div class="prop-section"><h4>개체 관리</h4><div class="action-row"><button data-command="object.lock">🔒 잠금</button><button data-command="object.ungroup">그룹 해제</button></div><div class="action-row"><button data-command="object.duplicate">복제</button><button data-command="object.front">맨 앞으로</button><button data-command="object.back">맨 뒤로</button><button data-command="object.delete" class="danger">삭제</button></div></div>`;
 p.innerHTML=content+layerListHtml();
}
function timelineItem(){return Motion.readSteps(currentSlide()).find(x=>x.id===motionSelected)||null;}
function renderTimeline(){
 const node=$('#timelinePanel');if(!node)return;
 const enabled=tab==='animations'&&timelineOpen&&!masterMode;
 node.classList.toggle('hidden',!enabled);$('.workarea').classList.toggle('timeline-open',enabled);
 if(!enabled)return;
 const sc=Motion.visualSchedule(currentSlide()),rows=sc.events;
 if(motionSelected&&!rows.some(x=>x.id===motionSelected)){motionSelected=null;motionSelectedIds.clear();}
 $('#timelineSummary').textContent=`${rows.length}개 효과 · ${Motion.schedule(currentSlide()).cues}회 클릭`;
 const editor=document.querySelector('.timeline-actions');
 if(!editor.querySelector('.timeline-zoom')){
  editor.insertAdjacentHTML('afterbegin','<button data-command="anim.copy" title="선택 효과 복사 Ctrl+C">복사</button><button data-command="anim.paste" title="붙여넣기 Ctrl+V">붙여넣기</button><button data-command="anim.selectAll">전체 선택</button><span class="timeline-zoom"><button data-command="timeline.zoomOut" title="타임라인 축소">−</button><b id="motionZoomLabel">100%</b><button data-command="timeline.zoomIn" title="타임라인 확대">＋</button></span>');
 }
 $('#motionZoomLabel').textContent=Math.round(timelineZoom*100)+'%';
 const width=Math.max(580,Math.round(900*timelineZoom)),span=Math.max(sc.seconds,.5),px=width/span;
 $('#timelineTracks').style.setProperty('--motion-track-width',width+'px');
 const ticks=Array.from({length:Math.ceil(span)+1},(_,i)=>`<span class="motion-tick" style="left:${i*px}px">${i}s</span>`).join('');
 const barRows=rows.map(x=>{
  const obj=currentSlide().elements.find(e=>e.id===x.elementId),name=(obj?.text||obj?.chartTitle||obj?.type||'개체').replace(/\s+/g,' ').slice(0,26);
  const left=Math.round(x.visualStart*px),w=Math.max(9,Math.round(x.duration*px));
  return `<button type="button" draggable="true" class="timeline-track ${motionSelectedIds.has(x.id)?'active':''}" data-motion-id="${esc(x.id)}" title="${esc(name)}"><span class="timeline-num">${String(x.order).padStart(2,'0')}</span><span class="timeline-label"><b>${esc(name)}</b> · ${esc(Motion.EFFECTS[x.effect]||x.effect)} · ${x.trigger==='click'?'클릭 '+x.cue:Motion.TRIGGERS[x.trigger]}</span><span class="timeline-timing"><span class="timeline-bar ${x.kind}" style="left:${left}px;width:${w}px"><span class="timeline-bar-resize" data-motion-resize="${esc(x.id)}" title="드래그해 효과 길이 변경"></span></span></span></button>`;
 }).join('');
 $('#timelineTracks').innerHTML=`<div class="timeline-ruler"><div class="timeline-ruler-left">초 단위 타임라인</div><div class="timeline-ruler-scale" style="width:${width}px">${ticks}<span class="timeline-playhead" style="left:${(timelineCursor||0)*px}px"></span></div></div>${barRows||'<div class="timeline-empty">도형을 선택한 뒤 효과를 추가해 줘.</div>'}<div class="timeline-scrub-row"><label>위치 <output id="motionCursorLabel">${(timelineCursor||0).toFixed(2)}s</output></label><input id="timelineScrub" aria-label="타임라인 재생 위치" type="range" min="0" max="${span}" step="0.05" value="${Math.min(timelineCursor||0,span)}"></div>`;
 const x=timelineItem();if(!x){$('#timelineEditor').innerHTML='<div class="timeline-hint">Ctrl/Shift로 여러 효과를 선택하고 복사·삭제할 수 있어. 막대의 오른쪽 끝을 드래그하면 지속 시간을 바꿀 수 있어.</div>';motionPathOverlay();return}
 const options=(v,vals)=>Object.entries(vals).map(([k,name])=>`<option value="${k}" ${v===k?'selected':''}>${esc(name)}</option>`).join('');
 const pick=(key,label,v,values)=>`<label>${label}<select data-timeline-prop="${key}">${options(v,values)}</select></label>`;
 const pathFields=x.effect==='path'?`<div class="timeline-path-fields"><b>모션 경로 편집</b>${pick('pathType','경로',x.pathType||'line',{line:'직선',curve:'곡선'})}<label>끝점 X (px)<input data-timeline-prop="pathDx" type="number" min="-960" max="960" step="1" value="${x.pathDx??180}"></label><label>끝점 Y (px)<input data-timeline-prop="pathDy" type="number" min="-540" max="540" step="1" value="${x.pathDy??0}"></label><label>곡선 휘어짐<input data-timeline-prop="pathCurve" type="number" min="-540" max="540" value="${x.pathCurve??-55}"></label><small>슬라이드의 끝점·곡선 조절점을 드래그하거나 수치를 입력해.</small><button data-command="anim.reversePath">경로 반전 ↔</button></div>`:'';
 $('#timelineEditor').innerHTML=pick('effect','효과',x.effect,Motion.EFFECTS)+pick('kind','단계',x.kind,Motion.KINDS)+pick('trigger','시작',x.trigger,Motion.TRIGGERS)+pick('direction','방향',x.direction||'right',Motion.DIRECTIONS)+pick('easing','속도 변화',x.easing||'ease-out',Motion.EASINGS)+`<label>지속 시간(초)<input data-timeline-prop="duration" type="number" min="0.08" max="15" step="0.1" value="${x.duration}"></label><label>지연(초)<input data-timeline-prop="delay" type="number" min="0" max="15" step="0.1" value="${x.delay}"></label>`+pathFields;
 motionPathOverlay();
}
function applyTimelineScrub(time){
 timelineCursor=time;const rows=Motion.visualSchedule(currentSlide()).events;
 for(const e of slide().elements){const node=[...$('#stage').querySelectorAll('.element')].find(n=>n.dataset.id===e.id);if(!node)continue;node.style.visibility='visible';node.style.transform=`rotate(${e.rotation||0}deg)`;node.style.opacity=String(e.opacity??1);}
 for(const x of rows){const node=[...$('#stage').querySelectorAll('.element')].find(n=>n.dataset.id===x.elementId);if(!node)continue;
  const before=time<x.visualStart,after=time>=x.visualEnd,t=before?0:after?1:(time-x.visualStart)/x.duration;
  if(x.kind==='entrance'&&before){node.style.opacity='0';continue}
  if(x.kind==='exit'&&after){node.style.opacity='0';continue}
  if(x.effect==='path'){
   const p=Motion.pathPoint(x,t);node.style.transform=`translate(${p.x}px,${p.y}px) rotate(${eRotation(x.elementId)}deg)`;
  }else if(!before&&!after){node.style.opacity=String(x.kind==='exit'?1-t:x.kind==='entrance'?t:1)}
 }
 const lbl=$('#motionCursorLabel');if(lbl)lbl.textContent=time.toFixed(2)+'s';
 const head=$('#timelineTracks .timeline-playhead');if(head)head.style.left=(time*(Math.max(580,Math.round(900*timelineZoom))/Math.max(Motion.visualSchedule(currentSlide()).seconds,.5)))+'px';
}
function eRotation(id){return slide().elements.find(e=>e.id===id)?.rotation||0}

function addMotion(effect='fade'){
 const target=el();if(!target){statusMsg('애니메이션을 적용할 개체를 먼저 선택해 줘');return}
 if(target.locked){statusMsg('잠금 해제 후 애니메이션을 적용해 줘');return}
 let newId=null;editCurrent(s=>{const step=Motion.appendStep(s,Motion.newStep(target.id,effect,['pulse','shake','spin','path'].includes(effect)?'emphasis':'entrance'));newId=step.id});motionSelected=newId;renderTimeline();statusMsg('애니메이션 타임라인에 효과를 추가했어');
}
function render(){document.querySelector('.workspace').classList.toggle('studio-mode',!!studioPanel&&!inspectorVisible);document.querySelector('.workspace').classList.toggle('audit-mode',inspectorVisible);if(!store.deck.slides.some(s=>s.id===active))active=store.deck.slides[0].id;ensureSelected();document.querySelector('#deckTitle').value=store.deck.title;renderRibbon();renderSlides();renderStage();renderProps();renderTimeline();if(isShowing)renderShow()}
function add(type){const e=type==='chart'?makeChart():shape(type);if(type==='line'){e.x=260;e.y=240;e.w=240;e.h=4}editCurrent(s=>s.elements.push(e));clearSelection();selectObject(e.id);render();statusMsg(`${{text:'텍스트',rect:'사각형',rounded:'둥근 사각형',ellipse:'타원',star:'별',arrow:'화살표',line:'선',chart:'차트'}[type]} 요소를 추가했어`)}
function insertSlide(layout='blank'){if(masterMode){masterMode=false;selected=null}const i=store.deck.slides.findIndex(s=>s.id===active)+1;let s;update(d=>s=addSlide(d,i,layout));active=s.id;clearSelection();render();statusMsg('새 슬라이드를 추가했어')}
function chooseSlide(id){motionSelected=null;if(!store.deck.slides.some(s=>s.id===id))return;masterMode=false;active=id;clearSelection();slideFocused=true;render()}
function clipboardShape(copy=true){const e=el();if(!e)return;if(copy)clipboard=clone(e)}
function selectTheme(bg,color){editCurrent(s=>{s.background=bg;for(const e of s.elements){if(e.type==='text'&&(e.fill==='transparent'||!e.fill)){e.color=color}}})}
function domRuns(root){
 const out=[];
 const push=(t,attrs)=>{if(t)out.push({text:t,...attrs})};
 const walk=(node,attrs={})=>{
  if(node.nodeType===3){push(node.nodeValue,attrs);return}
  if(node.nodeType!==1)return;
  if(node.tagName==='BR'){push('\n',attrs);return}
  let next=attrs;
  if(node.dataset.runStyle){try{next={...attrs,...JSON.parse(node.dataset.runStyle)}}catch{}}
  // Browser-native Ctrl+B/I/U creates semantic tags. Preserve them when the
  // editable DOM is committed to the same rich-text model as the mini toolbar.
  if(node.tagName==='B'||node.tagName==='STRONG')next={...next,bold:true};
  if(node.tagName==='I'||node.tagName==='EM')next={...next,italic:true};
  if(node.tagName==='U')next={...next,underline:true};
  if((['DIV','P'].includes(node.tagName)||node.classList?.contains('rich-body'))&&out.length&&!out.at(-1).text.endsWith('\n'))push('\n',attrs);
  for(const child of node.childNodes)walk(child,next);
 };
 for(const child of root.childNodes)walk(child);
 return mergeRuns(out);
}
// RC2: contextual formatting stays attached to the browser's text Selection.
// Tools use pointerdown rather than click so selection is not lost to focus changes.
const quickBar=document.createElement('div');
quickBar.id='quickFormat';quickBar.className='quick-format hidden';
quickBar.setAttribute('role','toolbar');quickBar.setAttribute('aria-label','선택한 글자 빠른 서식');
quickBar.innerHTML=`<div class="quick-format-row"><button class="qf-font" type="button" data-qf-menu="font" aria-label="글꼴 선택">맑은 고딕 ▾</button><button type="button" data-qf-action="smaller" title="글자 크기 줄이기">A−</button><span class="qf-size">24</span><button type="button" data-qf-action="larger" title="글자 크기 키우기">A＋</button><i></i><button type="button" data-qf-action="bold" title="굵게 Ctrl+B"><b>B</b></button><button type="button" data-qf-action="italic" title="기울임"><em>I</em></button><button type="button" data-qf-action="underline" title="밑줄"><u>U</u></button><i></i><button type="button" data-qf-menu="color" title="글자 색상" class="qf-color">A<span>●</span></button><button type="button" class="qf-dismiss" data-qf-close="true" title="닫기">×</button></div><div id="quickSubmenu" class="quick-submenu hidden"></div>`;
document.body.appendChild(quickBar);
let quickMenu='';
const quickFonts=['맑은 고딕','Arial','Noto Sans KR','Pretendard','나눔고딕','Georgia','Times New Roman','바탕','굴림'];
const quickColors=['#202b3b','#ffffff','#e34747','#d88224','#2c7aeb','#208b73','#8659cb','#d94b9d'];
function quickSelectionStyle(){
 const e=el();if(!e)return {};
 let offset=0,choice={};const index=rangeCache?.start??0;
 for(const run of textRuns(e)){if(offset+run.text.length>index || offset+run.text.length===0){choice=run;break}offset+=run.text.length}
 return runStyle(e,choice);
}
function hideQuickFormat(){quickBar.classList.add('hidden');quickMenu='';$('#quickSubmenu')?.classList.add('hidden')}
function placeQuickFormat(){
 if(!editing||composition||!rangeCache||rangeCache.id!==editing.id||rangeCache.end<=rangeCache.start){hideQuickFormat();return}
 const sel=window.getSelection();if(!sel?.rangeCount)return;
 const r=sel.getRangeAt(0),rectangle=r.getBoundingClientRect();
 if(!rectangle.width&&!rectangle.height)return;
 const st=quickSelectionStyle();quickBar.querySelector('.qf-font').textContent=(st.fontFamily||'맑은 고딕')+' ▾';
 quickBar.querySelector('.qf-size').textContent=String(Math.round(Number(st.fontSize)||24));
 for(const prop of ['bold','italic','underline'])quickBar.querySelector(`[data-qf-action="${prop}"]`).classList.toggle('active',!!st[prop]);
 quickBar.classList.remove('hidden');
 const width=quickBar.getBoundingClientRect().width||400;
 quickBar.style.left=Math.max(8,Math.min(window.innerWidth-width-8,rectangle.left+rectangle.width/2-width/2))+'px';
 const up=rectangle.top-56,low=rectangle.bottom+10;
 quickBar.style.top=(up>8?up:Math.min(window.innerHeight-54,low))+'px';
}
function restoreRange(id,start,end){
 const node=[...$('#stage').querySelectorAll('.element')].find(x=>x.dataset.id===id);
 if(!node)return;
 textEdit(node);const root=node.querySelector('.rich-body')||node,tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 const parts=[];let text;while((text=tw.nextNode()))parts.push(text);
 if(!parts.length)return;
 const point=off=>{let remaining=off;for(const part of parts){if(remaining<=part.textContent.length)return [part,remaining];remaining-=part.textContent.length}return [parts.at(-1),parts.at(-1).textContent.length]};
 const [a,ao]=point(start),[b,bo]=point(end),range=document.createRange();range.setStart(a,ao);range.setEnd(b,bo);
 const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);trackRange();
}
function applyQuickFormat(property,value){
 if(!rangeCache||rangeCache.end<=rangeCache.start)return;
 const saved={...rangeCache};textFormat(property,value);
 restoreRange(saved.id,saved.start,saved.end);placeQuickFormat();
}
quickBar.addEventListener('pointerdown',event=>{
 const button=event.target.closest('button');if(!button)return;
 event.preventDefault();event.stopPropagation();
 if(button.dataset.qfClose){hideQuickFormat();return}
 if(button.dataset.qfMenu){
  quickMenu=quickMenu===button.dataset.qfMenu?'':button.dataset.qfMenu;
  const panel=$('#quickSubmenu');
  panel.classList.toggle('hidden',!quickMenu);
  panel.innerHTML=quickMenu==='font'?quickFonts.map(f=>`<button type="button" data-qf-font="${esc(f)}" style="font-family:${fontCss(f)},sans-serif">${esc(f)} <span>가나다 ABC</span></button>`).join(''):quickMenu==='color'?`<div class="quick-colors">${quickColors.map(c=>`<button type="button" data-qf-color="${c}" title="${c}" style="background:${c}"></button>`).join('')}</div>`:'';
  return;
 }
 if(button.dataset.qfFont){applyQuickFormat('fontFamily',button.dataset.qfFont);quickMenu='';$('#quickSubmenu').classList.add('hidden');return}
 if(button.dataset.qfColor){applyQuickFormat('color',button.dataset.qfColor);quickMenu='';$('#quickSubmenu').classList.add('hidden');return}
 const action=button.dataset.qfAction;if(!action)return;
 const st=quickSelectionStyle();
 if(action==='smaller'||action==='larger')applyQuickFormat('fontSize',limit((Number(st.fontSize)||24)+(action==='larger'?2:-2),6,160));
 else if(['bold','italic','underline'].includes(action))applyQuickFormat(action,!st[action]);
});
window.addEventListener('scroll',()=>{if(!quickBar.classList.contains('hidden'))placeQuickFormat()},{capture:true,passive:true});
window.addEventListener('resize',()=>{if(!quickBar.classList.contains('hidden'))placeQuickFormat()});
function editableObject(e){return e&&!e.locked&&!['image','arrow','star','line','chart','connector'].includes(e.type)&&!e.groupId&&(e.type==='text'||!!String(e.text||'').trim())}
function textHit(ev,node,obj){
 if(obj?.type==='text')return true;
 const run=node.querySelector('.rich-body span');if(!run)return false;
 const r=document.createRange();r.selectNodeContents(run);
 return [...r.getClientRects()].some(b=>ev.clientX>=b.left-3&&ev.clientX<=b.right+3&&ev.clientY>=b.top-3&&ev.clientY<=b.bottom+3);
}
function nearObjectBorder(ev,node){const r=node.getBoundingClientRect(),pad=3;return ev.clientX-r.left<pad||r.right-ev.clientX<pad||ev.clientY-r.top<pad||r.bottom-ev.clientY<pad}
function trackRange(){
 if(!editing||composition)return;
 const sel=window.getSelection(),node=editing.node;
 if(!sel||!sel.rangeCount||!node.contains(sel.anchorNode)||!node.contains(sel.focusNode))return;
 const at=(n,offset)=>{let r=document.createRange();r.selectNodeContents(node);r.setEnd(n,offset);return r.toString().length};
 rangeCache={id:editing.id,start:Math.min(at(sel.anchorNode,sel.anchorOffset),at(sel.focusNode,sel.focusOffset)),end:Math.max(at(sel.anchorNode,sel.anchorOffset),at(sel.focusNode,sel.focusOffset))};
 placeQuickFormat();
}
document.addEventListener('selectionchange',trackRange);
function finishText(){
 if(!editing||editing.finished)return;
 const session=editing;trackRange();editing=null;session.finished=true;
 if(!quickMenu)hideQuickFormat();
 session.node.contentEditable='false';
 const runs=domRuns(session.node),text=runs.map(r=>r.text).join('');
 const semanticRuns=r=>r.map(x=>[x.text,x.fontFamily??null,x.fontSize??null,x.color??null,x.bold??null,x.italic??null,x.underline??null]);
 if(text!==session.original.text||JSON.stringify(semanticRuns(runs))!==JSON.stringify(semanticRuns(textRuns(session.original)))){
  editCurrent(s=>{const e=s.elements.find(x=>x.id===session.id);if(e){e.text=text;e.runs=runs}});
 }
}
function textEdit(target){if(el()?.locked)return;
 const id=target.dataset.id,obj=slide().elements.find(e=>e.id===id);
 if(!obj||['image','arrow','star','line','chart'].includes(obj.type))return;
 if(editing?.node===target)return;
 if(editing&&editing.node!==target){finishText();target=[...$('#stage').querySelectorAll('.element')].find(node=>node.dataset.id===id)||target;}
 editing={id,node:target,original:clone(obj)};rangeCache=null;hideQuickFormat();
 target.contentEditable='true';target.focus();
 if(obj.text==='더블클릭하여 입력하세요'){
  // Select the entire placeholder, including its wrapper, so the first
  // keystroke replaces it instead of adding characters around it.
  const r=document.createRange();r.selectNodeContents(target);
  const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);
 }
 target.addEventListener('compositionstart',()=>composition=true);
 target.addEventListener('compositionend',()=>{composition=false;trackRange()});
 target.addEventListener('blur',()=>{if(editing?.node===target)finishText()},{once:true});
}
function textFormat(property,value){if(el()?.locked)return;
 if(!el())return;
 if(editing)finishText();
 const r=rangeCache?.id===selected?rangeCache:null;
 editCurrent(s=>{const e=s.elements.find(x=>x.id===selected);if(!e)return;
  if(r&&r.end>r.start)patchElement(e,r.start,r.end,{[property]:value});
  else setUniform(e,property,value);
 });
 if(r&&r.end>r.start)statusMsg('선택 영역의 글자 서식을 변경했어');
}
function availableFonts(){
 const names=fontFilter==='ko'?FONT_KO:fontFilter==='en'?FONT_EN:fontFilter==='favorites'?[...favoriteFonts]:fontFilter==='recent'?recentFonts:FONT_CHOICES;
 return names.filter(n=>n.toLowerCase().includes(fontQuery.trim().toLowerCase()));
}
function refreshFonts(){
 const panel=$('#fontExplorer');panel.classList.toggle('hidden',!fontOpen);
 if(!fontOpen)return;
 panel.querySelector('#fontCount').textContent=availableFonts().length+'개';
 panel.querySelectorAll('[data-font-filter]').forEach(b=>b.classList.toggle('active',b.dataset.fontFilter===fontFilter));
 panel.querySelector('#fontList').innerHTML=availableFonts().map(n=>`<div class="font-item"><button class="font-choice-btn" data-font-choose="${esc(n)}"><strong>${esc(n)}</strong><span style="font-family:${fontCss(n)},sans-serif">가나다라마바사 ABC 123</span></button><button class="font-favorite ${favoriteFonts.has(n)?'saved':''}" data-font-favorite="${esc(n)}" title="즐겨찾기">${favoriteFonts.has(n)?'★':'☆'}</button></div>`).join('')||(fontQuery.trim()?`<div class="font-item"><button class="font-choice-btn" data-font-choose="${esc(fontQuery.trim())}"><strong>직접 입력한 글꼴 적용</strong><span>${esc(fontQuery.trim())}</span></button></div>`:'<p class="font-empty">검색 결과가 없어</p>');
}
function showFonts(){if(!el())return;fontOpen=!fontOpen;refreshFonts();if(fontOpen)$('#fontSearch').focus()}
function chooseFont(name){if(!el())return;textFormat('fontFamily',name);recentFonts=[name,...recentFonts.filter(n=>n!==name)].slice(0,8);rememberFont();fontOpen=false;refreshFonts()}
async function rasterChart(e){const svg=chartSvg(e),url='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg),img=new Image();img.src=url;await img.decode();const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=620;canvas.getContext('2d').drawImage(img,0,0,1200,620);e.type='image';e.src=canvas.toDataURL('image/png');}
function saveOriginal(){if(!sourcePptx){statusMsg('원본 PPTX를 가져온 후에 사용할 수 있어');return}downloadBlob(new Blob([sourcePptx.bytes],{type:'application/vnd.openxmlformats-officedocument.presentationml.presentation'}),'original-presentation-backup.pptx');statusMsg('편집 여부와 관계없이 가져온 원본 파일을 저장했어')}
function saveJson(){downloadBlob(new Blob([JSON.stringify(store.deck,null,2)],{type:'application/json'}),safeFileName(store.deck.title)+'.aster.json');markSaved('프로젝트를 JSON으로 저장했어')}
async function savePptx(nativeMetadata=false){
 try{
  let bytes=null,kind=nativeMetadata?'Aster 편집용':'호환용';
  if(sourcePptx&&!sourcePptx.native&&!nativeMetadata){
   const report=preservationReport(sourcePptx.deck,store.deck);
   if(report.safe){
    bytes=await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck);
    kind=report.changedSlides.length?'원본 구조 보존':'원본 바이트 그대로';
   }else{
    const detail=report.issues.slice(0,5).join('\n• ');
    if(!confirm('원본 PPTX를 안전하게 부분 수정할 수 없어.\n• '+detail+'\n\n호환본으로 다시 만들면 지원하지 않는 요소가 사라질 수 있어. 원본은 변경하지 않고 별도 파일로 생성할까?'))return;
    kind='호환본 재생성';
   }
  }
  if(!bytes)bytes=exportPptx(clone(store.deck),nativeMetadata?store.deck:null);
  const audit=await verifyPptx(bytes,store.deck.slides.length);
  if(nativeMetadata&&!audit.hasNativeSnapshot)throw Error('Aster 편집 데이터 검사 실패');
  if(!nativeMetadata&&kind!=='원본 구조 보존'&&kind!=='원본 바이트 그대로'&&audit.hasNativeSnapshot)throw Error('호환본에 Aster 전용 정보가 포함됐어');
  downloadBlob(new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.presentationml.presentation'}),safeFileName(store.deck.title)+(nativeMetadata?'_aster_editable':kind==='원본 구조 보존'?'_preserved':kind==='호환본 재생성'?'_recreated':'')+'.pptx');
  markSaved(kind+' PPTX 저장 완료. 수정된 부분의 PowerPoint 화면은 별도 확인이 필요해.');
 }catch(err){statusMsg('PPTX 저장 실패: '+err.message);console.error(err)}
}
function importStatus(mode){
 const b=$('#importNotice');if(!b)return;
 const notes={
  'aster-native':'Aster Deck에서 만든 PPTX: 원본 편집 요소를 복원했어.',
  'external-approximate':'외부 PPTX: 지원된 텍스트·좌표 변경은 원본 패키지를 유지하며 저장해. 다른 변경은 안전을 위해 호환본 생성 확인을 요구해.'
 };
 b.hidden=!notes[mode];b.textContent=notes[mode]||'';
 b.classList.toggle('limited',mode==='external-approximate');
}
function replaceDocument(deck,pptxBytes=null){
 clearTimeout(recoveryTimer);recoveryTimer=null;recoveryDirty=false;suppressRecovery=true;
 const mode=deck._importFidelity||null;
 if(deck._importFidelity)delete deck._importFidelity;
 store.load(deck);compareReference=null;compareName='';studioPanel=null;
 sourcePptx=pptxBytes?{bytes:pptxBytes,snapshot:JSON.stringify(store.deck),deck:clone(store.deck),native:mode==='aster-native'}:null;
 masterMode=false;active=store.deck.slides[0].id;clearSelection();slideFocused=false;
 importStatus(mode);render();
 suppressRecovery=false;dirtySinceExport=false;$('#saveStatus').textContent='✓ 파일을 열었어 · 수정 전 상태';$('#footLeft').innerHTML='<span class="ready-dot"></span> 저장한 파일은 변경되지 않았어';
}
function markSaved(msg){dirtySinceExport=false;$('#saveStatus').textContent='✓ 파일 내보내기 완료';$('#footLeft').innerHTML='<span class="ready-dot"></span> 마지막 내보내기 완료';statusMsg(msg)}
function stopShowAnimations(){for(const a of showAnimations)try{a.cancel()}catch{}showAnimations=[];}
function show(index=0){stopShowAnimations();isShowing=true;showIndex=limit(index,0,store.deck.slides.length-1);showReveal=0;$('#slideShow').classList.remove('hidden');$('#slideShow').focus();renderShow(true)}
function presentCue(cue,oldCue){
 const sl=store.deck.slides[showIndex],entries=Motion.schedule(sl).events.filter(x=>x.cue===cue),container=$('#showCanvas');
 for(const item of entries){
  const element=container.querySelector(`.show-slide [data-id="${CSS.escape(item.elementId)}"]`);if(!element)continue;
  element.style.visibility='visible';
  const frames=Motion.keyframes(item);const anim=element.animate(frames,{duration:item.duration*1000,delay:item.start*1000,easing:item.easing,fill:'both'});showAnimations.push(anim);
  anim.addEventListener('finish',()=>{if(item.kind==='exit')element.style.visibility='hidden';if(item.kind!=='emphasis')try{anim.cancel()}catch{}},{once:true});
 }
}
function renderShow(play=false){
 const sl=store.deck.slides[showIndex];if(!sl)return;stopShowAnimations();
 const host=$('#showCanvas'),scale=host.clientWidth/W;host.style.background=effectiveBg(store.deck,sl);
 const before=play&&showReveal>0?showReveal-1:showReveal;
 const state=Motion.stateAt(sl,before);
 const all=allElements(store.deck,sl);
 host.innerHTML=`<div class="show-slide transition-${sl.transition||'none'}" style="position:absolute;left:0;top:0;width:960px;height:540px;transform-origin:0 0;transform:scale(${scale});animation-duration:${limit(Number(sl.transitionDuration)||.55,.1,4)}s">${all.map(e=>elementHtml(e,false,all)).join('')}</div>`;
 for(const [id,visible] of state){const target=host.querySelector(`[data-id="${CSS.escape(id)}"]`);if(target)target.style.visibility=visible?'visible':'hidden'}
 const timeline=Motion.schedule(sl);$('#showCounter').textContent=`${showIndex+1} / ${store.deck.slides.length}`;
 $('#showCue').textContent=`클릭 ${showReveal} / ${timeline.cues}`;
 if(play&&showReveal===0&&timeline.events.some(x=>x.cue===0))presentCue(0,0);
 if(play&&showReveal>0)presentCue(showReveal,showReveal-1);
}
function advanceShow(){
 const total=Motion.schedule(store.deck.slides[showIndex]).cues;
 if(showReveal<total){showReveal++;renderShow(true);return}
 if(showIndex<store.deck.slides.length-1){showIndex++;showReveal=0;renderShow(true)}
 else statusMsg('마지막 슬라이드야 · Esc로 종료해 줘');
}
let contextReturn=null;
function closeMenu(restore=false){const m=$('#slideMenu'),wasOpen=!m.classList.contains('hidden');m.classList.add('hidden');if(restore&&wasOpen){const target=contextReturn?.isConnected?contextReturn:$('#stage');target.focus({preventScroll:true})}}
function openContext(kind,x,y,origin){
 closeMenu();hideQuickFormat();contextReturn=origin;
 const items=contextActions(kind,{items:selection(),slideIndex:store.deck.slides.findIndex(s=>s.id===active),slideCount:store.deck.slides.length,master:masterMode,hasClipboard:!!clipboard,hasObjects:!!slide().elements.length});
 const m=$('#slideMenu');m.setAttribute('aria-label',kind==='slide'?'슬라이드 메뉴':kind==='object'?'개체 메뉴':'캔버스 메뉴');m.dataset.kind=kind;
 m.innerHTML=items.map(a=>`<button type="button" role="menuitem" tabindex="-1" data-command="${a.id}" ${a.enabled?'':'disabled'}>${esc(a.label)}</button>`).join('');
 m.classList.remove('hidden');m.style.left='0px';m.style.top='0px';const b=m.getBoundingClientRect();
 m.style.left=Math.max(8,Math.min(x,innerWidth-b.width-8))+'px';m.style.top=Math.max(8,Math.min(y,innerHeight-b.height-8))+'px';m.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
}
function canvasContext(ev){
 // Keep native selection, copy/paste and IME actions inside active text editors.
 if(isShowing||ev.target.closest('input,textarea,select,[contenteditable="true"]'))return;
 const node=ev.target.closest('.element'),id=node?.dataset.id;
 if(node&&!slide().elements.some(e=>e.id===id))return;
 ev.preventDefault();if(editing)finishText();slideFocused=false;
 if(id){if(!selectedIds.has(id))selectObject(id)}else clearSelection();
 renderStage();renderProps();renderRibbon();openContext(id?'object':'canvas',ev.clientX,ev.clientY,$('#stage'));
}
$('#stageViewport').addEventListener('contextmenu',canvasContext);
$('#slideMenu').addEventListener('keydown',ev=>{
 const items=[...$('#slideMenu').querySelectorAll('button:not(:disabled)')],i=items.indexOf(document.activeElement);
 if(['ArrowDown','ArrowUp','Home','End'].includes(ev.key)){ev.preventDefault();ev.stopPropagation();items[ev.key==='Home'?0:ev.key==='End'?items.length-1:(i+(ev.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus()}
 else if(ev.key==='Escape'||ev.key==='Tab'){if(ev.key==='Escape')ev.preventDefault();ev.stopPropagation();closeMenu(true)}
 else if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();ev.stopPropagation();document.activeElement?.click()}
 else {ev.preventDefault();ev.stopPropagation()}
});
$('#slideMenu').addEventListener('click',ev=>{const b=ev.target.closest('button');if(!b||b.disabled)return;ev.stopPropagation();const id=b.dataset.command;closeMenu();$('#stage').focus({preventScroll:true});command(id)});
document.addEventListener('pointerdown',ev=>{if(!ev.target.closest('#slideMenu'))closeMenu()},true);
document.addEventListener('focusin',ev=>{if(!ev.target.closest('#slideMenu'))closeMenu()});
window.addEventListener('blur',()=>closeMenu());window.addEventListener('resize',()=>closeMenu());
document.addEventListener('scroll',ev=>{if(!ev.target.closest?.('#slideMenu'))closeMenu()},true);

const commands={
 'review.open':()=>activateInspector('all'),
 'review.toggle':()=>{if(studioPanel){studioPanel=null;inspectorVisible=false}else inspectorVisible=!inspectorVisible;render()},
 'review.compat':()=>activateInspector('compat'),
 'review.design':()=>activateInspector('design'),
 'review.close':()=>{inspectorVisible=false;render()},
 'review.recheck':()=>{inspectorVisible=true;render();statusMsg('전체 문서를 다시 검사했어')},
 'review.onlySlide':()=>{inspectorVisible=true;inspectorSlideOnly=!inspectorSlideOnly;render()},
 'review.clearIgnored':()=>{if(!store.deck.diagnosticIgnores?.length){statusMsg('제외한 항목이 없어');return}update(d=>{d.diagnosticIgnores=[]});statusMsg('제외 목록을 초기화했어')},
 'review.fix':()=>{const item=auditIssues().find(x=>x.id===pendingIssueId);if(!item)return;if(item.elementId&&store.deck.slides.find(s=>s.id===item.slideId)?.elements.find(e=>e.id===item.elementId)?.locked){statusMsg('잠긴 개체는 수정할 수 없어');return}let applied=false;update(d=>{applied=Diagnostics.applyFix(d,item)});statusMsg(applied?'수정 완료 · Ctrl+Z로 되돌릴 수 있어':'자동으로 조정할 수 없어. 직접 수정해 줘');},
 'review.ignore':()=>{const item=auditIssues().find(x=>x.id===pendingIssueId);if(!item)return;update(d=>{d.diagnosticIgnores=[...new Set([...(d.diagnosticIgnores||[]),item.id])]});statusMsg('이 항목을 검사 목록에서 제외했어')},
 'ui.closeProperties':()=>{$('.workspace').classList.remove('context-properties');$('#stage').focus()},
 'object.properties':()=>{studioPanel=null;inspectorVisible=false;render();$('.workspace').classList.add('context-properties');$('#propertiesBody').setAttribute('tabindex','-1');$('#propertiesBody').focus()},
 'ui.slides':()=>{if(editing)finishText();prefs.slidesCollapsed=!prefs.slidesCollapsed;applyPreferences();persistPreferences();renderZoom();renderSlides();thumbnailScale()},
 'ui.palette':openPalette,'ui.theme':()=>{prefs.theme=prefs.theme==='dark'?'light':'dark';applyPreferences();persistPreferences();statusMsg(prefs.theme==='dark'?'다크 모드':'라이트 모드')},
 'ui.recovery':showRecoveries,'ui.resetPanes':()=>{prefs.leftWidth=222;prefs.rightWidth=292;prefs.slidesCollapsed=false;applyPreferences();persistPreferences();renderZoom();thumbnailScale()},
 'file.new':()=>{if(confirm('새 문서를 만들까? 저장하지 않은 변경 사항을 내보냈는지 확인해 줘.')){replaceDocument(makeDeck());statusMsg('새 프레젠테이션을 만들었어')}},
 'file.demo':()=>{if(confirm('샘플 프레젠테이션을 불러올까? 현재 작업이 교체돼.')){replaceDocument(makeDemoDeck())}},
 'file.open':()=>$('#openFile').click(),
 'file.recoverLegacy':()=>{let raw=null;try{raw=localStorage.getItem('asterDeck.autoSave')}catch{};if(!raw){statusMsg('이전 버전의 복구 데이터가 없어');return}if(!confirm('이전 작업 데이터를 열까? 현재 화면의 문서는 교체되지만, 기존 저장 파일에는 영향을 주지 않아.'))return;try{replaceDocument(JSON.parse(raw));statusMsg('이전 버전의 작업을 복구했어')}catch(err){statusMsg('복구 실패: '+err.message)}},
 'file.clearLegacy':()=>{if(!confirm('브라우저에 남은 이전 버전 자동 복구 데이터만 삭제할까? 다운로드한 PPTX·JSON 파일은 삭제되지 않아.'))return;try{localStorage.removeItem('asterDeck.autoSave');statusMsg('이전 자동 복구 데이터를 삭제했어')}catch(e){statusMsg('저장소 접근 실패: '+e.message)}},
 'file.save':()=>savePptx(false),'file.exportOriginal':saveOriginal,'file.exportPptx':()=>savePptx(false),'file.exportPptxNative':()=>savePptx(true),'file.exportJson':saveJson,'file.exportPng':()=>exportPng(),
 'slide.add':()=>insertSlide(),'slide.addTitle':()=>insertSlide('title'),'slide.addSection':()=>insertSlide('section'),'slide.addTwocol':()=>insertSlide('twocol'),
 'slide.duplicate':()=>{const i=store.deck.slides.findIndex(s=>s.id===active),copy=clone(slide());copy.id=uid();copy.name+=' · 복사';const idMap=new Map(copy.elements.map(e=>[e.id,uid()]));Motion.copyTimeline(copy,idMap);copy.elements.forEach(e=>{if(e.type==='connector'){e.from=idMap.get(e.from)||e.from;e.to=idMap.get(e.to)||e.to;}e.id=idMap.get(e.id)});update(d=>d.slides.splice(i+1,0,copy));active=copy.id;clearSelection();render()},
 'slide.delete':()=>{if(masterMode){statusMsg('마스터 편집 중에는 슬라이드를 삭제할 수 없어');return}if(store.deck.slides.length===1){statusMsg('마지막 슬라이드는 삭제할 수 없어');return}const i=store.deck.slides.findIndex(s=>s.id===active);update(d=>removeSlide(d,active));active=store.deck.slides[limit(i,0,store.deck.slides.length-1)].id;clearSelection();render()},
 'slide.up':()=>{const i=store.deck.slides.findIndex(s=>s.id===active);if(i>0)update(d=>moveSlide(d,i,i-1))},
 'slide.down':()=>{const i=store.deck.slides.findIndex(s=>s.id===active);if(i<store.deck.slides.length-1)update(d=>moveSlide(d,i,i+1))},
 'studio.open':()=>{inspectorVisible=false;studioPanel='design';render()},
 'studio.typography':()=>{let n=0;update(d=>{d.activeThemeSlide=active;n=Studios.typography(d,studioScope);delete d.activeThemeSlide});statusMsg(n+'개 텍스트 스타일을 정리했어')},
 'fontlab.open':()=>{inspectorVisible=false;studioPanel='fontlab';render()},
 'data.open':()=>{inspectorVisible=false;studioPanel='data';render()},
 'data.refresh':()=>{if(el()?.type!=='chart'||!el().chartSource?.mapping){statusMsg('연결된 차트를 선택해 줘');return}$('#dataRefreshFile').click()},
 'data.toTable':()=>{const source=el();if(source?.type!=='chart'){statusMsg('표로 만들 차트를 선택해 줘');return}const chart=clone(source),i=store.deck.slides.findIndex(s=>s.id===active)+1;const conditional=confirm('수치가 평균보다 높거나 낮은 셀을 색상으로 구분할까?\n취소하면 일반 표로 만들어.');let created=null;update(d=>{const s=addSlide(d,i);s.name='데이터 표 · '+(chart.chartTitle||'차트');const table=Studios.makeDataTable(chart,shape,uid,8,conditional);s.elements.push(...table.elements);created=s.id});active=created;clearSelection();studioPanel=null;tab='home';render();statusMsg('편집 가능한 표를 새 슬라이드에 만들었어')},
 'compare.open':()=>$('#compareFile').click(),
 'compare.show':()=>{inspectorVisible=false;studioPanel='compare';render()},
 'compare.clear':()=>{compareReference=null;compareName='';render();statusMsg('비교를 종료했어')},
 'chart.import':()=>{if(!el()||el().type!=='chart'){statusMsg('데이터를 적용할 차트를 먼저 선택해 줘');return}$('#chartDataFile').click()},
 'chart.exportCsv':()=>{if(!el()||el().type!=='chart')return;downloadBlob(new Blob([ChartData.chartCsvMulti(el())],{type:'text/csv;charset=utf-8'}),safeFileName(el().chartTitle||'chart')+'.csv')},
 'insert.chart':()=>add('chart'),'insert.text':()=>add('text'),'insert.rect':()=>add('rect'),'insert.rounded':()=>add('rounded'),'insert.ellipse':()=>add('ellipse'),'insert.star':()=>add('star'),'insert.arrow':()=>add('arrow'),'insert.line':()=>add('line'),'insert.image':()=>$('#imageFile').click(),
 'connector.add':()=>{
  const list=selection().filter(e=>!Smart.isConnector(e));
  if(list.length!==2||!Arrange.canEdit(list)){statusMsg('잠금 해제된 도형 2개를 Ctrl/Shift로 선택해 줘');return}
  const item=Smart.createConnector(slide().elements,list[0].id,list[1].id,uid());
  if(!item){statusMsg('연결할 수 없는 도형이 포함돼 있어');return}
  editCurrent(s=>s.elements.push(item));clearSelection();selectObject(item.id);render();statusMsg('연결선 생성 완료 · 도형을 이동해 봐');
 },
 'connector.straight':()=>{if(el()?.type==='connector')editCurrent(s=>s.elements.find(e=>e.id===selected).route='straight');else statusMsg('연결선을 먼저 선택해 줘')},
 'connector.elbow':()=>{if(el()?.type==='connector')editCurrent(s=>s.elements.find(e=>e.id===selected).route='elbow');else statusMsg('연결선을 먼저 선택해 줘')},
 ...Object.fromEntries(['horizontal','vertical','grid'].map(mode=>['smart.'+mode,()=>{
  const entries=selection().filter(e=>!Smart.isConnector(e));
  if(entries.length<2){statusMsg('배치할 도형이나 그룹을 둘 이상 선택해 줘');return}
  if(entries.some(e=>e.locked)){statusMsg('잠긴 개체가 포함돼 있어');return}
  if(editCurrent(s=>Smart.smartLayout(s.elements,entries.map(e=>e.id),mode)))statusMsg('Smart Layout · 정렬 완료');
 }])),
 'object.selectAll':()=>selectAllObjects(),
 'object.group':()=>{if(objectOperation(s=>Arrange.group(s.elements,selectedIds,uid()),2)){statusMsg('개체를 그룹으로 묶었어')}},
 'object.ungroup':()=>{if(!selection().some(e=>e.groupId)){statusMsg('선택한 개체가 그룹에 속하지 않아');return}objectOperation(s=>Arrange.ungroup(s.elements,selectedIds));statusMsg('그룹을 해제했어')},
 'object.lock':()=>{if(!selection().length)return;editCurrent(s=>Arrange.setLocked(s.elements,selectedIds,true));statusMsg('선택한 개체를 잠갔어')},
 'object.unlock':()=>{if(!selection().length)return;editCurrent(s=>Arrange.setLocked(s.elements,selectedIds,false));statusMsg('잠금을 해제했어')},
 'object.delete':()=>{if(objectOperation(s=>{const done=Arrange.deleteSelected(s.elements,selectedIds);if(done)Smart.removeDangling(s.elements);return done})){clearSelection();render()}},
 'object.duplicate':()=>{let ids=[];if(objectOperation(s=>{const originals=Arrange.picked(s.elements,selectedIds).map(x=>x.id);ids=Arrange.duplicate(s.elements,selectedIds,uid);const mapper=new Map(originals.map((id,i)=>[id,ids[i]]));const copy=Motion.readSteps(s).filter(x=>mapper.has(x.elementId)).map(x=>({...x,id:Motion.stepId(),elementId:mapper.get(x.elementId)}));if(copy.length)Motion.ensureTimeline(s).push(...copy);return ids.length>0})){selectedIds.clear();ids.forEach(id=>selectedIds.add(id));selected=ids.at(-1);render()}},
 'object.front':()=>objectOperation(s=>Arrange.reorder(s.elements,selectedIds,'front')),
 'object.back':()=>objectOperation(s=>Arrange.reorder(s.elements,selectedIds,'back')),
 'object.forward':()=>objectOperation(s=>Arrange.reorder(s.elements,selectedIds,'forward')),
 'object.backward':()=>objectOperation(s=>Arrange.reorder(s.elements,selectedIds,'backward')),
 'object.alignLeft':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'x','start')),
 'object.alignCenter':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'x','center')),
 'object.alignRight':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'x','end')),
 'object.alignTop':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'y','start')),
 'object.alignMiddle':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'y','center')),
 'object.alignBottom':()=>objectOperation(s=>Arrange.align(s.elements,selectedIds,'y','end')),
 'object.distributeX':()=>objectOperation(s=>Arrange.distribute(s.elements,selectedIds,'x'),3),
 'object.distributeY':()=>objectOperation(s=>Arrange.distribute(s.elements,selectedIds,'y'),3),
 'format.noFill':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(!el()||el().type==='image'||el().type==='chart')return;editCurrent(s=>{const e=s.elements.find(x=>x.id===selected);e.fill='transparent';if(e.type==='line')e.stroke='transparent'})},
 'text.fitHeight':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el()?.type!=='text')return;const h=requiredTextHeight(el());if(h>0)editCurrent(s=>{const e=s.elements.find(x=>x.id===selected);e.h=Math.max(e.h,h)});statusMsg('텍스트 상자 높이를 글자에 맞춰 조정했어')},
 'format.bold':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el())textFormat('bold',!el().bold)},
 'format.italic':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el())textFormat('italic',!el().italic)},
 'font.explorer':()=>showFonts(),
 'format.left':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el())editCurrent(s=>s.elements.find(e=>e.id===selected).align='left')},
 'format.center':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el())editCurrent(s=>s.elements.find(e=>e.id===selected).align='center')},
 'format.right':()=>{if(el()?.locked){statusMsg('잠긴 개체는 편집할 수 없어');return}if(el())editCurrent(s=>s.elements.find(e=>e.id===selected).align='right')},
 'edit.copy':()=>{if(selection().length){clipboard=clone(selection());statusMsg('선택한 개체를 내부 클립보드에 복사했어')}},
 'edit.paste':()=>{if(!clipboard){statusMsg('먼저 개체를 복사해 줘');return}const originals=Array.isArray(clipboard)?clipboard:[clipboard];const groupMap=new Map(),ids=[],idMap=new Map(originals.map(e=>[e.id,uid()]));editCurrent(s=>{for(const old of originals){const e=clone(old);e.id=idMap.get(old.id);if(e.type==='connector'){e.from=idMap.get(e.from)||e.from;e.to=idMap.get(e.to)||e.to;}e.x+=22;e.y+=22;delete e.locked;if(e.groupId){if(!groupMap.has(e.groupId))groupMap.set(e.groupId,uid());e.groupId=groupMap.get(e.groupId)}ids.push(e.id);s.elements.push(e)}});selectedIds.clear();ids.forEach(id=>selectedIds.add(id));selected=ids.at(-1);render()},
 'edit.undo':()=>{store.undo();render()},'edit.redo':()=>{store.redo();render()},
 'view.zoomIn':()=>{autoFit=false;zoom=limit(zoom+.1,.2,1.7);renderZoom()},'view.zoomOut':()=>{autoFit=false;zoom=limit(zoom-.1,.2,1.7);renderZoom()},'view.fit':()=>{autoFit=true;renderZoom()},
 'view.grid':()=>{grid=!grid;$('#stageViewport').classList.toggle('grid-on',grid);$('#gridToggle').style.color=grid?'#d87445':'';renderRibbon()},
 'show.start':()=>show(0),'show.current':()=>show(store.deck.slides.findIndex(s=>s.id===active)),
 'show.end':()=>{stopShowAnimations();isShowing=false;$('#slideShow').classList.add('hidden')},'show.replay':()=>{showReveal=0;renderShow(true)},
 'show.next':()=>advanceShow(),
 'show.prev':()=>{if(showReveal>0){showReveal--;renderShow();return}showIndex=limit(showIndex-1,0,store.deck.slides.length-1);showReveal=0;renderShow()},
 'master.toggle':()=>{masterMode=!masterMode;clearSelection();slideFocused=false;render();statusMsg(masterMode?'공통 마스터 편집 모드':'슬라이드 편집 모드')},
 'master.backgroundAll':()=>{update(d=>{d.master.useBackground=true;d.master.background=masterMode?d.master.background:currentSlide().background})},
 'master.backgroundOff':()=>update(d=>{d.master.useBackground=false}),
 'timeline.toggle':()=>{timelineOpen=!timelineOpen;renderTimeline()},
  'anim.add':()=>addMotion('fade'),'anim.preview':()=>show(store.deck.slides.findIndex(x=>x.id===active)),
  'anim.delete':()=>{if(!motionSelectedIds.size&&motionSelected)motionSelectedIds.add(motionSelected);if(!motionSelectedIds.size)return;editCurrent(s=>{for(const id of motionSelectedIds)Motion.removeStep(s,id)});motionSelected=null;motionSelectedIds.clear();renderTimeline()},
  'anim.selectAll':()=>{motionSelectedIds=new Set(Motion.readSteps(currentSlide()).map(x=>x.id));motionSelected=Motion.readSteps(currentSlide()).at(-1)?.id||null;renderTimeline()},
  'anim.copy':()=>{motionClipboard=Motion.readSteps(currentSlide()).filter(x=>motionSelectedIds.has(x.id)).map(x=>clone(x));statusMsg(motionClipboard.length+'개 효과 복사')},
  'anim.paste':()=>{if(!motionClipboard.length)return;let newIds=[];editCurrent(s=>{for(const old of motionClipboard){if(!s.elements.some(x=>x.id===old.elementId))continue;const row=Motion.appendStep(s,{...old,id:Motion.stepId()});newIds.push(row.id)}});motionSelectedIds=new Set(newIds);motionSelected=newIds.at(-1)||null;renderTimeline()},
  'anim.reversePath':()=>{if(!motionSelected)return;editCurrent(s=>{const x=Motion.ensureTimeline(s).find(x=>x.id===motionSelected);if(x?.effect==='path'){x.pathDx=-(Number(x.pathDx??180));x.pathDy=-(Number(x.pathDy??0));x.pathCurve=-(Number(x.pathCurve??-55))}})},
  'timeline.zoomIn':()=>{timelineZoom=limit(timelineZoom+.25,.6,2.5);renderTimeline()},
  'timeline.zoomOut':()=>{timelineZoom=limit(timelineZoom-.25,.6,2.5);renderTimeline()},
  'anim.moveUp':()=>{if(motionSelected)editCurrent(s=>Motion.moveStep(s,motionSelected,-1))},
  'anim.moveDown':()=>{if(motionSelected)editCurrent(s=>Motion.moveStep(s,motionSelected,1))},
  ...Object.fromEntries(['fade','fly','zoom','wipe','spin','pulse','shake','path'].map(effect=>['anim.'+effect,()=>addMotion(effect)])),
  'anim.none':()=>{if(motionSelected)commands['anim.delete']()},
  ...Object.fromEntries(['none','fade','slide','zoom','wipe','dissolve'].map(effect=>['transition.'+effect,()=>editCurrent(s=>s.transition=effect)])),
  'design.snow':()=>selectTheme('#ffffff','#182b45'),'design.night':()=>selectTheme('#192e50','#ffffff'),
 'design.ocean':()=>selectTheme('#eaf4fe','#284c7c'),'design.peach':()=>selectTheme('#fff0e5','#863b27'),'design.mint':()=>selectTheme('#e6fbf3','#237d68')
};
function command(id){closeMenu();try{if(!commands[id])throw Error('알 수 없는 명령: '+id);commands[id]()}catch(err){console.error('Aster command error',id,err);statusMsg('실행 오류: '+err.message)}}
// Event adapters call the same command registry as the ribbon and shortcuts.
document.addEventListener('click',ev=>{
 const scopeButton=ev.target.closest('[data-studio-scope]');if(scopeButton){studioScope=scopeButton.dataset.studioScope;renderProps();return}
 const themeButton=ev.target.closest('[data-studio-theme]');if(themeButton){const name=themeButton.dataset.studioTheme;update(d=>{d.activeThemeSlide=active;Studios.applyTheme(d,name,studioScope);delete d.activeThemeSlide});statusMsg(Studios.THEMES[name].name+' 테마 적용 완료');return}
 const fontFrom=ev.target.closest('[data-fontlab-from]');if(fontFrom){$('#fontLabFrom').value=fontFrom.dataset.fontlabFrom;return}
 if(ev.target.closest('[data-fontlab-replace]')){const from=$('#fontLabFrom').value.trim(),to=$('#fontLabTo').value.trim();if(!from||!to){statusMsg('기존 글꼴과 새 글꼴을 입력해 줘');return}let changed=0;update(d=>{changed=Studios.replaceFont(d,from,to)});statusMsg(changed?changed+'개 글꼴 적용 구간 교체 완료':'교체할 글꼴이 없어');return}
 const targetChart=ev.target.closest('[data-chart-target]');if(targetChart){clearSelection();selectObject(targetChart.dataset.chartTarget);renderStage();renderProps();return}
 if(ev.target.closest('[data-live-filter]')){if(el()?.type!=='chart'){statusMsg('차트를 선택해 줘');return}const mode=$('#liveFilterMode').value,count=Number($('#liveFilterCount').value)||5;editCurrent(s=>{const chart=s.elements.find(e=>e.id===selected);Studios.filterChart(chart,mode,count)});statusMsg('차트 표시 데이터에 필터를 적용했어');return}
 const versionJump=ev.target.closest('[data-version-jump]');if(versionJump){chooseSlide(store.deck.slides[Number(versionJump.dataset.versionJump)]?.id);return}
 const versionApply=ev.target.closest('[data-version-apply]');if(versionApply){const i=Number(versionApply.dataset.versionApply);if(!compareReference||!confirm((i+1)+'번 슬라이드를 비교 파일의 내용으로 교체할까? Ctrl+Z로 되돌릴 수 있어.'))return;let id;update(d=>{id=Studios.applyComparedSlide(d,compareReference,i,uid)});active=id;clearSelection();render();statusMsg('슬라이드 변경 사항을 가져왔어');return}
 const jump=ev.target.closest('[data-diag-jump]');if(jump){inspectGo(jump.dataset.diagJump);return}
 const fix=ev.target.closest('[data-diag-fix]');if(fix){pendingIssueId=fix.dataset.diagFix;command('review.fix');return}
 const ignore=ev.target.closest('[data-diag-ignore]');if(ignore){pendingIssueId=ignore.dataset.diagIgnore;command('review.ignore');return}
 const auditFilter=ev.target.closest('[data-diag-filter]');if(auditFilter){inspectorFilter=auditFilter.dataset.diagFilter;renderProps();return}
 const motion=ev.target.closest('[data-motion-id]');if(motion){motionSelected=motion.dataset.motionId;if(ev.ctrlKey||ev.metaKey||ev.shiftKey){motionSelectedIds.has(motionSelected)?motionSelectedIds.delete(motionSelected):motionSelectedIds.add(motionSelected)}else{motionSelectedIds.clear();motionSelectedIds.add(motionSelected)}const step=timelineItem();if(step){clearSelection();selectObject(step.elementId)}renderStage();renderProps();renderTimeline();return}
  const font=ev.target.closest('[data-font-choose]');if(font){chooseFont(font.dataset.fontChoose);return}
 const fav=ev.target.closest('[data-font-favorite]');if(fav){const n=fav.dataset.fontFavorite;favoriteFonts.has(n)?favoriteFonts.delete(n):favoriteFonts.add(n);rememberFont();refreshFonts();return}
 const filter=ev.target.closest('[data-font-filter]');if(filter){fontFilter=filter.dataset.fontFilter;refreshFonts();return}
 if(ev.target.closest('#fontDismiss')){fontOpen=false;refreshFonts();return}
 const color=ev.target.closest('[data-color-prop]');if(color){const prop=color.dataset.colorProp,c=color.dataset.color;if(prop==='background')editCurrent(s=>s.background=c);else if(el()&&!el().locked)editCurrent(s=>{s.elements.find(e=>e.id===selected)[prop]=c});return}
 const t=ev.target.closest('[data-tab]');if(t){tab=t.dataset.tab;studioPanel=['design','fontlab','data','compare'].includes(tab)?tab:null;if(studioPanel)inspectorVisible=false;if(tab==='review'){inspectorVisible=true;render()}if((tab==='master')!==masterMode){masterMode=tab==='master';clearSelection();slideFocused=false;render()}$$('.tab').forEach(b=>b.classList.toggle('active',b===t));document.querySelector('.workspace').classList.toggle('studio-mode',!!studioPanel&&!inspectorVisible);renderRibbon();renderTimeline();renderStage();renderProps();renderZoom();return}
 const lockButton=ev.target.closest('[data-layer-lock]');if(lockButton){const id=lockButton.dataset.layerLock;const found=slide().elements.find(e=>e.id===id);if(found){editCurrent(s=>Arrange.setLocked(s.elements,[id],!found.locked));statusMsg(found.locked?'잠금을 해제했어':'선택한 개체를 잠갔어')}return}
 const layer=ev.target.closest('[data-layer-select]');if(layer){selectObject(layer.dataset.layerSelect,ev.ctrlKey||ev.metaKey||ev.shiftKey);renderStage();renderProps();renderRibbon();return}
 const c=ev.target.closest('[data-command]');if(c){command(c.dataset.command);return}
 const thumb=ev.target.closest('[data-slide]');if(thumb){chooseSlide(thumb.dataset.slide);return}
 const target=ev.target.closest('#stage .element');if(target){if(!slide().elements.some(e=>e.id===target.dataset.id)){statusMsg('공통 마스터 개체는 마스터 탭에서 편집해 줘');return}slideFocused=false;if(!target.isContentEditable||selected!==target.dataset.id)rangeCache=null;if(!selection().some(e=>e.id===target.dataset.id)&&!(ev.shiftKey||ev.ctrlKey||ev.metaKey))selectObject(target.dataset.id);renderProps();renderRibbon();$$('#stage .element').forEach(e=>e.classList.toggle('selected',selectedIds.has(e.dataset.id)));return}
 if(ev.target===$('#stage')){slideFocused=false;clearSelection();renderStage();renderProps();renderRibbon()}
 closeMenu();
});
$('#timelineTracks').addEventListener('input',ev=>{if(ev.target.id==='timelineScrub')applyTimelineScrub(Number(ev.target.value))});
let clipResize=null;
$('#timelineTracks').addEventListener('pointerdown',ev=>{
 const handle=ev.target.closest('[data-motion-resize]');if(!handle)return;
 const item=Motion.schedule(currentSlide()).events.find(x=>x.id===handle.dataset.motionResize);if(!item)return;
 ev.preventDefault();ev.stopPropagation();clipResize={id:item.id,x:ev.clientX,duration:item.duration};handle.setPointerCapture(ev.pointerId);
});
$('#timelineTracks').addEventListener('pointerup',ev=>{
 if(!clipResize)return;const dt=(ev.clientX-clipResize.x)/(Math.max(580,Math.round(900*timelineZoom))/Math.max(Motion.visualSchedule(currentSlide()).seconds,.5));
 const newDur=limit(Math.round((clipResize.duration+dt)*20)/20,.08,15),id=clipResize.id;clipResize=null;
 editCurrent(s=>{const x=Motion.ensureTimeline(s).find(e=>e.id===id);if(x)x.duration=newDur});
});
$('#stage').addEventListener('pointerdown',ev=>{
 const h=ev.target.closest('[data-path-handle]');if(!h)return;
 const step=timelineItem(),target=slide().elements.find(e=>e.id===step?.elementId);if(!target)return;
 ev.preventDefault();ev.stopImmediatePropagation();
 pathDrag={id:step.id,handle:h.dataset.pathHandle,x:target.x+target.w/2,y:target.y+target.h/2,dx:Number(step.pathDx??180),dy:Number(step.pathDy??0),curve:Number(step.pathCurve??-55),type:step.pathType||'line'};
 h.setPointerCapture(ev.pointerId);
},true);
$('#stage').addEventListener('pointermove',ev=>{if(pathDrag)setPathPreview(pathDrag.handle,ev.clientX,ev.clientY)},true);
$('#stage').addEventListener('pointerup',ev=>{
 if(!pathDrag)return;ev.preventDefault();ev.stopImmediatePropagation();const changes=pathDrag;pathDrag=null;
 editCurrent(s=>{const row=Motion.ensureTimeline(s).find(e=>e.id===changes.id);if(row){row.pathDx=Math.round(changes.dx);row.pathDy=Math.round(changes.dy);row.pathCurve=Math.round(changes.curve)}});
},true);
$('#timelineTracks').addEventListener('dragstart',ev=>{const row=ev.target.closest('[data-motion-id]');if(row){ev.dataTransfer.setData('text/aster-motion-id',row.dataset.motionId);ev.dataTransfer.effectAllowed='move'}});
$('#timelineTracks').addEventListener('dragover',ev=>{if(ev.target.closest('[data-motion-id]'))ev.preventDefault()});
$('#timelineTracks').addEventListener('drop',ev=>{const to=ev.target.closest('[data-motion-id]')?.dataset.motionId,from=ev.dataTransfer.getData('text/aster-motion-id');if(!to||!from)return;ev.preventDefault();motionSelected=from;editCurrent(s=>Motion.moveStepTo(s,from,to));renderTimeline()});
document.addEventListener('change',ev=>{
 if(ev.target.matches?.('[data-series-color]')){const i=Number(ev.target.dataset.seriesColor),color=ev.target.value;if(el()?.type==='chart')editCurrent(sl=>{const e=sl.elements.find(x=>x.id===selected);const spec=NativeChart.chartSpec(e);e.chartSeries=spec.series.map((ss,j)=>({...ss,color:j===i?color:ss.color}));e.chartColor=e.chartSeries[0]?.color||e.chartColor;});return}
 if(ev.target.id==='auditCurrentOnly'){inspectorSlideOnly=ev.target.checked;renderProps();return}
 const timelineProp=ev.target.dataset?.timelineProp;if(timelineProp){if(!motionSelected)return;const raw=ev.target.value;editCurrent(s=>{const item=Motion.ensureTimeline(s).find(x=>x.id===motionSelected);if(item)item[timelineProp]=['duration','delay','pathDx','pathDy','pathCurve'].includes(timelineProp)?limit(Number(raw)||0,timelineProp==='duration'?.08:timelineProp==='delay'?0:-960,timelineProp==='duration'||timelineProp==='delay'?15:960):raw});return}
  const prop=ev.target.dataset?.prop;if(!prop)return;if(el()?.locked && !['slideName','background','transition','hideMaster','useBackground'].includes(prop)){statusMsg('잠긴 개체를 먼저 해제해 줘');return}
 const raw=ev.target.type==='checkbox'?ev.target.checked:ev.target.value;
 if(['fontSize','color'].includes(prop)&&rangeCache?.id===selected&&rangeCache.end>rangeCache.start){textFormat(prop,prop==='fontSize'?Number(raw):raw);return}
 if(prop==='slideName')editCurrent(s=>s.name=String(raw));
 else if(prop==='hideMaster'||prop==='useBackground')editCurrent(s=>s[prop]=raw);
 else if(prop==='transition')editCurrent(s=>s.transition=String(raw));
  else if(prop==='transitionDuration')editCurrent(s=>s.transitionDuration=limit(Number(raw)||.55,.1,4));
 else if(prop==='chartData'&&el()){try{const table=ChartData.parseDelimited(String(raw));if(table[0]?.length<2)throw Error('2개 이상의 열이 필요해');const cols=Array.from({length:table[0].length-1},(_,i)=>i+1);const parsed=ChartData.tableToMultiChart(table.slice(1),0,cols,table[0]);editCurrent(s=>{const e=s.elements.find(e=>e.id===selected);const old=NativeChart.chartSpec(e);e.chartData=parsed.chartData;e.chartSeries=parsed.chartSeries.map((ss,i)=>({...ss,color:old.series.find(o=>o.name===ss.name)?.color||NativeChart.chartPalette[i%NativeChart.chartPalette.length]}));e.chartColor=e.chartSeries[0].color;delete e.chartRaw;delete e.chartFilter;if(e.chartSource)e.chartSource.manualEdits=true});}catch(error){statusMsg('차트 표 오류: '+error.message)}}
 else if(prop.startsWith('animation')&&el())editCurrent(s=>{
    const e=s.elements.find(x=>x.id===selected);Motion.ensureTimeline(s);
    e.animation ||= {effect:'none',trigger:'click',duration:.65,delay:0};
    const key=prop.slice(9);const field=key.charAt(0).toLowerCase()+key.slice(1);
    const val=['duration','delay'].includes(field)?Number(raw):raw;e.animation[field]=val;
    let step=s.timeline.find(x=>x.elementId===e.id);
    if(!step&&((field==='effect'&&val!=='none')||field!=='effect')){step=Motion.appendStep(s,Motion.newStep(e.id,field==='effect'?val:e.animation.effect==='none'?'fade':e.animation.effect));}
    if(step)step[field]=val;
    if(field==='effect'&&val==='none')s.timeline=s.timeline.filter(x=>x.elementId!==e.id);
   });
 else if(prop==='background')editCurrent(s=>s.background=String(raw));
 else if(el())editCurrent(s=>{const e=s.elements.find(e=>e.id===selected);if(!e)return;
  if(['x','y','w','h','fontSize','lineSpacing','textMarginX','textMarginY','strokeWidth','radius','rotation','opacity'].includes(prop)){const val=prop==='opacity'?limit(Number(raw)/100,0,1):Number(raw);if(prop==='fontSize')setUniform(e,prop,val);else e[prop]=val}
  else if(['chartAxisMin','chartAxisMax'].includes(prop))e[prop]=String(raw).trim()===''?null:Number(raw);
  else if(prop==='text'){e.text=raw;delete e.runs}
  else if(['color','fontFamily'].includes(prop))setUniform(e,prop,raw);
  else if(e.type==='connector'&&['from','to'].includes(prop)){if(raw!==(prop==='from'?e.to:e.from)&&s.elements.some(x=>x.id===raw&&!Smart.isConnector(x)))e[prop]=raw;}
  else e[prop]=raw;
  if(['w','h'].includes(prop))e[prop]=Math.max(3,Number(raw));
 });
});
function askChartColumns(rows,fileName,sheetName=''){
 return new Promise(resolve=>{
  const d=$('#chartMapDialog'),first=rows[0],headers=first.map((v,i)=>String(v||'열 '+(i+1)));
  const hasHeader=headers.some((v,i)=>i>0&&isNaN(Number(v)))||/항목|name|label|category|분류|날짜/i.test(headers[0]||'');
  const names=hasHeader?headers:headers.map((_,i)=>'열 '+(i+1));
  $('#chartMapFile').textContent=fileName+(sheetName?' · '+sheetName:'')+' · '+(rows.length-(hasHeader?1:0))+'개 데이터 행';
  for(const [select,chosen] of [['#chartMapLabel',0],['#chartMapValue',Math.min(1,names.length-1)]]){
   const node=$(select);node.innerHTML=names.map((h,i)=>`<option value="${i}" ${i===chosen?'selected':''}>${i+1}. ${esc(h)}</option>`).join('');
  }
  const sample=rows.slice(0,7);
  $('#chartMapTable').innerHTML=`<thead><tr>${names.map(n=>`<th>${esc(n)}</th>`).join('')}</tr></thead><tbody>${(hasHeader?sample.slice(1):sample).map(row=>`<tr>${names.map((_,i)=>`<td>${esc(row[i]??'')}</td>`).join('')}</tr>`).join('')}</tbody>`;
  let finished=false;
  const done=result=>{if(finished)return;finished=true;if(d.open)d.close();resolve(result)};
  $('#chartMapApply').onclick=()=>{const cat=Number($('#chartMapLabel').value),vals=Array.from($('#chartMapValue').selectedOptions).map(opt=>Number(opt.value)).filter(v=>v!==cat);if(!vals.length){statusMsg('항목 열과 다른 수치 열을 하나 이상 선택해 줘');return}done({cat,vals,names,hasHeader})};
  $('#chartMapCancel').onclick=()=>done(null);$('#chartMapClose').onclick=()=>done(null);
  d.oncancel=ev=>{ev.preventDefault();done(null)};
  d.showModal();
 });
}
$('#chartDataFile').addEventListener('change',async ev=>{
 const file=ev.target.files?.[0];ev.target.value='';if(!file||!el()||el().type!=='chart')return;if(file.size>10*1024*1024){statusMsg('데이터 파일은 10MB 이하만 지원해');return}
 const id=selected;
 try{
  const xlsx=/\.xlsx$/i.test(file.name);const dataset=xlsx?await ChartData.parseXlsx(await file.arrayBuffer()):{rows:ChartData.parseDelimited(await file.text()),sheetName:''};
  const rows=dataset.rows;if(rows.length<2)throw Error('데이터가 최소 2행 이상 필요해');
  const mapping=await askChartColumns(rows,file.name,dataset.sheetName);if(!mapping)return;
  const {cat,vals,names,hasHeader}=mapping;
  const parsed=ChartData.tableToMultiChart(hasHeader?rows.slice(1):rows,cat,vals,names);
  editCurrent(s=>{const chart=s.elements.find(e=>e.id===id);if(!chart||chart.type!=='chart')throw Error('차트 선택이 변경됐어');chart.chartData=parsed.chartData;chart.chartSeries=parsed.chartSeries.map((ss,i)=>({...ss,color:NativeChart.chartPalette[i%NativeChart.chartPalette.length]}));chart.chartColor=chart.chartSeries[0].color;chart.chartRaw=null;delete chart.chartFilter;chart.chartSource={fileName:file.name,sheet:dataset.sheetName||'',categoryColumn:names[cat],valueColumns:vals.map(v=>names[v]),mapping:{cat,vals,names,hasHeader},importedAt:new Date().toISOString()};});
  statusMsg(`${parsed.chartData.length}개 항목 · ${parsed.chartSeries.length}개 계열을 가져왔어${parsed.skipped?' · 제외한 행 '+parsed.skipped+'개':''}${parsed.limited?' · 최대 100개만 적용':''}`);
 }catch(error){console.error(error);statusMsg('데이터 가져오기 실패: '+error.message)}
});
$('#deckTitle').addEventListener('change',ev=>update(d=>d.title=ev.target.value));
let noteStart='';$('#notes').addEventListener('focus',()=>noteStart=$('#notes').value);
$('#notes').addEventListener('blur',ev=>{if(ev.target.value!==noteStart)editCurrent(s=>s.notes=ev.target.value)});
$('#stage').addEventListener('keydown',ev=>{if(ev.key==='Escape'&&editing){ev.preventDefault();finishText();$('#stage').focus();renderProps()}});
$('#stage').addEventListener('dblclick',ev=>{const target=ev.target.closest('.element');if(!target)return;if(editing?.node===target)return;selectObject(target.dataset.id);if(!canChangeSelection()||selection().length>1){statusMsg('그룹 안의 글자는 그룹 해제 후 편집할 수 있어');renderProps();return}renderProps();textEdit(target)});
$('#stage').addEventListener('pointerdown',ev=>{
 const handle=ev.target.closest('.selection-resize-handle');if(handle&&ev.button===0){
  if(!canChangeSelection()){statusMsg('잠긴 개체는 크기를 바꿀 수 없어');return}
  ev.preventDefault();const members=selection(),bounds=Arrange.box(members);
  drag={ids:members.map(e=>e.id),startX:ev.clientX,startY:ev.clientY,before:members.map(e=>({id:e.id,x:e.x,y:e.y,w:e.w,h:e.h})),bounds,resize:true,moved:false,previews:[]};
  handle.setPointerCapture(ev.pointerId);return;
 }
 const target=ev.target.closest('.element');if(!target||!slide().elements.some(e=>e.id===target.dataset.id)||ev.button!==0)return;
 const obj=slide().elements.find(e=>e.id===target.dataset.id);
 const border=nearObjectBorder(ev,target);
 if(!ev.shiftKey&&!ev.ctrlKey&&!ev.metaKey&&!border&&editableObject(obj)&&textHit(ev,target,obj)&&!(selectedIds.size>1)){
  if(!selectedIds.has(obj.id))selectObject(obj.id);
  slideFocused=false;renderProps();renderRibbon();
  if(editing&&editing.id!==obj.id){
   // Committing the previous box may replace the DOM during pointerdown.
   // Wait for the native click to finish before focusing its replacement.
   ev.preventDefault();finishText();
   const nextId=obj.id;
   setTimeout(()=>{if(selected!==nextId)return;const fresh=[...$('#stage').querySelectorAll('.element')].find(e=>e.dataset.id===nextId);if(fresh)textEdit(fresh)},0);
   return;
  }
  textEdit(target);
  // A placeholder has no real text position yet; prevent the native click from
  // moving the caret outside the editable rich-body. Existing text uses native hit testing.
  if(obj.text==='더블클릭하여 입력하세요')ev.preventDefault();
  return;
 }
 // Re-rendering while committing text detaches the old DOM node. Remember its
 // bounds before committing; otherwise the drag is misclassified as resize.
 const hitBounds=target.getBoundingClientRect();
 if(editing)finishText();
 ev.preventDefault();slideFocused=false;
 if(ev.shiftKey||ev.ctrlKey||ev.metaKey){selectObject(target.dataset.id,true);renderStage();renderProps();renderRibbon();return}
 if(target.classList.contains('connector')){selectObject(target.dataset.id);renderStage();renderProps();renderRibbon();return}
 if(!selectedIds.has(target.dataset.id))selectObject(target.dataset.id);
 if(!canChangeSelection()){renderStage();renderProps();renderRibbon();statusMsg('🔒 잠긴 개체는 이동할 수 없어');return}
 const members=selection(),bounds=Arrange.box(members),r=hitBounds;
 const resize=members.length===1&&ev.clientX>r.right-17&&ev.clientY>r.bottom-17;
 drag={ids:members.map(e=>e.id),startX:ev.clientX,startY:ev.clientY,before:members.map(e=>({id:e.id,x:e.x,y:e.y,w:e.w,h:e.h})),bounds,resize,moved:false,previews:[]};
 const liveTarget=[...$('#stage').querySelectorAll('.element')].find(e=>e.dataset.id===target.dataset.id)||target;
 liveTarget.setPointerCapture(ev.pointerId);
 renderProps();renderRibbon();$$('#stage .element').forEach(e=>e.classList.toggle('selected',selectedIds.has(e.dataset.id)));
});
$('#stage').addEventListener('pointermove',ev=>{
 if(!drag){const target=ev.target.closest('.element');if(target){const object=slide().elements.find(e=>e.id===target.dataset.id);if(editableObject(object))target.style.cursor=nearObjectBorder(ev,target)||!textHit(ev,target,object)?'move':'text';}return;}const dx=Math.round((ev.clientX-drag.startX)/zoom),dy=Math.round((ev.clientY-drag.startY)/zoom);
 if(Math.abs(dx)+Math.abs(dy)<1&&!drag.moved)return;
 const d=drag,b=d.bounds;const sx=d.resize?(Math.max(8,b.w+dx)/Math.max(1,b.w)):1,sy=d.resize?(Math.max(8,b.h+dy)/Math.max(1,b.h)):1;
 let mx=dx,my=dy,guides=[];
 if(!d.resize&&!ev.altKey){const snap=Smart.snapMove(slide().elements,d.ids,{x:b.x+dx,y:b.y+dy,w:b.w,h:b.h});mx+=snap.dx;my+=snap.dy;guides=snap.guides}
 d.previews=d.before.map(o=>({id:o.id,x:d.resize?Math.round(b.x+(o.x-b.x)*sx):o.x+mx,y:d.resize?Math.round(b.y+(o.y-b.y)*sy):o.y+my,w:d.resize?Math.max(3,Math.round(o.w*sx)):o.w,h:d.resize?Math.max(3,Math.round(o.h*sy)):o.h}));
 previewGuides(guides);previewConnectors(d.previews);
 for(const pv of d.previews){const node=$$('#stage .element').find(e=>e.dataset.id===pv.id);if(node)Object.assign(node.style,{left:pv.x+'px',top:pv.y+'px',width:pv.w+'px',height:pv.h+'px'})}
 const frame=$('#stage .selection-frame');if(frame&&!d.resize){frame.style.left=b.x+mx-3+'px';frame.style.top=b.y+my-3+'px'}d.moved=true;
});
function endDrag(){if(!drag)return;const d=drag;drag=null;previewGuides();if(d.moved&&d.previews.length){editCurrent(s=>{for(const pv of d.previews){const e=s.elements.find(e=>e.id===pv.id);if(e&&!e.locked)Object.assign(e,{x:pv.x,y:pv.y,w:pv.w,h:pv.h})}});renderStage()}}
$('#stage').addEventListener('pointerup',endDrag);$('#stage').addEventListener('pointercancel',endDrag);
$('#slideList').addEventListener('dragstart',e=>{const row=e.target.closest('[data-slide]');if(row)e.dataTransfer.setData('text/plain',row.dataset.slide)});
$('#slideList').addEventListener('dragover',e=>e.preventDefault());
$('#slideList').addEventListener('drop',e=>{e.preventDefault();const from=e.dataTransfer.getData('text/plain'),to=e.target.closest('[data-slide]')?.dataset.slide;const i=store.deck.slides.findIndex(s=>s.id===from),j=store.deck.slides.findIndex(s=>s.id===to);if(i>=0&&j>=0&&i!==j)update(d=>moveSlide(d,i,j))});
$('#slideList').addEventListener('contextmenu',ev=>{const row=ev.target.closest('[data-slide]');if(!row||isShowing)return;ev.preventDefault();if(editing)finishText();chooseSlide(row.dataset.slide);openContext('slide',ev.clientX,ev.clientY,$(`#slideList [data-slide="${active}"]`))});
$('#slideList').addEventListener('keydown',ev=>{const row=ev.target.closest('[data-slide]');if(row&&['Delete','Backspace'].includes(ev.key)){ev.preventDefault();chooseSlide(row.dataset.slide);command('slide.delete');return}if(row&&(ev.key==='Enter'||ev.key===' ')){ev.preventDefault();chooseSlide(row.dataset.slide)}});
$('#openFile').addEventListener('change',async ev=>{
 const f=ev.target.files?.[0];if(!f)return;
 if(dirtySinceExport&&!confirm('저장하지 않은 변경 사항이 있어. 현재 작업을 별도 프로젝트로 내보내지 않고 새 파일을 열까? 복구 기록은 최대 3개까지만 유지돼.')){ev.target.value='';return}
 try{
 const name=f.name.toLowerCase();
 if(f.size>300*1024*1024)throw Error('파일이 300MB를 초과했어. 큰 이미지 파일은 크기를 줄이고 다시 시도해 줘.');
 if(name.endsWith('.ppt'))throw Error('구형 .ppt 바이너리 파일은 아직 지원하지 않아. .pptx 또는 .aster.json을 사용해 줘.');
 const pptx=name.endsWith('.pptx');if(!pptx&&!name.endsWith('.json')&&!name.endsWith('.aster'))throw Error('지원하는 파일은 .pptx 또는 .aster.json이야.');
 const bytes=pptx?new Uint8Array(await f.arrayBuffer()):null;
 const deck=pptx?await importPptx(bytes):JSON.parse(await f.text());
 const approx=deck._importFidelity==='external-approximate';
 replaceDocument(deck,bytes);
 statusMsg(approx?'외부 PPTX를 간이 편집 모드로 불러왔어.':'파일을 정상적으로 열었어.');
 }catch(e){console.error(e);statusMsg('열기 실패: '+e.message)}finally{ev.target.value=''}
});
$('#dataRefreshFile').addEventListener('change',async ev=>{
 const file=ev.target.files?.[0];ev.target.value='';if(!file||el()?.type!=='chart')return;
 const id=selected,old=clone(el());if(!old.chartSource?.mapping){statusMsg('먼저 원본 CSV/XLSX를 가져와 줘');return}
 try{if(file.size>10e6)throw Error('파일은 10MB 이하여야 해');const dataset=/\.xlsx$/i.test(file.name)?await ChartData.parseXlsx(await file.arrayBuffer()):{rows:ChartData.parseDelimited(await file.text()),sheetName:''};
 const m=old.chartSource.mapping;if(m.hasHeader&&m.names.some((name,i)=>String(dataset.rows[0]?.[i]??'').trim()!==String(name).trim()))throw Error('열 제목이나 순서가 바뀌었어. CSV / XLSX 가져오기로 열을 다시 지정해 줘');const parsed=ChartData.tableToMultiChart(m.hasHeader?dataset.rows.slice(1):dataset.rows,m.cat,m.vals,m.names);
 const next={chartData:parsed.chartData,chartSeries:parsed.chartSeries.map((r,i)=>({...r,color:old.chartSeries?.[i]?.color||NativeChart.chartPalette[i%NativeChart.chartPalette.length]}))};
 const delta=Studios.sourceDiff(old,next);if(delta.identical){statusMsg('데이터가 이전과 같아');return}
 if(!confirm(`새 파일: ${file.name}\n항목 ${delta.oldRows} → ${delta.newRows}개\n계열 ${delta.oldSeries} → ${delta.newSeries}개\n변경된 항목/계열 ${delta.changedRows}개\n\n선택한 차트의 데이터를 갱신할까?`))return;
 editCurrent(s=>{const chart=s.elements.find(e=>e.id===id);if(!chart||chart.type!=='chart')return;Object.assign(chart,next);chart.chartColor=next.chartSeries[0]?.color||chart.chartColor;chart.chartSource={...old.chartSource,fileName:file.name,sheet:dataset.sheetName||'',importedAt:new Date().toISOString(),manualEdits:false};delete chart.chartRaw;delete chart.chartFilter});statusMsg('데이터 갱신 완료 · Ctrl+Z로 복원 가능');
 }catch(err){statusMsg('데이터 갱신 실패: '+err.message)}
});
$('#compareFile').addEventListener('change',async ev=>{const f=ev.target.files?.[0];ev.target.value='';if(!f)return;try{if(f.size>100*1024*1024)throw Error('비교 파일은 100MB 이하여야 해');const other=/\.pptx$/i.test(f.name)?await importPptx(new Uint8Array(await f.arrayBuffer())):JSON.parse(await f.text());Studios.compareDecks(store.deck,other);compareReference=other;compareName=f.name;studioPanel='compare';inspectorVisible=false;tab='compare';render();statusMsg('다른 버전과의 비교를 완료했어')}catch(e){statusMsg('비교 파일 열기 실패: '+e.message)}});
$('#imageFile').addEventListener('change',ev=>{const f=ev.target.files?.[0];if(!f)return;if(f.size>12e6){statusMsg('12MB 이하의 이미지만 지원해');ev.target.value='';return}const fr=new FileReader();fr.onload=()=>{const e=shape('image',270,148);e.src=fr.result;e.w=400;e.h=250;editCurrent(s=>s.elements.push(e));selected=e.id;render();statusMsg('이미지를 추가했어')};fr.readAsDataURL(f);ev.target.value=''});
document.addEventListener('keydown',ev=>{
 if(isShowing){if(ev.key==='Escape'){ev.preventDefault();command('show.end');return}if(['ArrowRight','ArrowDown','PageDown','Enter',' '].includes(ev.key)){ev.preventDefault();command('show.next')}else if(['ArrowLeft','ArrowUp','PageUp','Backspace'].includes(ev.key)){ev.preventDefault();command('show.prev')}return}
 if(composition||ev.isComposing||ev.keyCode===229)return;
 if((ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='k'){ev.preventDefault();command('ui.palette');return}
 const focused=document.activeElement,tag=focused?.tagName,typing=['INPUT','TEXTAREA','SELECT'].includes(tag)||focused?.isContentEditable;
 const ctrl=ev.ctrlKey||ev.metaKey,k=ev.key.toLowerCase();
 if(ctrl&&ev.altKey&&!typing&&['c','v'].includes(k)&&tab==='animations'){ev.preventDefault();command(k==='c'?'anim.copy':'anim.paste');return}
 if(ev.altKey&&ev.shiftKey&&k==='d'&&!typing){ev.preventDefault();command('review.open');return}
 if(!typing&&(ev.key==='ContextMenu'||ev.shiftKey&&ev.key==='F10')){
  const row=focused?.closest('[data-slide]');if(row){ev.preventDefault();chooseSlide(row.dataset.slide);const rect=row.getBoundingClientRect();openContext('slide',rect.x+20,rect.y+20,$(`#slideList [data-slide="${active}"]`));return}
  if(focused?.closest('#stageViewport')){ev.preventDefault();const rect=$('#stage').getBoundingClientRect();openContext(selection().length?'object':'canvas',rect.x+20,rect.y+20,$('#stage'));return}
 }
 const hot=ctrl?({s:'file.save',o:'file.open',n:'file.new',m:'slide.add',z:ev.shiftKey?'edit.redo':'edit.undo',y:'edit.redo',b:'format.bold',c:'edit.copy',v:'edit.paste',d:'object.duplicate',g:ev.shiftKey?'object.ungroup':'object.group',a:'object.selectAll'})[k]:({f5:ev.shiftKey?'show.current':'show.start',delete:!selected&&slideFocused&&!masterMode?'slide.delete':'object.delete',backspace:!selected&&slideFocused&&!masterMode?'slide.delete':'object.delete'})[k];
 if(hot&&(!typing||ctrl&&['s','o','n','m'].includes(k))){ev.preventDefault();command(hot);return}
 if(!typing&&!ctrl){if(k==='pagedown'){let i=store.deck.slides.findIndex(s=>s.id===active);chooseSlide(store.deck.slides[limit(i+1,0,store.deck.slides.length-1)].id)}else if(k==='pageup'){let i=store.deck.slides.findIndex(s=>s.id===active);chooseSlide(store.deck.slides[limit(i-1,0,store.deck.slides.length-1)].id)}
 else if(selection().length&&['arrowleft','arrowright','arrowup','arrowdown'].includes(k)){ev.preventDefault();const delta=ev.shiftKey?10:1;if(!canChangeSelection()){statusMsg('잠긴 개체는 이동할 수 없어');return}editCurrent(s=>Arrange.translate(s.elements,selectedIds,k==='arrowleft'?-delta:k==='arrowright'?delta:0,k==='arrowup'?-delta:k==='arrowdown'?delta:0))}}
});
window.addEventListener('resize',()=>{renderZoom();thumbnailScale();if(isShowing)renderShow()});
// Canvas raster exporter; no external service or CDN required.
async function exportPng(){const s=slide(),factor=2,canvas=document.createElement('canvas');canvas.width=W*factor;canvas.height=H*factor;const ctx=canvas.getContext('2d');ctx.scale(factor,factor);ctx.fillStyle=effectiveBg(store.deck,s);ctx.fillRect(0,0,W,H);
 for(const e of allElements(store.deck,s)){
  if(Smart.isConnector(e)){const route=Smart.connectorPath(allElements(store.deck,s),e);if(!route)continue;
   ctx.save();ctx.strokeStyle=e.stroke||'#4b648b';ctx.fillStyle=ctx.strokeStyle;ctx.lineWidth=e.strokeWidth||3;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();route.points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();
   const last=route.points.at(-1),prev=route.points.at(-2);if(prev){const angle=Math.atan2(last.y-prev.y,last.x-prev.x),len=11;ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(last.x-len*Math.cos(angle-.5),last.y-len*Math.sin(angle-.5));ctx.lineTo(last.x-len*Math.cos(angle+.5),last.y-len*Math.sin(angle+.5));ctx.closePath();ctx.fill()}ctx.restore();continue;}
  ctx.save();ctx.globalAlpha=e.opacity??1;ctx.translate(e.x+e.w/2,e.y+e.h/2);ctx.rotate((e.rotation||0)*Math.PI/180);ctx.translate(-e.w/2,-e.h/2);
  if(e.type==='chart'){try{const im=new Image();im.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(chartSvg(e));await im.decode();ctx.drawImage(im,0,0,e.w,e.h)}catch(err){console.warn(err)}ctx.restore();continue}
  if(e.type==='image'&&e.src){try{const img=new Image();img.src=e.src;await img.decode();const f=Math.min(e.w/img.naturalWidth,e.h/img.naturalHeight);ctx.drawImage(img,(e.w-img.naturalWidth*f)/2,(e.h-img.naturalHeight*f)/2,img.naturalWidth*f,img.naturalHeight*f)}catch(err){console.warn('Image could not be painted',err)}ctx.restore();continue}
  ctx.beginPath();if(e.type==='ellipse')ctx.ellipse(e.w/2,e.h/2,e.w/2,e.h/2,0,0,2*Math.PI);
  else if(e.type==='star'){const r=Math.min(e.w,e.h)/2;for(let i=0;i<10;i++){const a=i*Math.PI/5-Math.PI/2,v=i%2?r*.47:r;const px=e.w/2+Math.cos(a)*v,py=e.h/2+Math.sin(a)*v;if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py)}ctx.closePath()}
  else if(e.type==='arrow'){ctx.moveTo(0,e.h*.24);ctx.lineTo(e.w*.64,e.h*.24);ctx.lineTo(e.w*.64,0);ctx.lineTo(e.w,e.h*.5);ctx.lineTo(e.w*.64,e.h);ctx.lineTo(e.w*.64,e.h*.76);ctx.lineTo(0,e.h*.76);ctx.closePath()}
  else if(e.type==='rounded')ctx.roundRect(0,0,e.w,e.h,Math.min(e.radius||18,e.w/2,e.h/2));
  else if(e.type==='line')ctx.rect(0,0,e.w,Math.max(e.h,3));else ctx.rect(0,0,e.w,e.h);
  if(e.fill&&e.fill!=='transparent'&&e.type!=='text'){ctx.fillStyle=e.fill;ctx.fill()}
  if(e.stroke&&e.stroke!=='transparent'){ctx.lineWidth=e.strokeWidth||2;ctx.strokeStyle=e.stroke;ctx.stroke()}
  if(e.runs?.length)paintRichText(ctx,e);else if(e.text){const lines=String(e.text).split('\n'),sz=e.fontSize||24;ctx.fillStyle=e.color||'#253244';ctx.font=`${e.italic?'italic ':''}${e.bold?'bold ':''}${sz}px ${fontCss(e.fontFamily)}, sans-serif`;ctx.textAlign=e.align||'left';ctx.textBaseline='top';const metrics=textLayout(e),left=e.align==='center'?e.w/2:e.align==='right'?e.w-metrics.marginX:metrics.marginX,blockH=lines.length*sz*metrics.lineSpacing,first=metrics.verticalAlign==='top'?metrics.marginY:metrics.verticalAlign==='bottom'?e.h-metrics.marginY-blockH:(e.h-blockH)/2;lines.forEach((line,i)=>ctx.fillText(line,left,first+i*sz*metrics.lineSpacing,Math.max(e.w-2*metrics.marginX,1)))}ctx.restore();
 }
 canvas.toBlob(blob=>{if(blob){downloadBlob(blob,safeFileName(slide().name)+'.png');statusMsg('현재 슬라이드를 PNG로 저장했어')}else statusMsg('PNG 변환 실패')},'image/png');}
// No implicit browser persistence: a launch always starts from the same demo.
// v0.3 legacy data can only be restored (or cleared) with explicit File commands.
const fontPanel=document.createElement('div');fontPanel.id='fontExplorer';fontPanel.className='font-explorer hidden';fontPanel.setAttribute('role','dialog');fontPanel.setAttribute('aria-label','글꼴 탐색기');
fontPanel.innerHTML=`<header><div><b>Font Explorer</b><small>원하는 글꼴을 이름 또는 모양으로 찾아봐</small></div><button id="fontDismiss" aria-label="닫기">✕</button></header><div class="font-search"><span>⌕</span><input id="fontSearch" type="search" placeholder="글꼴 이름 검색" autocomplete="off"><small id="fontCount"></small></div><div class="font-filters">${[['all','전체'],['ko','한글'],['en','영문'],['favorites','★ 즐겨찾기'],['recent','최근']].map(([k,v])=>`<button data-font-filter="${k}">${v}</button>`).join('')}</div><div id="fontList" class="font-list"></div><footer>글자 일부 드래그 → 선택 영역만 변경. 개체 선택 → 전체 변경. 미설치 글꼴은 대체 서체로 미리 보여.</footer>`;
document.body.appendChild(fontPanel);
fontPanel.querySelector('#fontSearch').addEventListener('input',ev=>{fontQuery=ev.target.value;refreshFonts()});
document.addEventListener('pointerdown',ev=>{if(editing&&ev.target.closest('[data-command="font.explorer"]'))trackRange()},true);
store.subscribe(()=>{if(!suppressRecovery)dirtySinceExport=true;render();$('#saveStatus').textContent='● 변경 사항 있음 · 파일로 저장 필요';$('#footLeft').innerHTML='<span class="ready-dot"></span> 저장하지 않은 변경 사항 있음';scheduleRecovery()});

// v0.9.4 command palette: no external libraries and one central command dispatcher.
$('#commandQuery').addEventListener('input',()=>{paletteIndex=0;renderPalette()});
$('#commandPalette').addEventListener('keydown',ev=>{
 if(ev.key==='ArrowDown'||ev.key==='ArrowUp'){ev.preventDefault();paletteIndex=(paletteIndex+(ev.key==='ArrowDown'?1:-1)+Math.max(1,paletteItems.length))%Math.max(1,paletteItems.length);renderPalette();$('#commandResults [aria-selected=true]')?.scrollIntoView({block:'nearest'})}
 else if(ev.key==='Enter'){ev.preventDefault();paletteRun(paletteIndex)}
});
$('#commandResults').addEventListener('click',ev=>{const b=ev.target.closest('[data-palette-idx]');if(b)paletteRun(Number(b.dataset.paletteIdx))});
$('#recoveryClose').addEventListener('click',()=>$('#recoveryDialog').close());
$('#recoveryList').addEventListener('click',ev=>{const b=ev.target.closest('[data-recovery-open],[data-recovery-delete],[data-recovery-export]');if(!b)return;
 const id=b.dataset.recoveryOpen||b.dataset.recoveryDelete||b.dataset.recoveryExport;
 if(b.dataset.recoveryExport){const d=recovery.read(id);if(d){downloadBlob(new Blob([JSON.stringify(d,null,2)],{type:'application/json'}),safeFileName(d.title)+'_recovery.aster.json');statusMsg('복구 기록을 별도 프로젝트 파일로 내보냈어')}return}
 if(b.dataset.recoveryDelete){if(confirm('이 복구 기록을 삭제할까?')){recovery.remove(id);renderRecovery();updateRecoveryIndicator()}return}
 if(!confirm('현재 문서를 교체하고 선택한 복구 기록을 열까? 기존 다운로드 파일에는 영향이 없어.'))return;
 const d=recovery.read(id);if(!d){statusMsg('복구 기록이 손상되었어');return}
 try{replaceDocument(d);$('#recoveryDialog').close();statusMsg('복구 기록을 불러왔어 · 필요하면 프로젝트로 저장해')}catch(e){statusMsg('복구 실패: '+e.message)}
});
$('#enableRecovery').addEventListener('change',ev=>{prefs.recoveryEnabled=ev.target.checked;persistPreferences();if(!prefs.recoveryEnabled){clearTimeout(recoveryTimer);recoveryTimer=null;recoveryDirty=false}statusMsg(prefs.recoveryEnabled?'복구 기록 저장 켜짐':'복구 기록 저장 꺼짐')});
$('#clearRecoveries').addEventListener('click',()=>{if(confirm('이 브라우저의 새 버전 복구 기록을 전부 삭제할까?')){recovery.clear();renderRecovery();updateRecoveryIndicator()}});
$('#slideList').addEventListener('scroll',updateVisibleThumbnails,{passive:true});
for(const [id,side] of [['resizeLeft','left'],['resizeRight','right']]){
 const handle=$('#'+id);let startX=0,startW=0;
 const applyWidth=v=>{prefs[side==='left'?'leftWidth':'rightWidth']=Math.round(Math.max(side==='left'?154:235,Math.min(side==='left'?350:425,v)));applyPreferences();renderZoom();thumbnailScale()};
 handle.addEventListener('pointerdown',e=>{if(e.button!==0)return;startX=e.clientX;startW=side==='left'?prefs.leftWidth:prefs.rightWidth;handle.setPointerCapture(e.pointerId);handle.classList.add('dragging')});
 handle.addEventListener('pointermove',e=>{if(!handle.hasPointerCapture(e.pointerId))return;applyWidth(startW+(side==='left'?1:-1)*(e.clientX-startX))});
 handle.addEventListener('pointerup',e=>{if(handle.hasPointerCapture(e.pointerId)){handle.releasePointerCapture(e.pointerId);handle.classList.remove('dragging');persistPreferences();renderSlides()}});
 handle.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();applyWidth((side==='left'?prefs.leftWidth:prefs.rightWidth)+(side==='left'?1:-1)*(e.key==='ArrowRight'?15:-15));persistPreferences()}});
 handle.addEventListener('dblclick',()=>command('ui.resetPanes'));
}
window.addEventListener('pagehide',flushRecovery);
window.addEventListener('beforeunload',event=>{if(dirtySinceExport){flushRecovery();event.preventDefault();event.returnValue=''}});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')flushRecovery()});

// Embedded as a standalone offline HTML during build; this single bootstrap is always executed.
function init(){applyPreferences();updateRecoveryIndicator(); $$('[data-icon]').forEach(e=>e.insertAdjacentHTML('afterbegin',icon(e.dataset.icon)));render();requestAnimationFrame(()=>renderZoom());new ResizeObserver(()=>{if(autoFit)renderZoom();thumbnailScale()}).observe($('#stageViewport'));}
init();
