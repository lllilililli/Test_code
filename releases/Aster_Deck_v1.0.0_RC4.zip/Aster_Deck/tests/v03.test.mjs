import test from 'node:test';
import assert from 'node:assert/strict';
import {Store,makeDeck,makeSlide,makeChart,shape,addSlide,effectiveBg,allElements,normalizeDeck} from '../src/core.js';
import {exportPptx} from '../src/pptx.js';
import {zipRead,zipText} from '../src/zip.js';

test('legacy v2 decks acquire editable master non-destructively',()=>{
 const old=makeDeck();delete old.master;old.version=2;
 const store=new Store(old);
 assert.deepEqual(store.deck.master.elements,[]);
 assert.equal(store.deck.version,2);
});
test('no-fill shape survives clone and undo',()=>{
 const d=makeDeck(),s=new Store(d);s.execute(x=>x.slides[0].elements.push(shape('rect')));
 s.execute(x=>x.slides[0].elements[0].fill='transparent');
 assert.equal(s.deck.slides[0].elements[0].fill,'transparent');
 s.undo();assert.equal(s.deck.slides[0].elements[0].fill,'#5583e7');
 s.redo();assert.equal(s.deck.slides[0].elements[0].fill,'transparent');
});
test('master element overlays in visual model and can be hidden per slide',()=>{
 const d=makeDeck();d.master.elements.push(shape('text'));assert.equal(allElements(d,d.slides[0]).length,1);
 d.slides[0].hideMaster=true;assert.equal(allElements(d,d.slides[0]).length,0);
});
test('master background follows per-slide override',()=>{
 const d=makeDeck();d.master.background='#123456';d.master.useBackground=true;
 assert.equal(effectiveBg(d,d.slides[0]),'#123456');d.slides[0].hideMaster=true;
 assert.equal(effectiveBg(d,d.slides[0]),'#ffffff');
});
test('chart is native to Aster document schema',()=>{
 const d=makeDeck();const chart=makeChart();d.slides[0].elements.push(chart);
 const result=new Store(d);assert.equal(result.deck.slides[0].elements[0].chartData.length,4);
 assert.equal(result.deck.slides[0].elements[0].type,'chart');
});
test('per-element animation metadata survives undo redo',()=>{
 const store=new Store(makeDeck());store.execute(d=>d.slides[0].elements.push(shape('text')));
 store.execute(d=>d.slides[0].elements[0].animation={effect:'fly',trigger:'click',duration:1.2,delay:.3});
 store.undo();assert.equal(store.deck.slides[0].elements[0].animation.effect,'none');
 store.redo();assert.equal(store.deck.slides[0].elements[0].animation.effect,'fly');
});
test('PPTX transparency exports a:noFill and preserves slide transition',async()=>{
 const d=makeDeck(),e=shape('rounded');e.fill='transparent';e.stroke='#337799';e.strokeWidth=3;
 d.slides[0].elements.push(e);d.slides[0].transition='fade';
 const files=await zipRead(exportPptx(d));const xml=zipText(files,'ppt/slides/slide1.xml');
 assert.match(xml,/<a:noFill\/>/);assert.match(xml,/<p:transition spd="med"><p:fade\/><\/p:transition>/);
});
test('PPTX exports common master shapes as true master elements',async()=>{
 const d=makeDeck();const e=shape('text');e.text='Aster Deck common footer';d.master.elements.push(e);
 const files=await zipRead(exportPptx(d));assert.match(zipText(files,'ppt/slideMasters/slideMaster1.xml'),/Aster Deck common footer/);assert.doesNotMatch(zipText(files,'ppt/slides/slide1.xml'),/Aster Deck common footer/);
});
