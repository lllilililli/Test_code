import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text()
checks=[]
def check(cond,name):
 checks.append((name,bool(cond)))
 if not cond: print('FAIL',name,flush=True)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.evaluate("""() => {const m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k)}})}""")
  await page.set_content(HTML,wait_until='load')
  await page.wait_for_timeout(200)
  check(await page.locator('.thumbRow').count()==5,'initial 5 slides')
  check(await page.locator('#stage .element').count()>4,'visible slide')
  await page.keyboard.press('Control+k')
  check(await page.locator('#commandPalette').evaluate('(e)=>e.open'),'Ctrl K opens palette')
  await page.locator('#commandQuery').fill('슬라이드 추가')
  check(await page.locator('.command-result').count()==1,'palette filter')
  await page.keyboard.press('Enter')
  check(await page.locator('.thumbRow').count()==6,'palette execute slide.add')
  await page.locator('[data-command="ui.theme"]').first.click()
  check(await page.locator('body').get_attribute('data-aster-theme')=='dark','dark mode')
  await page.locator('[data-command="ui.theme"]').first.click()
  check(await page.locator('body').get_attribute('data-aster-theme')=='light','light mode')
  split=page.locator('#resizeLeft');box=await split.bounding_box()
  await page.mouse.move(box['x']+2,box['y']+90);await page.mouse.down();await page.mouse.move(box['x']+60,box['y']+90,steps=5);await page.mouse.up()
  width=await page.locator('.slides-panel').evaluate('(e)=>Math.round(e.getBoundingClientRect().width)')
  check(width>235,f'left pane resize to {width}')
  await page.evaluate("command('ui.resetPanes')")
  check(await page.locator('.slides-panel').evaluate('(e)=>Math.round(e.getBoundingClientRect().width)')==222,'reset panes')
  await page.wait_for_timeout(1250)
  await page.evaluate("command('ui.recovery')")
  rows=await page.locator('.recovery-row').count();check(rows>=1,f'recovery after edit: {rows}')
  await page.locator('#recoveryClose').click()
  # Switching to large deck tests viewport-only thumbnails and scroll
  await page.evaluate("""() => {const d=makeDeck();for(let i=1;i<180;i++)addSlide(d);store.load(d)}""")
  check(await page.locator('.thumbRow').count()==180,'180 slide rows')
  heavy=await page.locator('.thumbContent').count()
  check(heavy<32,f'virtualized thumbnail DOM count {heavy}')
  await page.locator('#slideList').evaluate('(e)=>e.scrollTop=10500')
  await page.wait_for_timeout(400)
  check(await page.locator('.thumbContent').count()<32,'virtualized after scrolling')
  check(await page.locator('.thumbRow').count()==180,'all thumbnails selectable')
  await page.locator('.thumbRow').nth(90).click()
  check('91 / 180' in await page.locator('#slidePosition').inner_text(),'select distant slide')
  # verify stored recovery remains manual only, and can restore user-visible original small deck
  await page.evaluate("command('ui.recovery')")
  check(await page.locator('.recovery-row').count()>=1,'recovery entries retained')
  page.once('dialog',lambda d:d.accept())
  await page.locator('.recovery-row').filter(has_text='Northern Lights').locator('.recovery-restore').first.click()
  check(await page.locator('.thumbRow').count()==6,'manual recovery loaded last six-slide session')
  check(not await page.locator('#recoveryDialog').evaluate('(e)=>e.open'),'recovery closes')
  # export JSON download
  async with page.expect_download() as downloaded:
   await page.evaluate("command('file.exportJson')")
  dl=await downloaded.value
  check(dl.suggested_filename.endswith('.aster.json'),'project downloadable')
  # after manually save, open dialog again and opt out
  await page.evaluate("command('ui.recovery')")
  await page.locator('#enableRecovery').uncheck()
  check(await page.evaluate("loadPrefs(window.localStorage).recoveryEnabled") is False,'opt out preference')
  await page.locator('#recoveryClose').click()
  # A fresh launch must not silently replace the opening document with a recovered snapshot.
  saved=await page.evaluate("[ ['aster.workspace.preferences.v096',localStorage.getItem('aster.workspace.preferences.v096')],['aster.workspace.recovery.v096',localStorage.getItem('aster.workspace.recovery.v096')] ]")
  fresh=await browser.new_page(viewport={'width':1440,'height':900})
  fresh.on('pageerror',lambda e:errors.append(str(e)))
  await fresh.evaluate("""(saved)=>{const m=new Map(saved);Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k)}})}""",saved)
  await fresh.set_content(HTML,wait_until='load')
  check(await fresh.locator('.thumbRow').count()==5,'launch stays on default document, no implicit recovery')
  check(await fresh.locator('body').get_attribute('data-aster-theme')=='light','preference retained across new document')
  check(await fresh.locator('#recoveryIndicator').is_visible(),'visible indicator for available recovery')
  check(not errors,'no JavaScript exceptions '+str(errors[:3]))
  for name,ok in checks:print(('PASS' if ok else 'FAIL'),name)
  print('BROWSER',sum(x[1] for x in checks),'/',len(checks))
  await browser.close()
  return all(x[1] for x in checks)
if __name__=='__main__':
 result=asyncio.run(main())
 sys.exit(0 if result else 1)
