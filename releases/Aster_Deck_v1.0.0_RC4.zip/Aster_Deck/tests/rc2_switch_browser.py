from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1480,'height':880});page.set_content((ROOT/'index.html').read_text());page.locator('.addSlide').click()
 page.locator('[data-command="insert.text"]').first.click()
 A=page.locator('#stage .element.text').first
 # set first text directly, second text separate position
 page.locator('[data-prop="text"]').fill('첫번째 글자');page.locator('[data-prop="text"]').dispatch_event('change')
 objid=page.evaluate('selected')
 page.locator('[data-command="insert.text"]').first.click()
 # shift second down so clicks don't overlap
 page.locator('[data-prop="y"]').fill('290');page.locator('[data-prop="y"]').dispatch_event('change')
 page.locator('[data-prop="text"]').fill('두번째 글자');page.locator('[data-prop="text"]').dispatch_event('change')
 first=page.locator(f'#stage [data-id="{objid}"]');r=first.bounding_box();page.mouse.click(r['x']+r['width']*.2,r['y']+r['height']*.42)
 assert page.evaluate('editing?.id')==objid
 # edit first by adding ! at end
 page.keyboard.press('End');page.keyboard.insert_text(' !');print('FIRST IN EDIT',first.inner_text())
 secondid=page.evaluate('slide().elements.find(x=>x.id!=="'+objid+'").id')
 second=page.locator(f'#stage [data-id="{secondid}"]');r=second.bounding_box();page.mouse.click(r['x']+r['width']*.2,r['y']+r['height']*.42)
 print('after switch edit id',page.evaluate('editing?.id'),'first saved',page.evaluate('slide().elements[0].text'))
 assert page.evaluate('editing?.id')==secondid
 assert page.evaluate('slide().elements.find(x=>x.id==="'+objid+'").text').endswith(' !')
 page.keyboard.press('End');page.keyboard.insert_text(' END')
 r=second.bounding_box();xy=(r['x']+1.5,r['y']+r['height']*.51)
 page.mouse.move(*xy);page.mouse.down();page.mouse.move(xy[0]+28,xy[1]+6,steps=5);page.mouse.up()
 print('second edited saved',page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").text'))
 print('second bounds',page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").x'),page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").w'))
 assert page.evaluate('editing===null')
 assert page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").text').endswith(' END')
 assert page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").x')>115
 assert page.evaluate('slide().elements.find(x=>x.id==="'+secondid+'").w')==470
 print('PASS multiple text edits + border move without escape')
 browser.close()
