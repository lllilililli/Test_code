import test from 'node:test';
import assert from 'node:assert/strict';
import {zipRead,zipWrite,ZIP_LIMITS} from '../src/zip.js';
import {createRecovery} from '../src/workspace.js';
import {makeDeck,Store,makeDemoDeck,addSlide,shape} from '../src/core.js';
import {exportPptx} from '../src/pptx.js';
const memory=()=>{const m=new Map();return {getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k)}};
const mutate=(bytes, fn)=>{const v=new Uint8Array(bytes);fn(v,new DataView(v.buffer));return v};
const eocd=x=>x.length-22;
const central=x=>new DataView(x.buffer,x.byteOffset,x.byteLength).getUint32(eocd(x)+16,true);
test('RC: ZIP CRC tamper is detected',async()=>{
 const v=mutate(zipWrite({'slide.xml':'ABCD'}),(b)=>{b[30+'slide.xml'.length]^=0x4});
 await assert.rejects(zipRead(v),/CRC/);
});
test('RC: ZIP rejects malformed local headers',async()=>{
 const v=mutate(zipWrite({'slide.xml':'Hi'}),(b)=>{b[0]=0});
 await assert.rejects(zipRead(v),/로컬 헤더/);
});
test('RC: ZIP rejects undeclared expanded sizes before decompression',async()=>{
 const v=mutate(zipWrite({'x':'Hi'}),(b,d)=>{d.setUint32(central(b)+24,ZIP_LIMITS.maxEntry+1,true)});
 await assert.rejects(zipRead(v),/안전 제한/);
});
test('RC: ZIP rejects malicious parent paths',async()=>{
 await assert.rejects(zipRead(zipWrite({'../evil.xml':'X'})),/이름/);
});
test('RC: ZIP rejects duplicate entries even when central directory repeats a name',async()=>{
 const v=mutate(zipWrite({'fileA':'1','fileB':'2'}),(b,d)=>{
  const pos=central(b), second=pos+46+5;
  for(let k=0;k<5;k++)b[second+46+k]=b[pos+46+k];
 });
 await assert.rejects(zipRead(v),/이름/);
});
test('RC: ZIP rejects declared size different from actual',async()=>{
 const v=mutate(zipWrite({'a':'Hi'}),(b,d)=>{d.setUint32(central(b)+24,1,true)});
 await assert.rejects(zipRead(v),/크기/);
});
test('RC: ZIP rejects invalid directory range',async()=>{
 const v=mutate(zipWrite({'a':'Hi'}),(b,d)=>{d.setUint32(eocd(b)+16,999999,true)});
 await assert.rejects(zipRead(v),/중앙 디렉터리/);
});
test('RC: ZIP refuses encrypted entries',async()=>{
 const v=mutate(zipWrite({'a':'Hi'}),(b,d)=>{d.setUint16(central(b)+8,1,true)});
 await assert.rejects(zipRead(v),/암호화/);
});
test('RC: ZIP verifies honest archive with binary image',async()=>{
 const png=Uint8Array.from([0,1,2,251,253,255]);
 const entries=await zipRead(zipWrite({'ppt/media/x.png':png,'ppt/a.xml':'<p/>'}));
 assert.deepEqual(entries['ppt/media/x.png'],png);
 assert.equal(new TextDecoder().decode(entries['ppt/a.xml']),'<p/>');
});
test('RC: recovery snapshots do not collide at the same timestamp',()=>{
 const store=memory(),rec=createRecovery(store,{now:()=>123456});const doc=makeDeck();
 const ids=[];for(let i=0;i<3;i++){doc.title='제목'+i;ids.push(rec.write(doc).id)}
 assert.equal(new Set(ids).size,3);
 assert.deepEqual(rec.list().map(x=>rec.read(x.id).title).sort(),['제목0','제목1','제목2']);
});
test('RC: recovery keeps existing snapshot when storage full',()=>{
 const mem=memory(),rec=createRecovery(mem),doc=makeDeck();
 const first=rec.write(doc);const before=mem.getItem('aster.workspace.recovery.v096');
 mem.setItem=()=>{throw Error('quota')};doc.title='new';assert.equal(rec.write(doc).ok,false);
 assert.equal(mem.getItem('aster.workspace.recovery.v096'),before);
 assert.ok(rec.read(first.id));
});
test('RC: PPTX full deck is readable as ZIP without errors',async()=>{
 const deck=makeDemoDeck();const zip=await zipRead(exportPptx(deck));
 assert.equal(Object.keys(zip).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).length,5);
 assert.ok(zip['ppt/presentation.xml']);
});
test('RC: 180-slide document exports readable PPTX',async()=>{
 const doc=makeDeck();for(let i=1;i<180;i++)addSlide(doc);
 const files=await zipRead(exportPptx(doc));
 assert.equal(Object.keys(files).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).length,180);
});
test('RC: undo and redo leave document structurally valid',()=>{
 const s=new Store();for(let i=0;i<30;i++)s.execute(d=>d.slides[0].elements.push(shape('rect')));
 for(let i=0;i<30;i++)assert.ok(s.undo());
 assert.equal(s.deck.slides[0].elements.length,0);
 for(let i=0;i<30;i++)assert.ok(s.redo());
 assert.equal(s.deck.slides[0].elements.length,30);
});
