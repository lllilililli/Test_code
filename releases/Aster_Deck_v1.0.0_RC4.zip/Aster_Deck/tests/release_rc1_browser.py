"""Smoke test for the bundled, dependency-free RC HTML (data-injected due file:// lockdown)."""
import asyncio, json, sys, time, pathlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
CHECKS=[]
def ck(ok,label):
 CHECKS.append((label,bool(ok)))
 print(('PASS' if ok else 'FAIL')+' '+label,flush=True)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1540,'height':940},accept_downloads=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content((ROOT/'index.html').read_text('utf-8'),wait_until='load')
  ck(await page.locator('.version').inner_text()=='v1.0.0 RC4','RC version visible')
  ck(await page.locator('.thumbRow').count()==5,'initial slide deck')
  await page.locator('[data-command="slide.add"]').first.click()
  ck(await page.locator('.thumbRow').count()==6,'new slide button')
  await page.keyboard.press('Control+z')
  ck(await page.locator('.thumbRow').count()==5,'undo new slide')
  await page.keyboard.press('Control+y')
  ck(await page.locator('.thumbRow').count()==6,'redo new slide')
  async with page.expect_download() as dl:
   await page.evaluate("command('file.exportJson')")
  d=await dl.value
  target=ROOT.parent/'rc-check-project.aster.json';await d.save_as(str(target))
  doc=json.loads(target.read_text('utf-8'))
  ck(len(doc['slides'])==6,'download project has six slides')
  async with page.expect_download(timeout=30000) as dl:
   await page.evaluate("command('file.exportPptx')")
  d=await dl.value
  target=ROOT.parent/'rc-check-export.pptx';await d.save_as(str(target))
  ck(target.stat().st_size>10000,'browser PPTX downloaded')
  # Browser import of its own export
  page.once('dialog',lambda d:d.accept())
  await page.locator('#openFile').set_input_files(str(target))
  await page.wait_for_timeout(500)
  ck(await page.locator('.thumbRow').count()==6,'browser re-import of exported PPTX')
  # Import user's former PowerPoint test file to catch compatibility regressions.
  user_file=pathlib.Path('/mnt/data/test.pptx')
  await page.locator('#openFile').set_input_files(str(user_file if user_file.exists() else target))
  await page.wait_for_timeout(500)
  expected=5 if user_file.exists() else 6
  ck(await page.locator('.thumbRow').count()==expected,'open verified PPTX')
  ck(not await page.evaluate('dirtySinceExport') and '내보내기 전' in (await page.locator('#saveStatus').inner_text()),'import marked clean without claiming disk save')
  # File-open failure should not replace the current document.
  await page.locator('#openFile').set_input_files({'name':'corrupt.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':b'not-a-zip'})
  await page.wait_for_timeout(250)
  ck(await page.locator('.thumbRow').count()==expected,'corrupted PPTX cannot replace deck')
  ck('열기 실패' in await page.locator('#toast').inner_text(),'corruption error shown')
  # Copy/export after failed open still works.
  async with page.expect_download(timeout=30000) as dl:
   await page.evaluate("command('file.exportPptx')")
  d=await dl.value
  target=ROOT.parent/'rc-check-preserved.pptx';await d.save_as(str(target))
  ck(target.stat().st_size>10000,'valid document remains exportable after failed open')
  # UI reliability under dark mode and command palette.
  await page.keyboard.press('Control+k')
  ck(await page.locator('#commandPalette').evaluate('(x)=>x.open'),'command search opens')
  await page.keyboard.press('Escape')
  await page.locator('[data-command="ui.theme"]').first.click()
  ck(await page.locator('body').get_attribute('data-aster-theme')=='dark','dark mode')
  await page.locator('[data-command="ui.theme"]').first.click()
  ck(await page.locator('body').get_attribute('data-aster-theme')=='light','return light mode')
  # Persistence is opt-in recovery only, never auto-restored on fresh page.
  await page.evaluate('''() => {const d=makeDeck();for(let i=1;i<180;i++)addSlide(d);store.load(d);}''')
  ck(await page.locator('.thumbRow').count()==180,'180 slides in editor')
  ck(await page.locator('.thumbContent').count()<35,'thumbnails virtualized')
  ck(not errors,'no unhandled JavaScript errors '+str(errors[:2]))
  await browser.close()
 for f in [ROOT.parent/'rc-check-project.aster.json',ROOT.parent/'rc-check-export.pptx',ROOT.parent/'rc-check-preserved.pptx']:
  f.unlink(missing_ok=True)
 print(f'RC_BROWSER {sum(ok for _,ok in CHECKS)}/{len(CHECKS)}',flush=True)
 return all(ok for _,ok in CHECKS)
if __name__=='__main__':sys.exit(0 if asyncio.run(main()) else 1)
