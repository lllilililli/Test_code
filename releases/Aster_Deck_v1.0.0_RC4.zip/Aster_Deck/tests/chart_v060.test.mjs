import test from 'node:test';
import assert from 'node:assert/strict';
import {parseDelimited,tableToChart,chartCsv} from '../src/chart-data.js';
import {chartRows,chartXml,chartGraphic,xlsxForChart} from '../src/native-chart.js';
import {makeDeck,makeChart,Store} from '../src/core.js';
import {exportPptx} from '../src/pptx.js';
import {zipRead,zipText} from '../src/zip.js';

test('quoted CSV multiline text and commas',()=>assert.deepEqual(parseDelimited('name,amount\r\n"빵,식사",12\r\n"한\n줄",20'),[['name','amount'],['빵,식사','12'],['한\n줄','20']]));
test('semicolon and tab auto-detection',()=>{assert.equal(parseDelimited('name;value\n가;12')[1][1],'12');assert.equal(parseDelimited('name\tvalue\n가\t14')[1][1],'14')});
test('BOM stripped and escaped quotes parsed',()=>assert.equal(parseDelimited('\ufeffa,b\r\n"""hello""",4')[1][0],'"hello"'));
test('bad quote detection',()=>assert.throws(()=>parseDelimited('a,b\n"missing,3')));
test('numeric mapping rejects headers and invalid rows',()=>assert.deepEqual(tableToChart([['A','10'],['B','2'],['C','bad']],0,1),{data:[{label:'A',value:10},{label:'B',value:2}],skipped:1,limited:false}));
test('reject same columns',()=>assert.throws(()=>tableToChart([['A','4']],1,1)));
test('CSV export and import preserve Korean and labels with commas',()=>{const d=[{label:'소금빵,한정',value:120},{label:'바게트',value:33.5}];assert.deepEqual(tableToChart(parseDelimited(chartCsv(d)).slice(1)).data,d)});
test('chart workbook is a valid independent xlsx zip',async()=>{const e=makeChart();const z=await zipRead(xlsxForChart(e));assert.ok(z['xl/workbook.xml']);assert.ok(z['xl/worksheets/sheet1.xml']);assert.match(zipText(z,'xl/worksheets/sheet1.xml'),/분기/)});
test('native chart references its series and embedded workbook',async()=>{const e=makeChart();e.chartTitle='매출';const d=makeDeck();d.slides[0].elements.push(e);const z=await zipRead(exportPptx(d,null));assert.ok(z['ppt/charts/chart1_0.xml']);assert.ok(z['ppt/embeddings/asterData1_0.xlsx']);assert.match(zipText(z,'ppt/slides/slide1.xml'),/graphicFrame/);assert.match(zipText(z,'ppt/charts/chart1_0.xml'),/barChart/);assert.match(zipText(z,'ppt/slides/_rels/slide1.xml.rels'),/chart1_0.xml/)});
test('line chart uses native lineChart and graph axes',async()=>{const d=makeDeck(),e=makeChart();e.chartType='line';d.slides[0].elements.push(e);const z=await zipRead(exportPptx(d,null));assert.match(zipText(z,'ppt/charts/chart1_0.xml'),/<c:lineChart>/);assert.match(zipText(z,'ppt/charts/chart1_0.xml'),/<c:valAx>/)});
test('chart data is undoable and redoable',()=>{const d=makeDeck();d.slides[0].elements.push(makeChart());const store=new Store(d);store.execute(x=>x.slides[0].elements[0].chartData=[{label:'월',value:12}]);store.undo();assert.equal(store.deck.slides[0].elements[0].chartData.length,4);store.redo();assert.equal(store.deck.slides[0].elements[0].chartData[0].value,12)});
