from pathlib import Path
from io import BytesIO
from pptx import Presentation
from pptx.util import Inches
from playwright.sync_api import sync_playwright
import zipfile
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,value):
 assert value,name
 checks.append(name);print('PASS',name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=b.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.set_content((ROOT/'index.html').read_text())
 note='한글 발표자 노트 & <태그> "인용"\n\n둘째 문단\n끝 줄'
 p.evaluate("""text=>{const d=makeDeck();d.slides[0].notes=text;addSlide(d,1);addSlide(d,2);d.slides[2].notes='3번 노트';replaceDocument(d)}""",note)
 data=bytes(p.evaluate('Array.from(exportPptx(store.deck,null))'))
 pres=Presentation(BytesIO(data))
 check('PowerPoint package reader sees Korean notes',pres.slides[0].notes_slide.notes_text_frame.text==note)
 check('empty slide has no notes relationship',not pres.slides[1].has_notes_slide)
 check('third slide keeps its own notes',pres.slides[2].notes_slide.notes_text_frame.text=='3번 노트')
 audit=p.evaluate('async data=>await verifyPptx(new Uint8Array(data),3)',list(data))
 check('notes OPC package passes verifier',bool(audit))
 p.evaluate('async data=>{window.notesImported=await importPptx(new Uint8Array(data))}',list(data))
 check('standard export reimports exact paragraphs',p.evaluate('window.notesImported.slides[0].notes')==note)
 check('third slide reimports correct notes',p.evaluate('window.notesImported.slides[2].notes')=='3번 노트')
 native=bytes(p.evaluate('Array.from(exportPptx(store.deck,store.deck))'))
 p.evaluate('async data=>{window.notesImported=await importPptx(new Uint8Array(data))}',list(native))
 check('editable export retains notes snapshot',p.evaluate('window.notesImported.slides[0].notes')==note)
 # Independent application-generated fixture includes a soft break and body placeholder.
 external=Presentation();slide=external.slides.add_slide(external.slide_layouts[6]);slide.shapes.add_textbox(Inches(1),Inches(1),Inches(4),Inches(1)).text='External slide'
 external_note='외부 노트\n두 번째\v같은 문단 줄바꿈';slide.notes_slide.notes_text_frame.text=external_note
 stream=BytesIO();external.save(stream);source=stream.getvalue()
 p.evaluate('async data=>{const bytes=new Uint8Array(data);replaceDocument(await importPptx(bytes),bytes)}',list(source))
 check('external notes paragraphs and soft breaks imported',p.evaluate('store.deck.slides[0].notes')==external_note.replace('\v','\n'))
 check('unchanged notes preserve eligibility',p.evaluate('preservationReport(sourcePptx.deck,store.deck).safe'))
 preserved=bytes(p.evaluate('async()=>Array.from(await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck))'))
 check('unchanged original including notes is byte-identical',preserved==source)
 p.evaluate("update(d=>d.slides[0].elements[0].x+=10)")
 preserved=bytes(p.evaluate('async()=>Array.from(await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck))'))
 with zipfile.ZipFile(BytesIO(source)) as a,zipfile.ZipFile(BytesIO(preserved)) as c:
  parts=[n for n in a.namelist() if n.startswith(('ppt/notesSlides/','ppt/notesMasters/'))]
  check('shape movement preserves all original notes parts',all(a.read(n)==c.read(n) for n in parts))
 p.evaluate("update(d=>d.slides[0].notes='수정한 발표자 노트')")
 check('external notes edit requires explicit regeneration',not p.evaluate('preservationReport(sourcePptx.deck,store.deck).safe'))
 regenerated=bytes(p.evaluate('Array.from(exportPptx(store.deck,null))'))
 check('regenerated standard PPTX contains edited notes',Presentation(BytesIO(regenerated)).slides[0].notes_slide.notes_text_frame.text=='수정한 발표자 노트')
 check('no browser runtime errors',not errors)
 b.close()
print('RC4_NOTES',len(checks),'PASS')
