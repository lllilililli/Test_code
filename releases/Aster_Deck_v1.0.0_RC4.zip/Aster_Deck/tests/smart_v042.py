"""Headless Chromium integration testing the offline single HTML build."""
from pathlib import Path
from io import BytesIO
from pptx import Presentation
from playwright.sync_api import sync_playwright
import json,zipfile
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,result):
 assert result,name
 print('PASS',name,flush=True)
 checks.append(name)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1740,'height':980},accept_downloads=True)
 page=context.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 page.locator('.addSlide').click()
 page.locator('[data-tab="insert"]').click()
 for i,cmd in enumerate(['insert.rounded','insert.rounded','insert.rounded']):
  page.locator(f'[data-command="{cmd}"]').first.click()
  page.locator('[data-prop="x"]').fill(str(85+i*295));page.locator('[data-prop="x"]').dispatch_event('change')
  page.locator('[data-prop="y"]').fill(str(170+i*16));page.locator('[data-prop="y"]').dispatch_event('change')
 def all_el():return page.evaluate('structuredClone(store.deck.slides[1].elements)')
 def selected():return page.evaluate('[...selectedIds]')
 check('three cards inserted',len(all_el())==3)
 a,b,c=[x['id'] for x in all_el()]
 # Select exactly two cards with CTRL click
 page.locator(f'#stage .element[data-id="{a}"]').click()
 page.locator(f'#stage .element[data-id="{b}"]').click(modifiers=['Control'])
 check('two objects selected for connector',len(selected())==2)
 page.locator('[data-tab="arrange"]').click()
 page.locator('[data-command="connector.add"]').click()
 check('connector command adds semantic edge',len(all_el())==4 and all_el()[3]['from']==a and all_el()[3]['to']==b)
 edge=all_el()[3]['id']
 check('SVG connection exists on stage',page.locator('#stage .connector-visible').count()==1)
 before=page.locator('#stage .connector-visible').get_attribute('d')
 # Move a connected node by keyboard via layer inspector
 page.locator(f'[data-layer-select="{a}"]').click()
 page.locator('#stage').focus();page.keyboard.press('Shift+ArrowRight')
 after=page.locator('#stage .connector-visible').get_attribute('d')
 check('moving shape updates attached endpoints',before!=after)
 page.keyboard.press('Control+z')
 check('undo restores connector endpoints',page.locator('#stage .connector-visible').get_attribute('d')==before)
 page.keyboard.press('Control+y')
 check('redo recomputes endpoints',page.locator('#stage .connector-visible').get_attribute('d')==after)
 # manipulate connector route through inspector
 page.locator(f'[data-layer-select="{edge}"]').click()
 check('connector inspector exposes endpoints',page.locator('[data-prop="from"]').count()==1 and page.locator('[data-prop="to"]').count()==1)
 page.locator('[data-prop="route"]').select_option('straight')
 check('straight connector stores route',all_el()[3]['route']=='straight')
 check('straight connector renders as one segment',page.locator('#stage .connector-visible').get_attribute('d').count('L')==1)
 page.locator('[data-prop="route"]').select_option('elbow')
 check('elbow connector can be restored',all_el()[3]['route']=='elbow')
 # Select three via keyboard to grid
 page.locator(f'[data-layer-select="{a}"]').click()
 page.locator(f'[data-layer-select="{b}"]').click(modifiers=['Control'])
 page.locator(f'[data-layer-select="{c}"]').click(modifiers=['Control'])
 check('three shape selection survives connector',len(selected())==3)
 page.locator('[data-command="smart.grid"]').click()
 check('smart layout moves shapes',all_el()[0]['x']!=all_el()[1]['x'])
 check('smart layout keeps connector attached',page.locator('#stage .connector-visible').count()==1)
 page.locator('[data-command="smart.horizontal"]').click()
 check('horizontal layout orders 3 shapes',all(rows[i]['x']+rows[i]['w']<rows[i+1]['x'] for rows in [[*sorted(all_el()[:3],key=lambda e:e['x'])]] for i in range(len(rows)-1)))
 page.locator('[data-command="smart.vertical"]').click()
 check('vertical layout stacks 3 shapes',all(rows[i]['y']+rows[i]['h']<rows[i+1]['y'] for rows in [[*sorted(all_el()[:3],key=lambda e:e['y'])]] for i in range(len(rows)-1)))
 # Magnetic guide is a transient drag-only overlay, not persisted document data.
 page.locator(f'[data-layer-select="{a}"]').click()
 field=page.locator('[data-prop="x"]');field.fill('100');field.dispatch_event('change')
 bb=page.locator(f'#stage .rounded[data-id="{a}"]').bounding_box()
 startx=bb['x']+bb['width']/2;starty=bb['y']+bb['height']/2
 page.mouse.move(startx,starty);page.mouse.down()
 page.mouse.move(startx+280*page.evaluate('zoom'),starty,steps=8)
 check('orange alignment guide appears during drag',page.locator('#stage .snap-guide').count()>0)
 page.mouse.up()
 check('alignment guide clears on mouse release',page.locator('#stage .snap-guide').count()==0)
 check('snap drag commits updated geometry',abs(next(e for e in all_el() if e['id']==a)['x']-380)<8)
 # Aster project round trip
 with page.expect_download() as dl:page.locator('[data-command="file.exportJson"]').first.click()
 saved=json.loads(dl.value.path().read_text())
 check('JSON stores live connector endpoints',any(e.get('type')=='connector' and e.get('from')==a for e in saved['slides'][1]['elements']))
 page.locator('#openFile').set_input_files({'name':'smart.aster.json','mimeType':'application/json','buffer':json.dumps(saved).encode()})
 page.locator('[data-slide]').nth(1).click()
 check('imported JSON reattaches live connector',page.locator('#stage .connector-visible').count()==1)
 with page.expect_download() as dl:page.locator('[data-command="file.exportPptx"]').first.click()
 data=dl.value.path().read_bytes()
 slides=Presentation(BytesIO(data))
 check('PowerPoint-compatible PPTX opens with python-pptx',len(slides.slides)==6)
 check('standard PPTX contains editable line geometry',sum(sh.shape_type==9 for sh in slides.slides[1].shapes)>=1)
 with zipfile.ZipFile(BytesIO(data)) as z:
  xml=z.read('ppt/slides/slide2.xml').decode()
  check('PPTX contains valid cxnSp drawing elements',xml.count('<p:cxnSp>')>=1)
 page.locator('[data-tab="file"]').click()
 with page.expect_download() as dl:page.locator('[data-command="file.exportPptxNative"]').first.click()
 native=dl.value.path().read_bytes()
 page.locator('#openFile').set_input_files({'name':'smart-editable.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':native})
 page.locator('[data-slide]').nth(1).click()
 check('native PPTX preserves dynamic connection',any(e.get('type')=='connector' and e.get('from')==a for e in all_el()))
 # Duplicate slides must rewire connector endpoints to new slide object IDs.
 page.locator('[data-tab="home"]').click()
 page.locator('[data-command="slide.duplicate"]').first.click()
 duplicated=page.evaluate('structuredClone(store.deck.slides[2].elements)')
 cloned_ids={e['id'] for e in duplicated}
 check('slide duplicate reassigns connector endpoints to cloned nodes',all(e.get('from') in cloned_ids and e.get('to') in cloned_ids for e in duplicated if e['type']=='connector'))
 page.locator('#slideList [data-slide]').nth(1).click()
 # When deleting node, only its attached connector should disappear
 page.locator(f'[data-layer-select="{a}"]').click()
 page.locator('[data-command="object.delete"]').last.click()
 check('delete node removes dangling connector',not any(e.get('type')=='connector' for e in all_el()))
 check('no browser JavaScript errors',not errors)
 browser.close()
print('TOTAL',len(checks))
