import test from 'node:test';
import assert from 'node:assert/strict';
import {makeDeck,makeSlide,shape} from '../src/core.js';
import {exportPptx} from '../src/pptx.js';
import {zipRead,zipText} from '../src/zip.js';
import {preservationReport} from '../src/preserve.js';

test('grouped shapes remain native DrawingML group and child shapes',async()=>{
 const d=makeDeck(),a=shape('rect'),b=shape('text',330,180);a.groupId='g';b.groupId='g';d.slides[0].elements=[a,b];
 const zip=await zipRead(exportPptx(d,null)),part=zipText(zip,'ppt/slides/slide1.xml');
 assert.match(part,/<p:grpSp>/);assert.equal(part.match(/<p:sp>/g).length,2);
 assert.match(part,/name="Aster group"/);
});
test('master objects are written only to the physical slideMaster part',async()=>{
 const d=makeDeck();d.master.elements.push(Object.assign(shape('text'),{text:'FOOTER'}));
 d.slides[0].hideMaster=true;
 const zip=await zipRead(exportPptx(d,null));
 assert.match(zipText(zip,'ppt/slideMasters/slideMaster1.xml'),/FOOTER/);
 assert.doesNotMatch(zipText(zip,'ppt/slides/slide1.xml'),/FOOTER/);
 assert.match(zipText(zip,'ppt/slides/slide1.xml'),/showMasterSp="0"/);
});
test('auto-fit mode has standards-defined DrawingML payload',async()=>{
 const d=makeDeck();d.slides[0].elements=[Object.assign(shape('text'),{textAutoFit:'shrink'}),Object.assign(shape('text',430,130),{textAutoFit:'resize'})];
 const z=await zipRead(exportPptx(d,null)),x=zipText(z,'ppt/slides/slide1.xml');
 assert.match(x,/<a:normAutofit\/>/);assert.match(x,/<a:spAutoFit\/>/);
});
test('conservative preservation allows geometry and blocks extra shape or reordering',()=>{
 const d=makeDeck(),e=shape('rect');e._pptxShapeId='2';d.slides[0]._pptxSlidePath='ppt/slides/slide1.xml';d.slides[0].elements=[e];
 const edit=structuredClone(d);edit.slides[0].elements[0].x+=20;
 assert.equal(preservationReport(d,edit).safe,true);
 edit.slides[0].elements.push(shape('star'));assert.equal(preservationReport(d,edit).safe,false);
});
test('preservation refuses editing source charts without a compatible patcher',()=>{
 const d=makeDeck(),e=shape('chart');e._pptxShapeId='3';d.slides[0]._pptxSlidePath='ppt/slides/slide1.xml';d.slides[0].elements=[e];
 const next=structuredClone(d);next.slides[0].elements[0].x++;
 assert.equal(preservationReport(d,next).safe,false);
});
