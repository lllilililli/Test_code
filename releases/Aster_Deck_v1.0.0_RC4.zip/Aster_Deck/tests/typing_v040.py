from playwright.sync_api import sync_playwright
from pathlib import Path
P=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1510,'height':900});page.set_content((P/'index.html').read_text())
 page.locator('.addSlide').click();page.locator('[data-command="insert.text"]').first.click()
 e=page.locator('#stage .element.text');e.dblclick();e.press('ControlOrMeta+A');page.keyboard.insert_text('한글 테스트 ABC');e.press('Enter');page.keyboard.insert_text('두 번째 줄');page.locator('#deckTitle').click()
 model=page.evaluate('store.deck.slides[1].elements[0]');print('TYPED',repr(model['text']),model.get('runs'))
 assert model['text']=='한글 테스트 ABC\n두 번째 줄',model['text']
 page.locator('#stage .element.text').dblclick()
 page.evaluate('''()=>{let n=document.querySelector('#stage .element.text .rich-body span').firstChild;let s=window.getSelection(),r=document.createRange();r.setStart(n,0);r.setEnd(n,2);s.removeAllRanges();s.addRange(r);document.dispatchEvent(new Event('selectionchange'))}''')
 page.locator('[data-command="format.bold"]').first.click();model=page.evaluate('store.deck.slides[1].elements[0]');print('BOLD',model['runs'])
 assert model['runs'][0]['bold'] and model['runs'][0]['text']=='한글',model
 # popup shot
 page.locator('[data-command="font.explorer"]').first.click()
 b.close()
print('KOREAN INPUT + PARTIAL BOLD: 2 / 2')
