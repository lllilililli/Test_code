"""v0.4.1 browser E2E: multi-selection, grouping, locking, positioning, layers, export."""
from pathlib import Path
from io import BytesIO
import json
from pptx import Presentation
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(label,ok):
 assert ok,label
 checks.append(label)
 print('PASS',label,flush=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1680,'height':970},accept_downloads=True)
 page=context.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 page.locator('.addSlide').click()
 page.locator('[data-tab="insert"]').click()
 for cmd,x,y in [('insert.rect',45,130),('insert.ellipse',360,130),('insert.star',650,130),('insert.text',350,345)]:
  page.locator(f'[data-command="{cmd}"]').first.click()
  for prop,value in [('x',x),('y',y)]:
   field=page.locator(f'[data-prop="{prop}"]');field.fill(str(value));field.dispatch_event('change')
 def model():return page.evaluate('JSON.parse(JSON.stringify(store.deck))')
 def els():return model()['slides'][1]['elements']
 def selected():return page.evaluate('[...selectedIds]')
 ids=[e['id'] for e in els()]
 check('four editable shapes created',len(ids)==4)
 # exact group selection via Ctrl-click after single-click
 page.locator('#stage .rect').first.click()
 page.locator('#stage .ellipse').click(modifiers=['Control'])
 check('Ctrl-click selects 2 objects',len(selected())==2)
 page.locator('#stage .ellipse').click(modifiers=['Shift'])
 check('Shift click deselects an object',len(selected())==1)
 page.locator('#stage .ellipse').click(modifiers=['Shift'])
 check('Shift click reselects an object',len(selected())==2)
 check('Inspector reports multi-selection',page.locator('#propertiesBody').inner_text().find('2개 개체 선택')>=0)
 page.locator('#stage').focus();page.keyboard.press('Control+g')
 check('Ctrl+G creates non-destructive group',els()[0].get('groupId') and els()[0].get('groupId')==els()[1].get('groupId'))
 page.keyboard.press('Control+Shift+g')
 check('Ctrl+Shift+G ungroups via shortcut',not els()[0].get('groupId') and not els()[1].get('groupId'))
 page.keyboard.press('Control+z')
 check('Ctrl+Z restores group after ungroup',els()[0].get('groupId') and els()[0]['groupId']==els()[1]['groupId'])
 group_id=els()[0]['groupId'];original=[(e['x'],e['y']) for e in els()[:2]]
 # grouped shape selects its entire group when clicked
 page.locator('#stage .rect').first.click()
 check('clicking a group selects both',set(selected())==set(ids[:2]))
 # resizing the whole group keeps relative positions and creates one undo entry
 handle=page.locator('.selection-resize-handle');check('group has resize handle',handle.count()==1)
 old_bounds=[(e['x'],e['y'],e['w'],e['h']) for e in els()[:2]]
 hb=handle.bounding_box();mx=hb['x']+hb['width']/2;my=hb['y']+hb['height']/2
 page.mouse.move(mx,my);page.mouse.down();page.mouse.move(mx+36,my+24,steps=8);page.mouse.up()
 after_bounds=[(e['x'],e['y'],e['w'],e['h']) for e in els()[:2]]
 check('group resize scales both shapes',after_bounds[0][2]>old_bounds[0][2] and after_bounds[1][2]>old_bounds[1][2])
 page.keyboard.press('Control+z')
 check('group resize undoes in one step',[(e['x'],e['y'],e['w'],e['h']) for e in els()[:2]]==old_bounds)
 # keyboard moves the group atomically
 page.locator('#stage').focus();page.keyboard.press('ArrowRight')
 check('group keyboard movement affects both',els()[0]['x']==original[0][0]+1 and els()[1]['x']==original[1][0]+1)
 page.keyboard.press('Control+z')
 check('Ctrl+Z reverses group nudge',[(e['x'],e['y']) for e in els()[:2]]==original)
 page.keyboard.press('Control+y')
 check('Ctrl+Y reapplies group nudge',els()[0]['x']==original[0][0]+1)
 # pointer drag group
 rect=page.locator('#stage .rect').bounding_box();before=[(e['x'],e['y']) for e in els()[:2]]
 page.mouse.move(rect['x']+rect['width']/2,rect['y']+rect['height']/2)
 page.mouse.down();page.mouse.move(rect['x']+rect['width']/2+35,rect['y']+rect['height']/2+19,steps=8);page.mouse.up()
 moved=[(e['x'],e['y']) for e in els()[:2]]
 check('pointer dragging moves both group members',moved[0]!=before[0] and (moved[0][0]-before[0][0]==moved[1][0]-before[1][0]))
 page.locator('[data-tab="arrange"]').click()
 # group selected remains active
 page.locator('[data-command="object.lock"]').first.click()
 check('Lock protects both group members',els()[0].get('locked') and els()[1].get('locked'))
 page.keyboard.press('Delete')
 check('Locked objects resist Delete',len(els())==4)
 pos=[(e['x'],e['y']) for e in els()[:2]]
 page.locator('#stage').focus();page.keyboard.press('Shift+ArrowRight')
 check('Locked objects resist keyboard moves',[(e['x'],e['y']) for e in els()[:2]]==pos)
 page.locator('[data-command="object.unlock"]').first.click()
 check('Unlock releases both group members',not els()[0].get('locked') and not els()[1].get('locked'))
 page.locator('[data-command="object.duplicate"]').first.click()
 check('Group duplication copies both shapes',len(els())==6)
 new=els()[-2:];check('Duplicates have new group ID',new[0].get('groupId')==new[1].get('groupId') and new[0].get('groupId')!=group_id)
 page.locator('[data-command="object.front"]').first.click()
 check('Bring to front retains selected group on top',[e['id'] for e in els()[-2:]]==[e['id'] for e in new])
 page.locator('[data-command="object.back"]').first.click()
 check('Send to back puts selected group behind',[e['id'] for e in els()[:2]]==[e['id'] for e in new])
 # grouping leaves original, and undo restores layer order
 page.locator('[data-command="edit.undo"]').first.click()
 check('Undo restores front layer arrangement',[e['id'] for e in els()[-2:]]==[e['id'] for e in new])
 page.locator('[data-command="object.ungroup"]').first.click()
 check('Ungroup removes only selected group IDs',all(not e.get('groupId') for e in els() if e['id'] in {m['id'] for m in new}))
 check('Ungroup preserves old original group',els()[0].get('groupId')==group_id)
 # selection through layer list, including lock button
 page.locator('[data-layer-select]').first.click()
 check('Layers panel selects object',len(selected())>=1)
 sid=selected()[0]
 page.locator(f'[data-layer-lock="{sid}"]').click()
 check('Layer lock button works',next(e for e in els() if e['id']==sid).get('locked',False))
 page.locator(f'[data-layer-lock="{sid}"]').click()
 check('Layer lock button unlocks',not next(e for e in els() if e['id']==sid).get('locked',False))
 # independent distribution test on original three ungrouped/ungroup as necessary
 page.locator('#stage').focus();page.keyboard.press('Control+a')
 check('Ctrl+A selects all slide objects',len(selected())==len(els()))
 page.locator('[data-command="object.distributeX"]').first.click()
 check('Distribute X changes positions',len(els())==6)
 # keep native metadata and standard flattened shapes
 with page.expect_download() as dl:page.locator('[data-command="file.exportJson"]').first.click()
 snapshot=json.loads(dl.value.path().read_text(encoding='utf-8'))
 check('Project JSON retains grouping',any(e.get('groupId') for e in snapshot['slides'][1]['elements']))
 with page.expect_download() as dl:page.locator('[data-command="file.exportPptx"]').first.click()
 presentation=Presentation(BytesIO(dl.value.path().read_bytes()))
 check('PPTX stores all shapes non-destructively',sum(len(sh.shapes) if hasattr(sh,'shapes') else 1 for sh in presentation.slides[1].shapes)>=6)
 page.locator('[data-tab="file"]').click()
 with page.expect_download() as dl:page.locator('[data-command="file.exportPptxNative"]').first.click()
 native_bytes=dl.value.path().read_bytes()
 page.locator('#openFile').set_input_files({'name':'group-demo.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':native_bytes})
 page.wait_for_timeout(350)
 check('Aster-editable PPTX restores group metadata',any(e.get('groupId') for e in model()['slides'][1]['elements']))
 check('no JS errors',not errors)
 page.locator('[data-tab="arrange"]').click()
 page.locator('.thumbRow').nth(1).click()
 page.locator('[data-layer-select]').first.click()
 context.close();browser.close()
print(f'ARRANGE BROWSER: {len(checks)}/{len(checks)}')
