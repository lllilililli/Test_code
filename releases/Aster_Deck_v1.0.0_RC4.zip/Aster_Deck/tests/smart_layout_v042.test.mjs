import test from 'node:test';
import assert from 'node:assert/strict';
import {makeDeck,Store} from '../src/core.js';
import * as A from '../src/arrange.js';
import * as S from '../src/smart-layout.js';
const elems=()=>[
 {type:'rounded',id:'a',x:40,y:110,w:150,h:95},
 {type:'rounded',id:'b',x:310,y:130,w:180,h:110},
 {type:'rounded',id:'c',x:620,y:260,w:165,h:115},
 {type:'rounded',id:'d',x:735,y:90,w:115,h:90},
];
test('two real objects become a semantic connector',()=>{const x=elems(),e=S.createConnector(x,'a','b','link');assert.equal(e.from,'a');assert.equal(e.to,'b');assert.equal(e.route,'elbow');assert.equal(S.createConnector(x,'a','missing','no'),null);assert.equal(S.createConnector(x,'a','a','no'),null)});
test('connection starts and ends on actual shape edges',()=>{const x=elems(),p=S.connectorPath(x,S.createConnector(x,'a','b','link'));assert.deepEqual(p.points[0],{x:190,y:157.5});assert.deepEqual(p.points.at(-1),{x:310,y:185});assert.equal(p.points.length,4)});
test('connected ends are recomputed after resize and move',()=>{const x=elems(),e=S.createConnector(x,'a','b','link'),old=S.connectorPath(x,e).d;A.translate(x,['a'],30,20);A.resize(x,['b'],30,30);assert.notEqual(S.connectorPath(x,e).d,old);assert.equal(S.connectorPath(x,e).points[0].x,220)});
test('straight connector has exactly one visible segment',()=>{const x=elems(),e=S.createConnector(x,'a','b','link','straight');assert.equal(S.connectorPath(x,e).points.length,2)});
test('missing targets do not produce fake or stale lines',()=>{const x=elems(),e=S.createConnector(x,'a','b','link');x.splice(1,1);assert.equal(S.connectorPath(x,e),null);x.push(e);S.removeDangling(x);assert.ok(!x.includes(e))});
test('locked and nested connector endpoints cannot be connected',()=>{const x=elems();x[0].locked=true;assert.equal(S.createConnector(x,'a','b','link'),null);x[0].locked=false;x.push(S.createConnector(x,'a','b','old'));assert.equal(S.createConnector(x,'old','c','link'),null)});
test('horizontal smart layout creates nonoverlapping safe columns',()=>{const x=elems();assert.equal(S.smartLayout(x,['a','b','c','d'],'horizontal'),true);for(let i=0;i<x.length-1;i++)assert.ok(x[i].x+x[i].w<x[i+1].x);assert.ok(x.every(e=>e.x>=0&&e.x+e.w<=960))});
test('vertical smart layout creates nonoverlapping rows',()=>{const x=elems();S.smartLayout(x,['a','b','c','d'],'vertical');const sorted=x.sort((a,b)=>a.y-b.y);for(let i=0;i<sorted.length-1;i++)assert.ok(sorted[i].y+sorted[i].h<sorted[i+1].y);assert.ok(x.every(e=>e.y+e.h<=540))});
test('grid smart layout fits four cards within canvas without intersection',()=>{const x=elems();S.smartLayout(x,['a','b','c','d'],'grid');assert.ok(x.every(e=>e.x>=0&&e.y>=0&&e.x+e.w<=960&&e.y+e.h<=540));for(let i=0;i<x.length;i++)for(let j=i+1;j<x.length;j++){const a=x[i],b=x[j];assert.ok(a.x+a.w<=b.x||b.x+b.w<=a.x||a.y+a.h<=b.y||b.y+b.h<=a.y)}});
test('group keeps members at constant relative geometry when cells fit',()=>{const x=elems();x[0].groupId='team';x[1].groupId='team';const oldDist=x[1].x-x[0].x;assert.equal(S.smartLayout(x,['a','c','d'],'grid'),true);assert.equal(x[0].groupId,x[1].groupId);assert.ok(x[1].x>x[0].x && Math.abs((x[1].x-x[0].x)/(x[0].w/150)-oldDist)<0.5)});
test('locked objects remain exactly unchanged',()=>{const x=elems();x[2].locked=true;const before=structuredClone(x);assert.equal(S.smartLayout(x,['a','b','c'],'grid'),false);assert.deepEqual(x,before)});
test('connector relationships survive layout, store undo and redo',()=>{const d=makeDeck();const x=elems();x.push(S.createConnector(x,'a','c','edge'));d.slides[0].elements=x;const store=new Store(d),before=S.connectorPath(x,x.at(-1)).d;store.execute(deck=>S.smartLayout(deck.slides[0].elements,['a','b','c','d'],'grid'));const after=S.connectorPath(store.deck.slides[0].elements,store.deck.slides[0].elements.at(-1)).d;assert.notEqual(before,after);store.undo();assert.equal(S.connectorPath(store.deck.slides[0].elements,store.deck.slides[0].elements.at(-1)).d,before);store.redo();assert.equal(S.connectorPath(store.deck.slides[0].elements,store.deck.slides[0].elements.at(-1)).d,after)});
test('snapping computes magnetic guide against neighboring center',()=>{const x=elems();const result=S.snapMove(x,['a'],{x:490,y:181,w:150,h:95});assert.ok(result.guides.length>0);assert.ok(result.guides.some(g=>g.axis==='x'||g.axis==='y'))});
test('alt free-drag is application preference, pure geometry remains deterministic',()=>{const x=elems(),b={x:473,y:200,w:150,h:95};assert.deepEqual(S.snapMove(x,['a'],b),S.snapMove(x,['a'],b))});
test('deleting node cascades only related connectors',()=>{const x=elems();x.push(S.createConnector(x,'a','b','ab'),S.createConnector(x,'b','c','bc'));x.splice(x.findIndex(e=>e.id==='a'),1);S.removeDangling(x);assert.ok(!x.some(e=>e.id==='ab'));assert.ok(x.some(e=>e.id==='bc'))});
