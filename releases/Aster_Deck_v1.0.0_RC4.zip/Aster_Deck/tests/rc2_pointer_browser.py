from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1540,'height':960})
 page.set_content((ROOT/'index.html').read_text())
 page.locator('.addSlide').click()
 page.locator('[data-command="insert.text"]').first.click()
 page.locator('[data-prop="text"]').fill('안녕하세요 Aster Deck')
 page.locator('[data-prop="text"]').dispatch_event('change')
 el=page.locator('#stage .element.text')
 r=el.bounding_box()
 page.mouse.click(r['x']+r['width']*.42,r['y']+r['height']*.4)
 assert page.evaluate('!!editing'), 'click to edit'
 rects=page.evaluate('''() => {const el=document.querySelector('#stage .element.text'),n=el.querySelector('.rich-body span').firstChild;const rr=i=>{const r=document.createRange();r.setStart(n,i);r.setEnd(n,i+1);const b=r.getBoundingClientRect();return {x:b.x,y:b.y,w:b.width,h:b.height}};return {a:rr(1),b:rr(6)}}''')
 a=rects['a'];z=rects['b'];y=a['y']+a['h']*.55
 page.mouse.move(a['x']+a['w']*.1,y);page.mouse.down();page.mouse.move(z['x']+z['w']*.75,y,steps=9);page.mouse.up();page.wait_for_timeout(120)
 print('SELECTION',page.evaluate('({text:window.getSelection()?.toString(),r:rangeCache,visible:!document.querySelector("#quickFormat").classList.contains("hidden")})'))
 assert page.evaluate('rangeCache?.end>rangeCache?.start'), 'native mouse selection'
 assert page.locator('#quickFormat').is_visible(), 'toolbar native mouse selection'
 # text is still editable after normal click, Escape exits
 page.keyboard.press('Escape');assert page.evaluate('editing===null')
 # plain shapes must remain selectable / draggable, not converted to text-editor
 page.locator('[data-command="insert.rect"]').first.click()
 item=page.locator('#stage .element.rect');rc=item.bounding_box()
 page.mouse.move(rc['x']+rc['width']/2,rc['y']+rc['height']/2);page.mouse.down();page.mouse.move(rc['x']+rc['width']/2+36,rc['y']+rc['height']/2+16,steps=6);page.mouse.up()
 print('shape cursor',item.evaluate('(e)=>e.style.cursor'),'editing',page.evaluate('editing'))
 assert page.evaluate('editing===null'), 'shape not an editable text'
 assert page.evaluate('el()?.x !== 100'), 'shape moved'
 print('RC2 native pointer tests passed')
 b.close()
