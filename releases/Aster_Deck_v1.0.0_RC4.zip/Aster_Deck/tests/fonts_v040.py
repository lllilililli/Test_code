from pathlib import Path
from playwright.sync_api import sync_playwright
from io import BytesIO
from zipfile import ZipFile
from pptx import Presentation
import json
ROOT=Path(__file__).resolve().parents[1]
checks=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 ctx=browser.new_context(viewport={'width':1520,'height':940},accept_downloads=True)
 page=ctx.new_page()
 errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
 page.set_content((ROOT/'index.html').read_text())
 def model():return page.evaluate('JSON.parse(JSON.stringify(store.deck))')
 def check(label,condition):
  assert condition,label
  checks.append(label);print('PASS',label,flush=True)
 page.locator('.addSlide').click()
 page.locator('[data-command="insert.text"]').first.click()
 page.locator('[data-prop="text"]').fill('오로라 Hello world')
 page.locator('[data-prop="text"]').dispatch_event('change')
 check('new slide text inserted',model()['slides'][1]['elements'][0]['text']=='오로라 Hello world')
 # whole-object font setting with explorer
 page.locator('[data-command="font.explorer"]').first.click()
 check('font explorer open',page.locator('#fontExplorer').is_visible())
 page.locator('#fontSearch').fill('Georgia')
 check('font search filters results',page.locator('#fontList .font-choice-btn').count()==1)
 page.locator('[data-font-choose="Georgia"]').click()
 e=model()['slides'][1]['elements'][0]
 check('whole object changed font',e['fontFamily']=='Georgia')
 # selected characters of a mixed Hangul + latin string
 editor=page.locator('#stage .element.text')
 editor.dblclick()
 page.evaluate('''() => {
   const root=document.querySelector('#stage .element.text'); const n=root.querySelector('.rich-body span').firstChild;
   const sel=window.getSelection(); const r=document.createRange();r.setStart(n,0);r.setEnd(n,3);sel.removeAllRanges();sel.addRange(r);
   document.dispatchEvent(new Event('selectionchange'));
 }''')
 check('browser captures selected range',page.evaluate('rangeCache?.start===0 && rangeCache?.end===3'))
 page.locator('[data-command="font.explorer"]').first.click()
 page.locator('#fontSearch').fill('Arial')
 page.locator('[data-font-choose="Arial"]').click()
 e=model()['slides'][1]['elements'][0]
 check('partial font change produces 2 runs',len(e['runs'])==2)
 check('first 3 characters use Arial',e['runs'][0]['text']=='오로라' and e['runs'][0]['fontFamily']=='Arial')
 check('unselected text keeps Georgia',e['runs'][1]['text']==' Hello world' and (e['runs'][1].get('fontFamily') or e['fontFamily'])=='Georgia')
 check('plain text remains unmodified',e['text']=='오로라 Hello world')
 page.locator('[data-command="edit.undo"]').first.click()
 check('undo partial format',len(model()['slides'][1]['elements'][0].get('runs',[]))<=1)
 page.locator('[data-command="edit.redo"]').first.click()
 check('redo partial format',len(model()['slides'][1]['elements'][0]['runs'])==2)
 page.locator('[data-command="font.explorer"]').first.click()
 page.locator('#fontSearch').fill('Georgia')
 page.locator('[data-font-favorite="Georgia"]').click()
 page.locator('[data-font-filter="favorites"]').click()
 check('favorite fonts filtered',page.locator('[data-font-choose="Georgia"]').count()==1)
 page.locator('#fontDismiss').click()
 with page.expect_download() as info:page.locator('[data-command="file.exportPptx"]').first.click()
 archive=info.value.path().read_bytes()
 prs=Presentation(BytesIO(archive))
 runs=[]
 for shp in prs.slides[1].shapes:
  if getattr(shp,'has_text_frame',False) and '오로라' in shp.text:
   runs=[(r.text,r.font.name) for p in shp.text_frame.paragraphs for r in p.runs];break
 check('pptx has 2 rich-text runs',len(runs)==2)
 check('pptx first run Arial',runs[0]==('오로라','Arial'))
 check('pptx second run Georgia',runs[1]==(' Hello world','Georgia'))
 # JSON project preserves exactly the two runs
 with page.expect_download() as info:page.locator('[data-command="file.exportJson"]').first.click()
 saved=json.loads(info.value.path().read_text())
 check('JSON project saves partial fonts',saved['slides'][1]['elements'][0]['runs']==model()['slides'][1]['elements'][0]['runs'])
 # native editable PPTX preserves original model
 page.locator('[data-tab="file"]').click()
 with page.expect_download() as info:page.locator('[data-command="file.exportPptxNative"]').first.click()
 native=info.value.path().read_bytes()
 check('native pptx carries editable snapshot','customXml/asterDeck1.xml' in ZipFile(BytesIO(native)).namelist())
 page.locator('#openFile').set_input_files({'name':'saved.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':archive})
 page.wait_for_timeout(500)
 imported=model()['slides'][1]['elements'][0]
 check('standard PPTX reimport retains mixed text runs',len(imported.get('runs',[]))==2 and imported['runs'][0]['fontFamily']=='Arial' and imported['runs'][1]['fontFamily']=='Georgia')
 check('no JS exceptions',not errors)
 page.locator('[data-tab="home"]').click()
 page.locator('.thumbRow').nth(1).click()
 browser.close()
print('NEW FONT BROWSER RESULTS:',len(checks),'/',len(checks))
