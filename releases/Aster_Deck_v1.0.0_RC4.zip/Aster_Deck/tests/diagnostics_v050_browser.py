"""Browser-level acceptance of document inspector and Design Doctor, offline bundle."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
count=0
def ok(name,value):
 global count
 assert value,name
 count+=1;print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1580,'height':920},accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 ok('review tab exists',page.locator('[data-tab="review"]').count()==1)
 page.locator('[data-tab="review"]').click()
 ok('review panel opens on tab click',page.locator('#propsTitle').inner_text()=='문서 진단')
 ok('inspector renders issue cards',page.locator('.audit-issue').count()>=4)
 ok('each issue offers location',page.locator('.audit-issue [data-diag-jump]').count()>0)
 ok('slide previews display warning counts',page.locator('.audit-thumb-badge').count()>0)
 ok('issue summary is visible',page.locator('.audit-score').is_visible())
 page.locator('[data-diag-filter="design"]').click()
 ok('design filter selects appropriate tab',page.locator('[data-diag-filter="design"]').get_attribute('class')=='active')
 ok('design filter only returns design entries',all('디자인 품질' in x.inner_text() for x in page.locator('.audit-issue').all()))
 page.locator('[data-diag-filter="compat"]').click()
 ok('compat filter works',all('PPTX 호환성' in x.inner_text() for x in page.locator('.audit-issue').all()))
 page.locator('#auditCurrentOnly').check()
 ok('slide-only toggle restricts result count',all('슬라이드 1' in x.inner_text() for x in page.locator('.audit-issue').all()))
 page.locator('#auditCurrentOnly').uncheck()
 page.locator('[data-diag-filter="all"]').click()
 # Add an unambiguously fixable title overflow object; pure diagnostic engine must find it.
 obj_id=page.evaluate('''() => {const e=shape('text',140,95);e.text='가나다라\\n마바사아';e.fontSize=28;e.w=380;e.h=25;e.id=uid();store.execute(d=>d.slides[0].elements.push(e));return e.id}''')
 issue=page.locator('.audit-issue').filter(has=page.locator('[data-diag-jump]')).filter(has_text='텍스트가 상자에서 넘칠 수 있어').first
 ok('new overflow is detected in browser',issue.count()>0)
 page.locator('#inspectorToggle').click()
 ok('properties toggle preserves editor',page.locator('#propsTitle').inner_text()=='속성 패널')
 page.locator('#inspectorToggle').click()
 ok('inspector toggle restores findings',page.locator('#propsTitle').inner_text()=='문서 진단')
 issue=page.locator('.audit-issue').filter(has_text='텍스트가 상자에서 넘칠 수 있어').first
 issue.locator('[data-diag-jump]').first.click()
 ok('jump selects exact object',page.evaluate('selected')==obj_id)
 ok('jump keeps review visible',page.locator('#propsTitle').inner_text()=='문서 진단')
 issue=page.locator('.audit-issue').filter(has_text='텍스트가 상자에서 넘칠 수 있어').first
 old_height=page.evaluate('(id)=>store.deck.slides[0].elements.find(e=>e.id===id).h',obj_id)
 issue.locator('[data-diag-fix]').click()
 height=page.evaluate('(id)=>store.deck.slides[0].elements.find(e=>e.id===id).h',obj_id)
 ok('explicit fix increases text height',height>old_height)
 ok('fix resolves overflow finding',page.locator('.audit-issue').filter(has_text='텍스트가 상자에서 넘칠 수 있어').count()==0)
 page.keyboard.press('Control+z')
 ok('ctrl+z restores fixed geometry',page.evaluate('(id)=>store.deck.slides[0].elements.find(e=>e.id===id).h',obj_id)==old_height)
 ok('undo restores finding',page.locator('.audit-issue').filter(has_text='텍스트가 상자에서 넘칠 수 있어').count()>0)
 page.keyboard.press('Control+y')
 ok('redo reapplies fix',page.evaluate('(id)=>store.deck.slides[0].elements.find(e=>e.id===id).h',obj_id)==height)
 page.locator('[data-diag-filter="compat"]').click()
 first=page.locator('.audit-issue').first
 issue_id=first.get_attribute('data-issue-id')
 first.locator('[data-diag-ignore]').click()
 ok('ignore suppresses issue',page.locator(f'.audit-issue[data-issue-id="{issue_id}"]').count()==0)
 ok('ignore persists on document',page.evaluate('(id)=>store.deck.diagnosticIgnores.includes(id)',issue_id))
 # Recheck honors suppression; undo and then clear all ignore history.
 page.locator('#propertiesBody [data-command="review.recheck"]').click()
 ok('recheck respects suppression',page.locator(f'.audit-issue[data-issue-id="{issue_id}"]').count()==0)
 page.locator('[data-command="review.clearIgnored"]').click()
 ok('clear excluded findings restores issue',page.locator(f'.audit-issue[data-issue-id="{issue_id}"]').count()==1)
 with page.expect_download() as dl:page.locator('[data-command="file.exportJson"]').first.click()
 saved=json.loads(dl.value.path().read_text(encoding='utf-8'))
 ok('regular JSON export still works with inspector',saved['format']=='aster-deck')
 page.locator('#openFile').set_input_files({'name':'diagnostics.aster.json','mimeType':'application/json','buffer':json.dumps(saved).encode()})
 ok('JSON import still loads document with diagnostics',page.locator('[data-slide]').count()==len(saved['slides']))
 # Keyboard shortcut while not typing.
 page.locator('#stage').focus();page.keyboard.press('Alt+Shift+d')
 ok('shortcut reopens review',page.locator('#propsTitle').inner_text()=='문서 진단')
 ok('no JS errors',len(errors)==0)
 browser.close()
print('TOTAL BROWSER CHECKS',count)
