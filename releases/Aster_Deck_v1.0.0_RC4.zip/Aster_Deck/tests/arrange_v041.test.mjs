import test from 'node:test';
import assert from 'node:assert/strict';
import {Store,makeDeck,shape} from '../src/core.js';
import * as A from '../src/arrange.js';
const shapes=()=>[
 {id:'a',x:10,y:20,w:40,h:30,type:'rect'},
 {id:'b',x:100,y:100,w:50,h:40,type:'text'},
 {id:'c',x:220,y:210,w:60,h:50,type:'ellipse'},
 {id:'d',x:360,y:280,w:30,h:30,type:'star'},
];
function deck(){const d=makeDeck();d.slides[0].elements=shapes();return d}
test('two objects are required to group',()=>{let x=shapes();assert.equal(A.group(x,['a'],'group1'),false);assert.equal(x[0].groupId,undefined)});
test('group retains original geometry and shape order',()=>{let x=shapes();let before=x.map(e=>[e.id,e.x,e.y,e.w,e.h]);A.group(x,['a','b'],'grp');assert.deepEqual(x.map(e=>[e.id,e.x,e.y,e.w,e.h]),before);assert.deepEqual(A.picked(x,['a']).map(e=>e.id),['a','b'])});
test('grouped translate moves all siblings but not unrelated objects',()=>{let x=shapes();A.group(x,['a','c'],'grp');A.translate(x,['a'],14,-8);assert.deepEqual([x[0].x,x[0].y,x[2].x,x[2].y,x[1].x],[24,12,234,202,100])});
test('group ungroup independent edit does not change coordinates',()=>{let x=shapes();A.group(x,['a','b'],'g');A.ungroup(x,['a']);A.translate(x,['a'],20,0);assert.equal(x[1].x,100);assert.equal(x[0].groupId,undefined)});
test('align selected uses selection bounds, solitary uses slide',()=>{let x=shapes();A.align(x,['a','b'],'x','center');assert.equal(x[0].x,60);assert.equal(x[1].x,55);A.align(x,['c'],'x','center');assert.equal(x[2].x,450)});
test('align top and bottom work correctly',()=>{let x=shapes();A.align(x,['a','b'],'y','start');assert.deepEqual([x[0].y,x[1].y],[20,20]);A.align(x,['c'],'y','end');assert.equal(x[2].y,490)});
test('horizontal distribute creates equal visual gaps, preserves endpoints',()=>{let x=shapes();let start=x[0].x,last=x[3].x;A.distribute(x,['a','b','c','d'],'x');assert.equal(x[0].x,start);assert.equal(x[3].x,last);const gaps=x.slice(1).map((e,i)=>e.x-x[i].x-x[i].w);assert.ok(Math.abs(gaps[0]-gaps[1])<1e-8&&Math.abs(gaps[1]-gaps[2])<1e-8)});
test('vertical distribute needs 3 objects',()=>{let x=shapes();assert.equal(A.distribute(x,['a','b'],'y'),false);assert.equal(A.distribute(x,['a','b','c','d'],'y'),true)});
test('lock prevents movement, deletion, reordering, alignment and duplication',()=>{let x=shapes();A.group(x,['a','b'],'g');A.setLocked(x,['a'],true);const baseline=JSON.stringify(x);assert.equal(A.translate(x,['b'],20,30),false);assert.equal(A.deleteSelected(x,['a']),false);assert.equal(A.reorder(x,['a'],'front'),false);assert.equal(A.align(x,['b'],'x','start'),false);assert.deepEqual(A.duplicate(x,['b']),[]);assert.equal(JSON.stringify(x),baseline)});
test('unlock through group member unlocks whole group',()=>{let x=shapes();A.group(x,['a','b'],'g');A.setLocked(x,['a'],true);A.setLocked(x,['b'],false);assert.equal(A.translate(x,['a'],10,0),true)});
test('multi selection delete removes only chosen group and never locked',()=>{let x=shapes();A.group(x,['a','b'],'g');assert.equal(A.deleteSelected(x,['b']),true);assert.deepEqual(x.map(e=>e.id),['c','d'])});
test('duplicate gets fresh element IDs and distinct group ID',()=>{let x=shapes();A.group(x,['a','b'],'g');let n=0;const ids=A.duplicate(x,['a'],()=>`new${++n}`);assert.deepEqual(ids,['new1','new3']);assert.equal(x[4].groupId,x[5].groupId);assert.notEqual(x[4].groupId,'g');assert.equal(x[4].x,x[0].x+22);assert.equal(x[0].groupId,'g')});
test('reorder stable for groups and unrelated shapes',()=>{let x=shapes();A.group(x,['a','c'],'g');A.reorder(x,['a'],'front');assert.deepEqual(x.map(e=>e.id),['b','d','a','c']);A.reorder(x,['a'],'back');assert.deepEqual(x.map(e=>e.id),['a','c','b','d']);A.reorder(x,['b'],'forward');assert.deepEqual(x.map(e=>e.id),['a','c','d','b']);A.reorder(x,['b'],'backward');assert.deepEqual(x.map(e=>e.id),['a','c','b','d'])});
test('group + lock + geometry survive JSON and Store undo/redo',()=>{let d=deck(),st=new Store(d);st.execute(x=>A.group(x.slides[0].elements,['a','b'],'grp'));st.execute(x=>A.translate(x.slides[0].elements,['a'],7,10));st.execute(x=>A.setLocked(x.slides[0].elements,['a'],true));const serialized=JSON.parse(JSON.stringify(st.deck));assert.equal(serialized.slides[0].elements[0].groupId,'grp');assert.equal(serialized.slides[0].elements[1].locked,true);assert.equal(serialized.slides[0].elements[0].x,17);st.undo();assert.equal(st.deck.slides[0].elements[1].locked,undefined);st.undo();assert.equal(st.deck.slides[0].elements[0].x,10);st.redo();assert.equal(st.deck.slides[0].elements[0].x,17);st.redo();assert.equal(st.deck.slides[0].elements[0].locked,true)});
test('aligning a group maintains spacing and moves whole group',()=>{let x=shapes();A.group(x,['a','b'],'g');const between=x[1].x-x[0].x;A.align(x,['a'],'x','center');assert.equal(x[1].x-x[0].x,between);assert.equal(A.box(A.picked(x,['a'])).x,410)});
test('distributing 3 groups treats groups as indivisible',()=>{let x=shapes();A.group(x,['a','b'],'g');const delta=x[1].x-x[0].x;assert.equal(A.distribute(x,['a','b','c','d'],'x'),true);assert.equal(x[1].x-x[0].x,delta)});
test('existing ungrouped objects stay editable and unchanged',()=>{const d=deck();const st=new Store(d);const before=structuredClone(st.deck);st.execute(x=>A.distribute(x.slides[0].elements,['a'],'x'));assert.deepEqual(st.deck,before)});
