"""Compressed multislide external-PPTX surgical preservation test (in memory)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE
from pptx.util import Inches
import io,zipfile
ROOT=Path(__file__).resolve().parents[1]
pres=Presentation();s0=pres.slides.add_slide(pres.slide_layouts[6]);s0.shapes.add_textbox(Inches(1),Inches(1),Inches(5),Inches(1)).text='First slide content'
s1=pres.slides.add_slide(pres.slide_layouts[6]);s1.shapes.add_textbox(Inches(1),Inches(1),Inches(5),Inches(1)).text='Second slide untouched'
data=CategoryChartData();data.categories=['Q1','Q2'];data.add_series('profit',[8,21]);s1.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED,Inches(1),Inches(2),Inches(5),Inches(3),data)
s1.notes_slide.notes_text_frame.text='Speaker notes unchanged'
buf=io.BytesIO();pres.save(buf);original=buf.getvalue()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(accept_downloads=True)
 page.set_content((ROOT/'index.html').read_text())
 page.locator('#openFile').set_input_files({'name':'external2.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':original})
 page.wait_for_function(f'sourcePptx && sourcePptx.bytes.length === {len(original)}')
 assert page.evaluate('store.deck.slides.length')==2,'external 2 slides import'
 assert page.evaluate('preservationReport(sourcePptx.deck,store.deck).safe')
 page.evaluate('''() =>store.execute(d=>{d.slides[0].elements[0].x+=20})''')
 assert page.evaluate('preservationReport(sourcePptx.deck,store.deck).safe')
 saved=bytes(page.evaluate('''async()=>Array.from(await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck))'''))
 with zipfile.ZipFile(io.BytesIO(original)) as z0,zipfile.ZipFile(io.BytesIO(saved)) as z1:
  untouched=[n for n in z0.namelist() if n.startswith('ppt/charts/') or n.startswith('ppt/embeddings/') or n.startswith('ppt/notesSlides/') or n=='ppt/slides/slide2.xml']
  assert untouched,'fixture has chart, notes, and slide2 parts'
  for name in untouched:
   assert z0.read(name)==z1.read(name),'modified '+name
  assert z0.read('ppt/slides/slide1.xml')!=z1.read('ppt/slides/slide1.xml')
 assert len(Presentation(io.BytesIO(saved)).slides)==2
 print('PASS external compressed PPTX: original chart, embedded spreadsheet, notes and entire untouched slide preserved. Parts checked:',len(untouched))
 b.close()
