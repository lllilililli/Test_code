import test from 'node:test';
import assert from 'node:assert/strict';
import {patchRuns,patchElement,setUniform,mergeRuns,textRuns} from '../src/rich-text.js';
test('select only Korean word and apply font',()=>{
 const e={text:'오로라 Hello world',fontFamily:'Georgia'};
 patchElement(e,0,3,{fontFamily:'맑은 고딕'});
 assert.deepEqual(e.runs,[{text:'오로라',fontFamily:'맑은 고딕'},{text:' Hello world'}]);
 assert.equal(e.text,'오로라 Hello world');
});
test('partial format spanning multiple existing runs',()=>{
 const r=[{text:'안녕',color:'#123456'},{text:' Hello',fontFamily:'Arial'}];
 const out=patchRuns(r,1,5,{bold:true});
 assert.deepEqual(out.map(r=>r.text),['안','녕',' He','llo']);
 assert.deepEqual(out.map(r=>r.bold),[undefined,true,true,undefined]);
});
test('uniform font change clears earlier overrides only for font',()=>{
 const e={text:'한국어AB',fontFamily:'Georgia',runs:[{text:'한국어',fontFamily:'Arial',bold:true},{text:'AB',color:'#ff0000'}]};
 setUniform(e,'fontFamily','나눔고딕');
 assert.equal(e.fontFamily,'나눔고딕');assert.equal(e.runs[0].bold,true);
 assert.equal(e.runs[0].fontFamily,undefined);assert.equal(e.runs[1].color,'#ff0000');
});
test('merge consecutive equal styles and preserve text',()=>{
 assert.deepEqual(mergeRuns([{text:'한'},{text:'글'},{text:'!' ,italic:true}]),[{text:'한글'},{text:'!',italic:true}]);
});
test('newlines remain in runs',()=>{
 const e={text:'첫 줄\n둘째 줄'};patchElement(e,0,2,{color:'#00ff00'});
 assert.equal(e.text,'첫 줄\n둘째 줄');
});
test('empty input stays editable',()=>assert.deepEqual(textRuns({text:''}),[{text:''}]));
