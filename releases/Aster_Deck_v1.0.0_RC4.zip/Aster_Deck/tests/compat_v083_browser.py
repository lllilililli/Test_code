"""Aster v0.8.0–0.8.3 end-to-end export, preservation, master, group smoke tests.
Transient documents live only in memory and /tmp; no samples folder.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from pptx import Presentation
import io, zipfile, xml.etree.ElementTree as ET, tempfile, subprocess, shutil, json
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(label,value):
 assert value,label
 checks.append(label);print('PASS',label,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1540,'height':930},accept_downloads=True)
 errs=[];page.on('pageerror',lambda err:errs.append(str(err)))
 page.set_content((ROOT/'index.html').read_text(encoding='utf-8'))
 check('v0.8.3 version label',page.locator('.version').inner_text()=='v1.0.0 RC4')
 check('editor starts',page.locator('#stage').count()==1)
 # modify a new doc with grouped elements, master title, auto fit.
 page.evaluate('''() => {let d=makeDeck();let a=shape('rounded',80,130),b=shape('text',300,130);a.text='Grouped';b.text='Group label';a.groupId='groupA';b.groupId='groupA';b.textAutoFit='shrink';d.slides[0].elements=[a,b];d.master.elements=[Object.assign(shape('text',25,20),{text:'REAL MASTER FOOTER',w:550,h:40})];d.master.useBackground=false;store.load(d);active=store.deck.slides[0].id;render();}''')
 with page.expect_download(timeout=30000) as dl:page.locator('[data-command="file.exportPptx"]').first.click()
 raw=Path(dl.value.path()).read_bytes()
 check('PPTX accepted by python-pptx',len(Presentation(io.BytesIO(raw)).slides)==1)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  sx=z.read('ppt/slides/slide1.xml').decode();mx=z.read('ppt/slideMasters/slideMaster1.xml').decode()
  check('native pptx group tag',sx.count('<p:grpSp>')==1)
  check('group includes 2 child objects',sx.split('<p:grpSp>')[1].split('</p:grpSp>')[0].count('<p:sp>')==2)
  check('auto fit in text body', '<a:normAutofit/>' in sx)
  check('real master text in slide master', 'REAL MASTER FOOTER' in mx)
  check('no flattened master in slide xml','REAL MASTER FOOTER' not in sx)
 # reimport and check group id + metadata
 page.locator('#openFile').set_input_files({'name':'native.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':raw})
 check('PPTX reimports grouped text',page.evaluate('store.deck.slides[0].elements.some(e=>e.text==="Group label")'))
 check('reimport honors group IDs',page.evaluate('store.deck.slides[0].elements.filter(e=>e.groupId).length')>=2)
 check('text auto fit recovered',page.evaluate('store.deck.slides[0].elements.find(e=>e.text==="Group label").textAutoFit')=='shrink')
 # Synthetic external powerpoint with unsupported extra parts. Use same PPTX but add an unrelated safe binary asset.
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  seed={name:z.read(name) for name in z.namelist()}
 seed['docProps/custom-real.bin']=b'UNTOUCHED-PART-\x00\x01-PRESERVE-EXACT'
 seed['[Content_Types].xml']=seed['[Content_Types].xml'].replace(b'</Types>',b'<Default Extension="bin" ContentType="application/octet-stream"/></Types>')
 # custom data must be truly linked to a package relationship for meaningful test
 rel='''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rIdOther" Type="http://example.com/custom/asset" Target="docProps/custom-real.bin"/></Relationships>'''
 seed['_rels/.rels']=rel.encode()
 with io.BytesIO() as f:
  with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as z:
   for name,data in seed.items():z.writestr(name,data)
  external=f.getvalue()
 page.locator('#openFile').set_input_files({'name':'external.pptx','mimeType':'application/vnd.openxmlformats-officedocument.presentationml.presentation','buffer':external})
 page.wait_for_function(f'sourcePptx && sourcePptx.bytes.length === {len(external)}')
 check('external PPTX imported',page.evaluate('sourcePptx !== null && !sourcePptx.native'))
 check('unchanged original preservation safe',page.evaluate('preservationReport(sourcePptx.deck,store.deck).safe'))
 out_unchanged=page.evaluate('''async()=>Array.from(await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck))''')
 print('DEBUG original/export lengths',len(external),len(out_unchanged), 'report',page.evaluate('preservationReport(sourcePptx.deck,store.deck)'))
 check('unchanged returns identical bytes',external==bytes(out_unchanged))
 # master slide left untouched, edit x & width only
 page.evaluate('''() => {store.execute(d=>{d.slides[0].elements[0].x+=33;d.slides[0].elements[0].w+=18;})}''')
 check('position update safe',page.evaluate('preservationReport(sourcePptx.deck,store.deck).safe'))
 new=bytes(page.evaluate('''async()=>Array.from(await exportPreservedPptx(sourcePptx.bytes,sourcePptx.deck,store.deck))'''))
 with zipfile.ZipFile(io.BytesIO(new)) as z:
  check('other arbitrary binary parts preserved',z.read('docProps/custom-real.bin')==seed['docProps/custom-real.bin'])
  check('master part unmodified',z.read('ppt/slideMasters/slideMaster1.xml')==seed['ppt/slideMasters/slideMaster1.xml'])
  check('presentation metadata unchanged',z.read('ppt/presentation.xml')==seed['ppt/presentation.xml'])
  check('source relationships unmodified',z.read('_rels/.rels')==seed['_rels/.rels'])
  check('changed slide XML only',z.read('ppt/slides/slide1.xml')!=seed['ppt/slides/slide1.xml'])
 check('preserved PPTX accepted by pptx parser',len(Presentation(io.BytesIO(new)).slides)==1)
 page.evaluate('''()=>store.execute(d=>d.slides[0].elements.push(shape('star')))''')
 check('new shape disallows preservation',not page.evaluate('preservationReport(sourcePptx.deck,store.deck).safe'))
 check('no JS page errors',not errs)
 if shutil.which('libreoffice'):
  with tempfile.TemporaryDirectory() as tmp:
   tmp=Path(tmp);(tmp/'grouped.pptx').write_bytes(raw);(tmp/'preserved.pptx').write_bytes(new)
   for pptx in ['grouped.pptx','preserved.pptx']:
    r=subprocess.run(['libreoffice','-env:UserInstallation=file:///tmp/aster_v083_lo','--headless','--convert-to','pdf','--outdir',str(tmp),str(tmp/pptx)],capture_output=True,text=True,timeout=50)
    check('LibreOffice PDF '+pptx, r.returncode==0 and (tmp/pptx.replace('pptx','pdf')).exists())
 browser.close()
print('CHECKS',len(checks))
