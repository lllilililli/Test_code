import test from 'node:test';
import assert from 'node:assert/strict';
import {timingXml,motionPath} from '../src/pptx-motion.js';
import {newStep,schedule,visualSchedule,motionPathFrames,pathPoint,appendStep,moveStepTo,cleanTimeline} from '../src/timeline.js';
const one=()=>{const step={...newStep('a','fade'),trigger:'click'};return {elements:[{id:'a'},{id:'b'}],timeline:[step]}};
test('0.7.1 generates valid object references and timing tree',()=>{
 const sl=one(),result=timingXml(sl,{a:2,b:3});
 assert.match(result,/<p:timing>/);assert.match(result,/nodeType="mainSeq"/);
 assert.match(result,/spid="2"/);assert.match(result,/nodeType="clickEffect"/);
 assert.match(result,/filter="fade"/);assert.doesNotMatch(result,/spid="undefined"/);
});
test('0.7.1 no animation leaves no timing part',()=>assert.equal(timingXml({elements:[],timeline:[]},{}),''));
test('0.7.1 skips dangling target',()=>assert.equal(timingXml(one(),{}),''));
test('0.7.1 serializes click, with and after triggers',()=>{
 const s=one();appendStep(s,{elementId:'b',effect:'fly',trigger:'with',kind:'entrance',duration:1,delay:.2});
 appendStep(s,{elementId:'a',effect:'zoom',trigger:'after',kind:'exit'});
 const xml=timingXml(s,{a:2,b:3});
 assert.equal((xml.match(/<p:animEffect/g)||[]).length,3);
 assert.match(xml,/nodeType="withEffect"/);assert.match(xml,/nodeType="afterEffect"/);
 assert.match(xml,/evt="onBegin"/);assert.match(xml,/evt="onEnd"/);
 assert.match(xml,/delay="200"/);
});
test('0.7.1 animations include emulated effects',()=>{
 for(const effect of ['fade','fly','zoom','wipe','spin','pulse','shake','path']){
  const s={elements:[{id:'a'}],timeline:[newStep('a',effect)]};
  const xml=timingXml(s,{a:2});assert.match(xml,/<p:(?:animEffect|animMotion|animRot|animScale)/,effect);
 }
});
test('0.7.2 straight path uses normalized slide offsets',()=>{
 const path=motionPath({pathDx:480,pathDy:270,pathType:'line'});
 assert.match(path,/L 0.5 0.5 E/);
});
test('0.7.2 curved motion stores cubic bezier geometry',()=>{
 const path=motionPath({pathDx:240,pathDy:90,pathType:'curve',pathCurve:-60});
 assert.match(path,/\bC\b/);assert.match(path,/E$/);
});
test('0.7.2 interpolated path starts at origin and finishes at displacement',()=>{
 const s={pathDx:270,pathDy:150,pathCurve:60,pathType:'curve'};
 assert.deepEqual(pathPoint(s,0),{x:0,y:0});assert.deepEqual(pathPoint(s,1),{x:270,y:150});
 assert.ok(pathPoint(s,.5).y>75);
 const frames=motionPathFrames(s,16);assert.equal(frames.length,17);
 assert.equal(frames[0].offset,0);assert.equal(frames.at(-1).offset,1);
});
test('0.7.3 visual schedule places click groups consecutively',()=>{
 const s=one();appendStep(s,{elementId:'b',effect:'fade',trigger:'click',duration:2});
 const r=visualSchedule(s);assert.equal(r.events.length,2);
 assert.ok(r.events[1].visualStart>r.events[0].visualEnd);
});
test('0.7.3 same click group with/after uses relative timeline',()=>{
 const s=one();appendStep(s,{elementId:'b',effect:'fade',trigger:'with',duration:.3});
 assert.equal(schedule(s).events.at(-1).cue,1);
 const v=visualSchedule(s);assert.equal(v.events[1].visualStart,v.events[0].visualStart);
});
test('0.7.3 reordered timeline updates event ordering',()=>{
 const s=one();const next=appendStep(s,{elementId:'b',effect:'path'});assert.ok(moveStepTo(s,next.id,s.timeline[0].id));
 assert.equal(s.timeline[0].effect,'path');s.elements.pop();cleanTimeline(s);assert.equal(s.timeline.length,1);
});
