import test from 'node:test';
import assert from 'node:assert/strict';
import {makeDeck,addSlide} from '../src/core.js';
import {exportPptx} from '../src/pptx.js';
import {zipRead,zipText} from '../src/zip.js';
test('notes export creates standard parts and relationship graph',async()=>{const d=makeDeck();d.slides[0].notes='한글 & <notes>\n두 번째';const z=await zipRead(exportPptx(d,null));assert.ok(z['ppt/notesSlides/notesSlide1.xml']);assert.ok(z['ppt/notesMasters/notesMaster1.xml']);assert.match(zipText(z,'ppt/slides/_rels/slide1.xml.rels'),/notesSlide/);assert.match(zipText(z,'ppt/presentation.xml'),/notesMasterIdLst/);assert.match(zipText(z,'[Content_Types].xml'),/notesSlide\+xml/);assert.match(zipText(z,'ppt/notesSlides/notesSlide1.xml'),/한글 &amp; &lt;notes&gt;/);assert.equal((zipText(z,'ppt/notesSlides/notesSlide1.xml').match(/<a:p>/g)||[]).length,2)});
test('empty notes add no unnecessary parts',async()=>{const d=makeDeck();const z=await zipRead(exportPptx(d,null));assert.ok(!Object.keys(z).some(n=>n.startsWith('ppt/notes')));assert.doesNotMatch(zipText(z,'ppt/presentation.xml'),/notesMasterIdLst/)});
test('notes use the correct slide index when preceding slide has no notes',async()=>{const d=makeDeck();addSlide(d,1);d.slides[1].notes='second';const z=await zipRead(exportPptx(d,null));assert.ok(z['ppt/notesSlides/notesSlide2.xml']);assert.ok(!z['ppt/notesSlides/notesSlide1.xml']);assert.match(zipText(z,'ppt/notesSlides/_rels/notesSlide2.xml.rels'),/slides\/slide2.xml/)});
