import test from 'node:test';
import assert from 'node:assert/strict';
import {PREFS_KEY,RECOVERY_KEY,normalizePrefs,loadPrefs,savePrefs,createRecovery,thumbnailRange,matchCommands} from '../src/workspace.js';
import {makeDeck,addSlide,Store,shape} from '../src/core.js';
function fakeStore(){const m=new Map();return {getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k),get map(){return m}}}
test('preferences normalize invalid values and clamp panel widths',()=>{assert.deepEqual(normalizePrefs({theme:'blue',leftWidth:-4,rightWidth:10000,recoveryEnabled:false}),{slidesCollapsed:false,theme:'light',leftWidth:154,rightWidth:425,recoveryEnabled:false});assert.equal(normalizePrefs({theme:'dark'}).theme,'dark')});
test('preferences save/load independently of a presentation',()=>{const m=fakeStore();assert.equal(savePrefs(m,{theme:'dark',leftWidth:300,rightWidth:380,recoveryEnabled:false}),true);assert.equal(loadPrefs(m).theme,'dark');assert.equal(loadPrefs(m).rightWidth,380);assert.ok(m.getItem(PREFS_KEY));assert.equal(m.getItem(RECOVERY_KEY),null)});
test('legacy or corrupt preference data returns safe defaults',()=>{const m=fakeStore();m.setItem(PREFS_KEY,'{not-json');assert.equal(loadPrefs(m).theme,'light')});
test('recovery retains bounded snapshots and restores newest',()=>{const m=fakeStore();let time=0;const r=createRecovery(m,{now:()=>++time,maxItems:3});const d=makeDeck();for(let i=0;i<4;i++){d.title='doc '+i;assert.equal(r.write(d).ok,true)}const list=r.list();assert.equal(list.length,3);assert.equal(r.read(list[0].id).title,'doc 3');assert.equal(r.read('missing'),null);assert.ok(m.getItem(RECOVERY_KEY))});
test('recovery rejects invalid and oversize documents without deleting existing',()=>{const m=fakeStore(),r=createRecovery(m,{maxBytes:250});const small=makeDeck();assert.equal(r.write(small).ok,false);assert.equal(r.write({format:'junk',slides:[]}).reason,'invalid');assert.equal(r.list().length,0)});
test('recovery remove and clear do not touch documents or preferences',()=>{const m=fakeStore();const r=createRecovery(m),d=makeDeck();savePrefs(m,{theme:'dark'});const id=r.write(d).id;assert.equal(r.read(id).title,d.title);assert.equal(r.remove(id),true);assert.equal(r.list().length,0);r.write(d);r.clear();assert.equal(r.list().length,0);assert.equal(loadPrefs(m).theme,'dark')});
test('recovery handles blocked localStorage',()=>{const m={getItem:()=>null,setItem:()=>{throw Error('blocked')},removeItem:()=>{throw Error('blocked')}};const r=createRecovery(m);assert.equal(r.write(makeDeck()).reason,'storage');assert.equal(r.clear(),false);assert.equal(savePrefs(m,normalizePrefs()),false)});
test('recovery quota fallback preserves latest if multiple do not fit',()=>{const m=fakeStore();m.setItem=(k,v)=>{if(v.length>900)throw Error('quota');m.map.set(k,v)};let n=0;const r=createRecovery(m,{now:()=>++n});const d=makeDeck();let last=null;for(let i=0;i<8;i++){d.title='updated '+i;last=r.write(d)}assert.equal(last.ok,true);assert.ok(r.list().length<=3)});
test('thumbnail window keeps offscreen rows unrendered and nearby rows in range',()=>{assert.deepEqual(thumbnailRange(5,0,800),{start:0,end:5});const v=thumbnailRange(500,13000,720);assert.ok(v.end-v.start<=23);assert.ok(v.start>10);assert.equal(thumbnailRange(0,0,0).end,0)});
test('command lookup includes shortcuts and sorts matched labels',()=>{const defs=[{id:'file.open',label:'파일 열기',shortcut:'Ctrl+O'},{id:'slide.add',label:'새 슬라이드',shortcut:'Ctrl+M'}];assert.equal(matchCommands(defs,'ctrl+m')[0].id,'slide.add');assert.equal(matchCommands(defs,'새')[0].id,'slide.add');assert.equal(matchCommands(defs,'미존재').length,0)});
test('large documents retain bounded undo history without losing latest undo',()=>{
 const d=makeDeck();const e=shape('text');e.text='some 1500 characters '+('가'.repeat(1500));d.slides[0].elements.push(e);
 const store=new Store(d);store.maxHistoryBytes=8000;
 for(let n=0;n<12;n++)store.execute(x=>{x.slides[0].elements[0].x=n+1});
 assert.ok(store.history.length<=3);assert.ok(store.history.length>=1);
 assert.equal(store.undo(),true);assert.equal(store.deck.slides[0].elements[0].x,11);
 assert.equal(store.redo(),true);assert.equal(store.deck.slides[0].elements[0].x,12);
});
