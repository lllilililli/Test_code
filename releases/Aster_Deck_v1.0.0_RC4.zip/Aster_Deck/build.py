"""Create two identical zero-dependency standalone HTML entrypoints."""
from pathlib import Path
import re
root=Path(__file__).parent
html=(root/'index.template.html').read_text(encoding='utf-8')
css=(root/'src/style.css').read_text(encoding='utf-8')
code='\n'.join((root/'src'/name).read_text(encoding='utf-8') for name in ['core.js','text-layout.js','rich-text.js','zip.js'])
for fn,alias,names in [('chart-data.js','ChartData','parseDelimited,tableToChart,parseXlsx,chartCsv,tableToMultiChart,chartTable,chartCsvMulti'),('native-chart.js','NativeChart','chartRows,chartSpec,chartGraphic,xlsxForChart,chartXml,chartRelationship,chartPalette')]:
 source=(root/'src'/fn).read_text(encoding='utf-8')
 source=re.sub(r'^import .*?;\s*$', '', source, flags=re.M)
 source=re.sub(r'\bexport\s+(?=(?:const|let|function|async|class))','',source)
 code+='\nconst '+alias+'=(()=>{\n'+source+'\nreturn {'+names+'};\n})();\n'
motion=(root/'src/pptx-motion.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst NativeMotion=(()=>{\n'+motion+'\nreturn {timingXml,readTiming,motionPath};\n})();\n'
workspace=(root/'src/workspace.js').read_text(encoding='utf-8')
workspace=re.sub(r'\bexport\s+(?=(?:const|let|function|async|class))','',workspace)
code+='\n'+workspace+'\n'
code+='\n'+(root/'src/pptx.js').read_text(encoding='utf-8')
code+='\n'+(root/'src/preserve.js').read_text(encoding='utf-8')
studio=(root/'src/studios.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst Studios=(()=>{\n'+studio+'\nreturn {THEMES,applyTheme,previewTheme,readableThemeText,typography,scanFonts,replaceFont,compareDecks,applyComparedSlide,sourceDiff,filterChart,makeDataTable};\n})();\n'
arrange=(root/'src/arrange.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst Arrange=(()=>{\n'+arrange+'\nreturn {picked,box,canEdit,translate,resize,units,align,distribute,group,ungroup,setLocked,deleteSelected,duplicate,reorder};\n})();\n'
smart=(root/'src/smart-layout.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst Smart=(()=>{\nconst {picked,units,box,canEdit}=Arrange;\n'+smart+'\nreturn {anchors,connectorPath,createConnector,connectedIds,removeDangling,smartLayout,snapMove,isConnector};\n})();\n'
diag=(root/'src/diagnostics.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst Diagnostics=(()=>{\n'+diag+'\nreturn {rgb,contrastRatio,estimateText,scanDeck,summary,applyFix,severityOrder,groups};\n})();\n'
timeline=(root/'src/timeline.js').read_text(encoding='utf-8').replace('export function ','function ').replace('export const ','const ')
code+='\nconst Motion=(()=>{\n'+timeline+'\nreturn {EFFECTS,KINDS,TRIGGERS,EASINGS,DIRECTIONS,stepId,newStep,legacySteps,readSteps,ensureTimeline,appendStep,removeStep,moveStep,moveStepTo,cleanTimeline,copyTimeline,schedule,stateAt,keyframes,pathPoint,motionPathFrames,visualSchedule};\n})();\n'
code+=(root/'src/app.js').read_text(encoding='utf-8')
code=re.sub(r'^import .*?;\s*$', '', code, flags=re.M)
code=re.sub(r'\bexport\s+(?=(?:const|let|function|async|class))','',code)
html=html.replace('<link rel="stylesheet" href="src/style.css">','<style>'+css+'</style>')
html=html.replace('<script type="module" src="src/app.js"></script>','<script>'+code+'</script>')
(root/'dist').mkdir(exist_ok=True)
for name in ['index.html','dist/index.html']:
 (root/name).write_text(html,encoding='utf-8')
print('Bundled offline HTML, bytes:',len(html.encode('utf-8')))
