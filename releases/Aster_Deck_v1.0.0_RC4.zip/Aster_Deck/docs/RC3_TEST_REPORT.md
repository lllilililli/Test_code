# Aster Deck v1.0.0 RC3 검증 보고

## 실행 결과

- `npm test`: **197/197 통과**, 실패·건너뜀·취소 0. 기존 190개 및 RC3 단위 검사 7개.
- 아래 번호형 브라우저 검사 **387개 통과**. 각 스크립트의 최종 실행 종료 코드 0.
- `rc2_pointer_browser.py`, `rc2_switch_browser.py`: 실제 포인터 선택 및 텍스트 상자 전환 시나리오 각각 통과. 아래 검사 수와 별도로 표시.

| 검사 | 실행 파일 | 통과 수 |
|---|---|---:|
| RC3 상황별 메뉴·패널 | `tests/rc3_context_browser.py` | 47 |
| RC2 텍스트 편집 | `tests/rc2_interaction_browser.py` | 24 |
| 글꼴 | `tests/fonts_v040.py` | 19 |
| 한글 입력·부분 굵게 | `tests/typing_v040.py` | 2 |
| 그룹·정렬 | `tests/arrange_v041.py` | 36 |
| 스마트 배치 | `tests/smart_v042.py` | 28 |
| 기본 차트 | `tests/chart_v060_browser.py` | 17 |
| 다중 차트 | `tests/chart_v061_browser.py` | 27 |
| PPTX 보존·그룹·마스터 | `tests/compat_v083_browser.py` | 23 |
| 진단 | `tests/diagnostics_v050_browser.py` | 28 |
| 애니메이션 | `tests/motion_v073_browser.py` | 25 |
| 타임라인 | `tests/timeline_v070_browser.py` | 37 |
| Studio | `tests/studios_v093_browser.py` | 31 |
| 작업 공간·복구 | `tests/workspace_v096_browser.py` | 24 |
| RC1 파일·대용량 회귀 | `tests/release_rc1_browser.py` | 19 |

## 범위와 방법

- 새 RC3 브라우저 검사는 완성 단일 HTML을 임시 로컬 HTTP 서버에서 Chromium으로 열어 실행. localStorage 저장·재로드를 실제 확인. 외부 서버나 CDN은 필요하지 않음.
- 기존 브라우저 검사는 단일 HTML 내용을 Chromium 문서에 로드하여 조작. Python 기반 PPTX 구조/가져오기 검사를 함께 수행하는 기존 테스트도 통과.
- 신규 검사: 우클릭 대상 및 다중 선택 유지, 그룹/잠금/해제, 복제 undo/redo, 캔버스 붙여넣기, 슬라이드 경계 및 순서, 키보드 탐색·포커스 복귀, 화면 밖 배치 방지, 외부 클릭 닫기, 패널 접힘·설정 저장·새로고침·너비 유지·문서/undo 불변, 780/1100/1540px 접근, 좁은 속성 패널 닫기, 텍스트 기본 메뉴 유지.
- 이전 회귀 스크립트의 RC2 버전 레이블 기대값을 RC3로 갱신. 기능 검사는 유지.
- Node v24.19.0, Python 3.12.14, headless Chromium/Playwright 환경에서 실행.
- 루트 `index.html`과 `dist/index.html`은 바이트 동일. 배포 ZIP에서 샘플·임시 PPTX·이미지·검증 출력 제외.

## 수정하며 확인한 문제

- 패널을 display:none으로 접으면 CSS grid 자동 배치가 캔버스를 0폭 열에 배치하던 문제를 명시적 열/행 배치로 수정했고 캔버스 폭 증가 검사로 검증.
- 좁은 창의 기존 숨김 규칙 때문에 개체 속성이 보이지 않던 경로에 명시적 오버레이·닫기 버튼을 제공하고 검증.

## 미검증 및 제한

- 이 실행 환경에서 `file://` 탐색은 `ERR_BLOCKED_BY_ADMINISTRATOR`로 차단됨. 사용자 Windows/Mac의 더블클릭 실사용은 미검증.
- 실제 Microsoft PowerPoint의 시각·애니메이션·차트 완전 호환성, 하드웨어 한국어 IME, 다른 브라우저는 미검증. 정식 1.0 승인으로 해석하지 않음.
- 내부 개체 클립보드는 OS 클립보드와 별개. 편집 중인 텍스트에는 브라우저 기본 메뉴 사용.
- RC4 디자인/빠른 서식 미리보기는 이번 범위에 포함하지 않음.
