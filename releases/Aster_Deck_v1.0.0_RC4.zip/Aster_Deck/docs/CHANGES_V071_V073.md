# Aster Deck v0.7.1 → v0.7.3 변경 내역

## v0.7.1 — OOXML animation exporter/importer

- 독립 `src/pptx-motion.js` 모듈 추가. 공식 PresentationML 시간표 문서 및 ISO/IEC 29500-1 §19.5를 참고.
- 슬라이드 형상 ID(`cNvPr@id`)에서 개체별 타깃(`p:spTgt@spid`)으로 참조 연결.
- `p:timing`/`p:tnLst`/`p:cTn`/`p:childTnLst` 생성, 클릭/이전과 함께/이전 뒤 시작 조건 출력.
- 페이드/날아오기/드러나기/확대의 `p:animEffect`, 회전/강조 확대의 회전·크기 효과 및 모션 경로 출력. 흔들기는 간소한 회전 강조로 근사.
- 일반 PPTX에서 지원하는 일부 애니메이션 다시 불러오기. 프로젝트 스냅샷은 저장 여부에 따라 별도 처리.

## v0.7.2 — Motion Path Editor

- `src/timeline.js`에 `pathPoint`, `motionPathFrames`, `path` 효과 추가.
- 직선과 단일 2차 곡선(OOXML에서는 동등한 3차 Bézier로 변환) 경로.
- 슬라이드 위 주황 경로, 이동 끝점/곡선 제어점, 상대 좌표 편집 및 Ctrl+Z.
- PPTX에 `p:animMotion`과 정규화한 경로 좌표 기록.

## v0.7.3 — Timeline UX

- 복수 효과 선택, 효과 클립보드 복사·붙여넣기·삭제.
- 트랙 드래그 순서 변경 유지, 막대 끝 드래그로 지속 시간 변경.
- 초 단위 눈금, 시간 위치 스크럽, 타임라인 줌.
- 기존 차트/그룹/글꼴/진단 기능의 브라우저 회귀 검사.

## 알려진 주의 사항

네이티브 PowerPoint의 애니메이션 재생 결과는 Windows PowerPoint에서 직접 확인해야 해. OOXML/XML 구조와 독립 로더·LibreOffice 열기 성공만으로 시각적 재생이 같다고 말할 수는 없어.
