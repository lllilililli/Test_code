# Aster Deck v1.0.0 RC4 검증 보고

## 결과

- Node 단위 검사: **213/213 통과**, 실패·건너뜀·취소 0. 기존 197개 + RC4 16개.
- 번호형 브라우저 검사: **458개 통과**, 아래 모든 스크립트 최종 종료 코드 0.
- 별도 시나리오: `rc2_pointer_browser.py`, `rc2_switch_browser.py`, `compat_v083_external.py` 3개 모두 통과. 마지막 검사는 별도 도구로 생성한 압축 PPTX의 차트/스프레드시트/노트/미수정 슬라이드 원본 파트 6개를 비교.
- 루트와 dist 단일 HTML 바이트 일치. ZIP 무결성 및 샘플·임시 검증 결과 제외 확인.

| 검사 | 실행 파일 | 통과 수 |
|---|---|---:|
| RC4 미리보기·상태·입력 중 내보내기 | `tests/rc4_preview_browser.py` | 57 |
| RC4 PPTX 발표자 노트 | `tests/rc4_notes_browser.py` | 14 |
| RC3 상황별 메뉴·패널 | `tests/rc3_context_browser.py` | 47 |
| RC2 텍스트 편집 | `tests/rc2_interaction_browser.py` | 24 |
| 글꼴 | `tests/fonts_v040.py` | 19 |
| 한글 입력·부분 굵게 | `tests/typing_v040.py` | 2 |
| 그룹·정렬 | `tests/arrange_v041.py` | 36 |
| 스마트 배치 | `tests/smart_v042.py` | 28 |
| 기본 차트 | `tests/chart_v060_browser.py` | 17 |
| 다중 차트 | `tests/chart_v061_browser.py` | 27 |
| PPTX 보존·그룹·마스터 | `tests/compat_v083_browser.py` | 23 |
| 진단 | `tests/diagnostics_v050_browser.py` | 28 |
| 애니메이션 | `tests/motion_v073_browser.py` | 25 |
| 타임라인 | `tests/timeline_v070_browser.py` | 37 |
| Studio | `tests/studios_v093_browser.py` | 31 |
| 작업 공간·복구 | `tests/workspace_v096_browser.py` | 24 |
| RC1 파일·대용량 회귀 | `tests/release_rc1_browser.py` | 19 |

## 핵심 검증

- 테마: 실제 포인터/키보드 미리보기, 문서 JSON·undo 불변, hover 이탈·취소·Escape, 클릭 고정, 현재/전체 적용, 한 단계 undo/redo, 화면 확대율 유지.
- 빠른 서식: 선택 구간만 시각 변경, 실제 포인터 클릭·키보드 Enter 적용, 범위 유지, Escape 후 편집 지속, undo/redo, 780px 창에서 확대·메뉴 잘림 검사, 툴바 내부 안내.
- 상태: 선택/잠금 개체 수, JSON/PPTX 요청 시각, 변경/undo/redo 상태, 상태 표시줄 확대율 버튼.
- 내보내기: Ctrl+S로 입력 중 텍스트/제목/노트를 반영하고 실제 다운로드한 PPTX를 python-pptx로 읽어 검사. 검증 함수를 일시 정지해 저장 중 수정/문서 교체를 결정적으로 재현. 실패 및 순서 역전 시 기준점 불변 검사. 미적용 테마가 JSON에 포함되지 않는지 검사.
- 노트: 한국어·XML 특수문자·빈 문단·줄바꿈의 일반 PPTX 출력/재입력, 편집용 스냅샷, 외부 도구가 생성한 노트의 소프트 줄바꿈, 미수정 원본의 바이트 동일, 도형만 이동했을 때 노트 파트 보존, 노트 수정 시 재생성 확인 필요 상태.
- 화면 확인: 밝은 테마의 디자인 미리보기·빠른 서식 미리보기 및 어두운 작업 공간을 Chromium 스크린샷으로 확인. 검증 이미지는 배포물에 넣지 않음.

## 환경 및 방법

- Node v24.19.0, Python 3.12.14, Playwright/headless Chromium.
- RC4 미리보기 검사는 임시 로컬 HTTP 서버에서 단일 HTML 실행. 나머지는 완성된 단일 HTML 내용을 Chromium에 로드.
- 회귀 검사의 버전 기대값을 RC4로 갱신. Studio 검사는 새 적용 버튼을 누른 뒤 기존 결과를 확인하며, 파일 열기 상태 검사는 다운로드 성공 대신 실제 dirty 상태와 새 표시를 확인.

## 수정 중 발견한 결함

- 미니 툴바의 절대 위치 서브메뉴가 잘릴 수 있어 내부 레이아웃과 실제 높이 기준 배치로 수정.
- 기존 PPTX 출력이 발표자 노트를 포함하지 않아 표준 노트 파트 출력·가져오기를 추가.
- 입력 중 내보내기 시 미확정 입력 누락 및 비동기 완료 시 새 편집 내용을 저장됨으로 표시할 가능성을 스냅샷/기준점 추적으로 보완.

## 미검증

- 실제 Windows/Mac PowerPoint의 화면·애니메이션·차트·노트 인쇄 및 하드웨어 한국어 IME는 미검증.
- file:// 직접 더블클릭은 현재 환경의 정책 제한으로 검증하지 못함. 일반 사용자 PC의 실기 확인이 필요.
- 실제 다운로드 파일의 디스크 저장 성공 여부는 앱이 검증하지 못함. 앱은 다운로드 요청과 해당 문서 내용 기준점을 표시.
- 노트의 복잡한 서식/그림/사용자 지정 노트 마스터 재생성은 미지원. 미수정 원본 파트 보존과 구분.
