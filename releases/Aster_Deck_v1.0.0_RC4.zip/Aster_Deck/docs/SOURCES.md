# 공개 문서 근거 (클린룸)

**기존 PowerPoint/오픈소스 프로그램의 소스 코드를 열어 보거나 복사하지 않았으며**, 다음과 같은 공개 OOXML/공식 문서 및 자체 생성 PPTX 파일의 구조를 기준으로 구현함.

- [Microsoft Learn — Working with presentation slides](https://learn.microsoft.com/en-us/office/open-xml/presentation/working-with-presentation-slides) — 슬라이드 구조와 PresentationML.
- [Microsoft Learn — GroupShape](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.presentation.groupshape?view=openxml-3.0.1) — 그룹 객체 `<p:grpSp>`의 좌표 변환.
- [Microsoft Learn — ShapeTree](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.presentation.shapetree?view=openxml-3.0.1) — 개체 트리와 쌓임 순서.
- [Microsoft Learn — NormalAutoFit](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.drawing.normalautofit?view=openxml-3.0.1) — 텍스트 상자 자동 맞춤.
- [Microsoft Learn — NoAutoFit](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.drawing.noautofit?view=openxml-3.0.1) — 자동 맞춤 해제.
- [ECMA-376 (OOXML)](https://ecma-international.org/publications-and-standards/standards/ecma-376/) — 공개 패키징·도형 XML 규격.

공개 표준과 별개로 실사용 검증을 위한 브라우저 조작 테스트, `python-pptx` 읽기 검사, LibreOffice의 문서 열기/렌더링 검사를 수행함. `python-pptx`의 구현 코드는 제품으로 복사하지 않았고 **테스트용 외부 파일 판독 라이브러리로만 사용**함.
