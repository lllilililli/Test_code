// Aster Deck object arrangement engine. Framework-free, undoable by Store.execute.
// Grouping is non-destructive: siblings retain global slide coordinates and z-order.
export function picked(elements, ids) {
  const selection = new Set(ids);
  for (const e of elements) if (selection.has(e.id) && e.groupId)
    for (const mate of elements) if (mate.groupId === e.groupId) selection.add(mate.id);
  return elements.filter(e => selection.has(e.id));
}
export function box(elements) {
  if (!elements.length) return null;
  const x=Math.min(...elements.map(e=>e.x)),y=Math.min(...elements.map(e=>e.y));
  const right=Math.max(...elements.map(e=>e.x+e.w)),bottom=Math.max(...elements.map(e=>e.y+e.h));
  return {x,y,w:right-x,h:bottom-y,right,bottom};
}
export const canEdit=elements=>elements.length>0&&elements.every(e=>!e.locked);
export function translate(elements,ids,dx,dy){const chosen=picked(elements,ids);if(!canEdit(chosen))return false;for(const e of chosen){e.x+=dx;e.y+=dy}return true}
export function resize(elements,ids,dx,dy){const chosen=picked(elements,ids);if(!canEdit(chosen))return false;
 const b=box(chosen),nw=Math.max(8,b.w+dx),nh=Math.max(8,b.h+dy),sx=b.w>0?nw/b.w:1,sy=b.h>0?nh/b.h:1;
 for(const e of chosen){e.x=b.x+(e.x-b.x)*sx;e.y=b.y+(e.y-b.y)*sy;e.w=Math.max(3,e.w*sx);e.h=Math.max(3,e.h*sy)}return true}
// Treat each group as a single layout unit so its internal geometry cannot collapse.
export function units(elements,ids){
 const chosen=picked(elements,ids),map=new Map();
 for(const e of chosen){const key=e.groupId||e.id;if(!map.has(key))map.set(key,[]);map.get(key).push(e)}
 return [...map.values()].map(members=>({members,...box(members)}));
}
export function align(elements,ids,axis,edge,canvas={w:960,h:540}){
 const chosen=picked(elements,ids);if(!canEdit(chosen))return false;
 const targets=units(elements,ids);
 const b=targets.length>1?box(chosen):{x:0,y:0,right:canvas.w,bottom:canvas.h,w:canvas.w,h:canvas.h};
 for(const unit of targets){
  const origin=axis==='x'?unit.x:unit.y,dimension=axis==='x'?unit.w:unit.h;
  const dest=axis==='x'?(edge==='start'?b.x:edge==='end'?b.right-dimension:b.x+(b.w-dimension)/2):(edge==='start'?b.y:edge==='end'?b.bottom-dimension:b.y+(b.h-dimension)/2);
  const delta=dest-origin;
  for(const e of unit.members){if(axis==='x')e.x+=delta;else e.y+=delta}
 }
 return true;
}
export function distribute(elements,ids,axis){
 const chosen=picked(elements,ids),targets=units(elements,ids);
 if(targets.length<3||!canEdit(chosen))return false;
 const pos=axis==='x'?'x':'y',size=axis==='x'?'w':'h';
 const sorted=[...targets].sort((a,b)=>a[pos]-b[pos]);
 const start=sorted[0][pos],end=sorted.at(-1)[pos]+sorted.at(-1)[size];
 const total=sorted.reduce((sum,u)=>sum+u[size],0),gap=(end-start-total)/(sorted.length-1);
 let cursor=start;
 for(const unit of sorted){const delta=cursor-unit[pos];for(const e of unit.members)e[pos]+=delta;cursor+=unit[size]+gap}
 return true;
}
export function group(elements,ids,id){const chosen=picked(elements,ids);if(chosen.length<2||!canEdit(chosen))return false;
 for(const e of chosen)e.groupId=id;return true}
export function ungroup(elements,ids){const chosen=picked(elements,ids);if(!chosen.some(e=>e.groupId))return false;
 for(const e of chosen)delete e.groupId;return true}
export function setLocked(elements,ids,locked){const chosen=picked(elements,ids);if(!chosen.length)return false;
 for(const e of chosen)e.locked=locked;return true}
export function deleteSelected(elements,ids){const chosen=picked(elements,ids);if(!canEdit(chosen))return false;
 const removes=new Set(chosen.map(e=>e.id));for(let i=elements.length-1;i>=0;i--)if(removes.has(elements[i].id))elements.splice(i,1);return true}
export function duplicate(elements,ids,newId=()=>Math.random().toString(36).slice(2)){
 const chosen=picked(elements,ids);if(!canEdit(chosen))return [];
 const groupMap=new Map();const clones=chosen.map(e=>{const c=structuredClone(e);c.id=newId();c.x+=22;c.y+=22;if(c.groupId){if(!groupMap.has(c.groupId))groupMap.set(c.groupId,newId());c.groupId=groupMap.get(c.groupId)}return c});
 elements.push(...clones);return clones.map(e=>e.id);
}
export function reorder(elements,ids,method){const chosen=picked(elements,ids);if(!canEdit(chosen))return false;
 const selected=new Set(chosen.map(e=>e.id));if(method==='front'||method==='back'){
  const moved=elements.filter(e=>selected.has(e.id)),rest=elements.filter(e=>!selected.has(e.id));
  elements.splice(0,elements.length,...(method==='front'?[...rest,...moved]:[...moved,...rest]));return true;
 }
 if(method==='forward'){for(let i=elements.length-2;i>=0;i--)if(selected.has(elements[i].id)&&!selected.has(elements[i+1].id))[elements[i],elements[i+1]]=[elements[i+1],elements[i]]}
 if(method==='backward'){for(let i=1;i<elements.length;i++)if(selected.has(elements[i].id)&&!selected.has(elements[i-1].id))[elements[i],elements[i-1]]=[elements[i-1],elements[i]]}
 return true;
}
