// Aster Deck v0.5.0 — pure, dependency-free document preflight rules.
// Geometry is in Aster logical 960x540 pixels. These findings are heuristics,
// NOT a PowerPoint renderer, font availability oracle, or OOXML schema validator.
const WIDTH = 960, HEIGHT = 540;
const isNum = n => Number.isFinite(Number(n));
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
const isText = e => Boolean(e && e.type !== 'image' && e.type !== 'chart' && e.type !== 'connector' && e.type !== 'line' && (e.text || e.runs?.length));
const tid = e => String(e?.text ?? e?.runs?.map(r=>r.text).join('') ?? '');
const groups = {compat:'PPTX 호환성',design:'디자인 품질'};
export const severityOrder = {error:0,warning:1,info:2};
export function rgb(value) {
 if(typeof value !== 'string')return null;
 const s=value.trim().toLowerCase();if(s==='transparent'||s==='none'||s==='')return null;
 const short=/^#([a-f\d]{3,4})$/i.exec(s),long=/^#([a-f\d]{6})(?:[a-f\d]{2})?$/i.exec(s);
 if(short){const h=short[1];return [0,1,2].map(i=>parseInt(h[i]+h[i],16));}
 if(long)return [0,2,4].map(i=>parseInt(long[1].slice(i,i+2),16));
 const fn=/^rgba?\(\s*(\d+)\s*[, ]\s*(\d+)\s*[, ]\s*(\d+)/.exec(s);
 if(fn)return fn.slice(1).map(n=>clamp(Number(n),0,255));
 const names={white:'#ffffff',black:'#000000',navy:'#000080',red:'#ff0000',blue:'#0000ff',gray:'#808080',grey:'#808080'};
 return names[s]?rgb(names[s]):null;
}
export function contrastRatio(a,b){const A=rgb(a),B=rgb(b);if(!A||!B)return null;
 const lum=v=>v.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
 const la=lum(A),lb=lum(B);return (Math.max(la,lb)+.05)/(Math.min(la,lb)+.05);
}
// Font-dependent widths are deliberately conservative; measured browser and
// PowerPoint line breaks will still differ, especially on machines with missing fonts.
export function estimateText(e){const value=tid(e),font=Math.max(1,Number(e.fontSize)||24),spacing=clamp(Number(e.lineSpacing)||1.2,.8,3),padX=Math.max(0,e.textMarginX == null?4:Number(e.textMarginX)||0),padY=Math.max(0,e.textMarginY == null?2:Number(e.textMarginY)||0),availableW=Math.max(1,(Number(e.w)||1)-2*padX);
 const width=(text,size=font)=>Array.from(text).reduce((sum,ch)=>sum+size*(/[\uAC00-\uD7A3\u3000-\u9FFF]/.test(ch)?0.96:/\s/.test(ch)?0.30:/[A-Z]/.test(ch)?0.67:/[.,;:!iIl1\|]/.test(ch)?0.28:0.53),0)*(e.bold?1.035:1);
 const lines=value.split('\n'),wrapLines=lines.reduce((total,line)=>total+Math.max(1,Math.ceil(width(line)/availableW)),0),longest=Math.max(0,...lines.map(l=>width(l))),requiredHeight=wrapLines*font*spacing+2*padY;
 return {value,wrapLines,longest,availableW,requiredHeight,font,lineSpacing:spacing};
}
const key = (rule,sid,eid='') => `${rule}:${sid}:${eid}`;
export function scanDeck(deck,opts={}){
 const issues=[],ignored=new Set(deck.diagnosticIgnores||[]);
 const add=(rule,category,severity,slideId,elementId,title,detail,fix=null,meta={})=>{
  const id=key(rule,slideId,elementId);if(ignored.has(id))return;
  issues.push({id,rule,category,severity,slideId,elementId,title,detail,fix,...meta});
 };
 if(!deck?.slides?.length)return issues;
 if(deck.master?.elements?.length)add('compat.master','compat','info',deck.slides[0].id,'','마스터 고급 기능 확인','일반 PPTX는 마스터에 공통 기본 도형을 저장하지만, 특수 마스터 효과와 차트는 보존되지 않을 수 있어.');
 for(let i=0;i<deck.slides.length;i++){
  const slide=deck.slides[i],slideId=slide.id,bg=deck.master?.useBackground&&!slide.hideMaster?deck.master.background:slide.background||'#ffffff';
  const elements=slide.elements||[];
  if(slide.hideMaster)add('compat.masterHide','compat','info',slideId,'','이 슬라이드는 마스터 개체를 숨겨','PPTX에서도 showMasterSp=0 옵션으로 숨기도록 저장해.');
  const textItems=[];
  let animated=false;
  const foundFonts=new Set();
  for(const e of elements){
   if(e.type==='connector'){
    add('compat.connector','compat','info',slideId,e.id,'연결선 추적 관계가 분리돼','일반 PPTX에서는 현재 선 모양을 개별 선분으로 저장해. 자동 연결 대상 ID는 유지되지 않아.');
    continue;
   }
   if(e.animation?.effect&&e.animation.effect!=='none')animated=true;
   const x=Number(e.x),y=Number(e.y),w=Number(e.w),h=Number(e.h);
   if([x,y,w,h].every(Number.isFinite)&&w>0&&h>0){
    if(x<-1||y<-1||x+w>WIDTH+1||y+h>HEIGHT+1)add('compat.offslide','compat','warning',slideId,e.id,'슬라이드 밖으로 나간 개체',`위치 (${Math.round(x)}, ${Math.round(y)}), 크기 ${Math.round(w)}×${Math.round(h)}px · 의도적인 배경 장식일 수도 있어.`,w<=WIDTH&&h<=HEIGHT?'reposition':null);
    else if(isText(e)&&(x<26||y<26||x+w>WIDTH-26||y+h>HEIGHT-26))add('design.safezone','design','info',slideId,e.id,'텍스트가 안전 여백에 가까워','발표 화면 가장자리에서 최소 26px 정도 여유를 두면 다양한 화면에서 읽기 편해져.',w<=WIDTH-52&&h<=HEIGHT-52?'safezone':null);
   }
   if(!isText(e)||!tid(e).trim())continue;
   textItems.push(e);
   const m=estimateText(e);
   if(e.type==='text' && m.requiredHeight>h+Math.max(8,m.font*.16))add('compat.overflow','compat','warning',slideId,e.id,'텍스트가 상자에서 넘칠 수 있어',`예상 필요 높이 ${Math.ceil(m.requiredHeight)}px / 실제 ${Math.round(h)}px · 글꼴에 따라 달라질 수 있어.`,y+m.requiredHeight<=HEIGHT?'fitText':null);
   else if(m.longest>m.availableW*.92&&m.longest<m.availableW*1.18)add('compat.wraprisk','compat','info',slideId,e.id,'글꼴 환경에 따른 줄바꿈 주의',`추정 한 줄 폭 ${Math.ceil(m.longest)}px / 공간 ${Math.round(m.availableW)}px. PowerPoint에서 줄 수가 달라질 수 있어.`);
   if(m.font<17 && m.value.length>2)add('design.smalltext','design','warning',slideId,e.id,'작은 본문 글자',`글자 크기 ${m.font}px. 발표 장소에서는 18px 이상을 고려해 봐.`);
   let foregrounds=e.runs?.length?[...new Set(e.runs.map(r=>r.color||e.color||'#243045'))]:[e.color||'#243045'];
   const background= e.fill && e.fill!=='transparent'?e.fill:bg;
   if(e.type==='text'||(!e.fill||e.fill==='transparent'||rgb(e.fill)))for(const fg of foregrounds){const c=contrastRatio(fg,background);const limit=e.fontSize>=24||(e.bold&&e.fontSize>=19)?3:4.5;
    if(c!=null&&c<limit)add('design.contrast','design',c<2.5?'error':'warning',slideId,e.id,'글자와 배경의 대비가 부족해',`추정 대비 ${c.toFixed(2)}:1 · 권장 ${limit}:1 이상. 실제 배경 이미지·투명도는 반영하지 않아.`,!e.runs?.length?'contrast':null);
   }
   const font=String(e.fontFamily||'Arial');
   // This is a portability warning, not an assertion that the font is missing.
   const common=/^(Arial|Times New Roman|Georgia|Verdana|Courier New|Tahoma|Calibri|Aptos|맑은 고딕|굴림|돋움)$/i;
   if(!common.test(font)&&!foundFonts.has(font)){
    foundFonts.add(font);
    add('compat.font','compat','info',slideId,e.id,'글꼴 대체 가능성 확인',`「${font}」이 다른 컴퓨터에 없으면 글꼴이 대체되고 줄바꿈이 달라질 수 있어. 글꼴 설치 여부를 자동 확정한 경고는 아니야.`);
   }
  }
  if(animated)add('compat.animation','compat','info',slideId,'','애니메이션을 실제 PowerPoint에서 확인해 줘','PPTX에 타이밍 XML을 기록하지만 Microsoft PowerPoint 실기 검증은 별도로 필요해.');
  // Detect only near-miss alignment (not full-column layout analysis).
  // Restrict to matching-size text frames in distinct rows to avoid card contents.
  for(let a=0;a<textItems.length;a++)for(let b=a+1;b<textItems.length;b++){
   const p=textItems[a],q=textItems[b];
   if(p.groupId&&p.groupId===q.groupId)continue;
   if(p.type!=='text'||q.type!=='text')continue;
   if(Math.abs(p.w-q.w)>12||Math.abs(p.y-q.y)<Math.min(p.h,q.h)*.85)continue;
   const delta=Math.abs(p.x-q.x);
   if(delta>=4&&delta<=9)add('design.align','design','info',slideId,q.id,'비슷한 텍스트 상자의 왼쪽 정렬이 미세하게 달라',`비슷한 크기의 텍스트 상자 두 개가 ${Math.round(delta)}px 어긋나 있어. 의도한 배치인지 확인해.`, 'alignX',{targetX:p.x});
  }
  // Warn only when text bounding boxes substantially overlap other text.
  for(let a=0;a<textItems.length;a++)for(let b=a+1;b<textItems.length;b++){
   const p=textItems[a],q=textItems[b];if(p.groupId&&p.groupId===q.groupId)continue;
   const iw=Math.min(p.x+p.w,q.x+q.w)-Math.max(p.x,q.x),ih=Math.min(p.y+p.h,q.y+q.h)-Math.max(p.y,q.y);
   if(iw>0&&ih>0&&iw*ih>Math.min(p.w*p.h,q.w*q.h)*.16){
    add('design.textoverlap','design','warning',slideId,p.id,'텍스트 상자끼리 겹쳐',`「${tid(p).slice(0,15)}」와 「${tid(q).slice(0,15)}」의 영역이 겹쳐. 의도한 구성인지 확인해.`);break;
   }
  }
 }
 return issues.sort((a,b)=>severityOrder[a.severity]-severityOrder[b.severity]||a.category.localeCompare(b.category)||deck.slides.findIndex(s=>s.id===a.slideId)-deck.slides.findIndex(s=>s.id===b.slideId));
}
export function summary(issues){return {total:issues.length,error:issues.filter(x=>x.severity==='error').length,warning:issues.filter(x=>x.severity==='warning').length,info:issues.filter(x=>x.severity==='info').length,compat:issues.filter(x=>x.category==='compat').length,design:issues.filter(x=>x.category==='design').length};}
export function applyFix(deck,issue){if(!issue?.fix||!issue.elementId)return false;
 const slide=deck.slides?.find(s=>s.id===issue.slideId),e=slide?.elements?.find(x=>x.id===issue.elementId);if(!e||e.locked)return false;
 if(issue.fix==='fitText'&&e.type==='text'){
  const needed=Math.ceil(estimateText(e).requiredHeight+2);if(needed<=e.h||e.y+needed>HEIGHT)return false;e.h=needed;return true;
 }
 if(['reposition','safezone'].includes(issue.fix)){
  const margin=issue.fix==='safezone'?26:0;if(e.w>WIDTH-2*margin||e.h>HEIGHT-2*margin)return false;
  const x=clamp(e.x,margin,WIDTH-margin-e.w),y=clamp(e.y,margin,HEIGHT-margin-e.h);
  if(x===e.x&&y===e.y)return false;e.x=x;e.y=y;return true;
 }
 if(issue.fix==='alignX'&&isText(e)&&isNum(issue.targetX)){const target=Number(issue.targetX);if(target===e.x||target<0||target+e.w>WIDTH)return false;e.x=target;return true;}
 if(issue.fix==='contrast'&&isText(e)&&!e.runs?.length){
  const bg=e.fill&&e.fill!=='transparent'?e.fill:deck.master?.useBackground&&!slide.hideMaster?deck.master.background:slide.background||'#ffffff';
  const candidates=['#101b30','#ffffff'];const optimal=candidates.sort((a,b)=>contrastRatio(b,bg)-contrastRatio(a,bg))[0];
  if(e.color===optimal)return false;e.color=optimal;return true;
 }
 return false;
}
