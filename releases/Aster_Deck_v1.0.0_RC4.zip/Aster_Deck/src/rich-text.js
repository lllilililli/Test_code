// Independent rich-text model. UTF-16 offsets match browser Selection ranges.
export const TEXT_KEYS=['fontFamily','fontSize','color','bold','italic','underline'];
export const textRuns=e=>Array.isArray(e.runs)&&e.runs.length?e.runs.map(r=>({...r})):[{text:String(e.text||'')}];
export const plainText=e=>Array.isArray(e.runs)&&e.runs.length?e.runs.map(r=>r.text).join(''):String(e.text||'');
const key=r=>JSON.stringify(TEXT_KEYS.map(k=>r[k]??null));
export function mergeRuns(runs){const out=[];for(const item of runs){const r={...item,text:String(item.text??'')};if(!r.text)continue;const last=out.at(-1);if(last&&key(last)===key(r))last.text+=r.text;else out.push(r)}return out.length?out:[{text:''}];}
export function patchRuns(runs,start,end,props){const out=[];let pos=0;for(const r of mergeRuns(runs)){const a=pos,b=pos+r.text.length;pos=b;if(b<=start||a>=end){out.push({...r});continue}if(a<start)out.push({...r,text:r.text.slice(0,start-a)});out.push({...r,...props,text:r.text.slice(Math.max(start,a)-a,Math.min(end,b)-a)});if(b>end)out.push({...r,text:r.text.slice(end-a)})}return mergeRuns(out)}
export function patchElement(e,start,end,props){e.runs=patchRuns(textRuns(e),start,end,props);e.text=e.runs.map(r=>r.text).join('')}
export function setUniform(e,property,value){e[property]=value;if(e.runs){e.runs=mergeRuns(e.runs.map(r=>{const n={...r};delete n[property];return n}));e.text=e.runs.map(r=>r.text).join('')}}
export const runStyle=(e,r)=>Object.fromEntries(TEXT_KEYS.map(k=>[k,r[k]??e[k]]));
