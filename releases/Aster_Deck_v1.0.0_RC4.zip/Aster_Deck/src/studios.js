// Aster Studio utilities: original independent document transforms.
export const THEMES={
 arctic:{name:'Arctic',bg:'#f7fbff',text:'#183453',accent:'#2778c9',secondary:'#23a8a1',muted:'#5b718c',surface:'#eaf3fc'},
 midnight:{name:'Midnight',bg:'#15243d',text:'#f1f6ff',accent:'#76b7ff',secondary:'#e0a461',muted:'#b6c7df',surface:'#273b58'},
 editorial:{name:'Editorial',bg:'#fffaf3',text:'#342c28',accent:'#c6654d',secondary:'#51877a',muted:'#6f6a64',surface:'#f4e9dc'},
 botanical:{name:'Botanical',bg:'#f4faf6',text:'#203c36',accent:'#2d9372',secondary:'#bd8c54',muted:'#638078',surface:'#e3f1e9'},
 violet:{name:'Violet Lab',bg:'#faf8ff',text:'#30244c',accent:'#8159cb',secondary:'#e07b98',muted:'#7d7198',surface:'#efe9fa'},
};
const copy=x=>JSON.parse(JSON.stringify(x));
const normal=s=>String(s??'').trim().toLowerCase();
const isTransparent=c=>!c||c==='transparent'||c==='#00000000';
export function applyTheme(deck,name,scope='all'){
 const palette=THEMES[name];if(!palette)throw Error('Unknown theme');
 const slides=scope==='current'?deck.slides.filter(s=>s.id===deck.activeThemeSlide):deck.slides;
 for(const slide of slides){slide.background=palette.bg;slide.designTheme=name;
  const fills=[palette.accent,palette.secondary,palette.surface];let n=0;
  for(const e of slide.elements){if(e.locked||e.type==='image'||e.type==='connector')continue;
   if(e.type==='chart'){e.chartColor=palette.accent;if(Array.isArray(e.chartSeries))e.chartSeries.forEach((s,i)=>s.color=fills[i%fills.length]);continue}
   if(e.type==='text'||isTransparent(e.fill)){e.color=palette.text;if(Array.isArray(e.runs))e.runs.forEach(r=>{if(r.color)r.color=palette.text});}
   else if(['rect','rounded','ellipse','star','arrow'].includes(e.type)){
    e.fill=fills[n++%fills.length];if(e.text){e.color=readableThemeText(e.fill,palette.text);if(Array.isArray(e.runs))e.runs.forEach(r=>{if(r.color)r.color=e.color})}
   }
  }
 }
 deck.designTheme=name;
 return slides.length;
}
export function typography(deck,scope='all'){
 const targets=scope==='current'?deck.slides.filter(s=>s.id===deck.activeThemeSlide):deck.slides;
 let count=0;for(const s of targets)for(const e of s.elements){if(e.type!=='text')continue;
  const size=Number(e.fontSize)||22;
  if(size>=38){e.fontSize=44;e.bold=true;count++}else if(size>=25){e.fontSize=28;count++}else if(size<16){e.fontSize=18;count++}
 }return count;
}
function eachText(deck,fn){const containers=[...(deck.slides||[]),...(deck.master?[deck.master]:[])];for(const s of containers)for(const e of s.elements||[])if(typeof e.text==='string'&&e.text){fn(e,s)}}
export function scanFonts(deck){const map=new Map();eachText(deck,(e,s)=>{
 const runs=e.runs?.length?e.runs:[{text:e.text,fontFamily:e.fontFamily}];
 for(const r of runs){const name=String(r.fontFamily||e.fontFamily||'Arial').trim();if(!name)continue;
 const k=normal(name);if(!map.has(k))map.set(k,{name,characters:0,objects:new Set(),slides:new Set()});
 const rec=map.get(k);rec.characters+=String(r.text||'').length;rec.objects.add(e.id);rec.slides.add(s.id||'master');}
 });return [...map.values()].map(r=>({name:r.name,characters:r.characters,objects:r.objects.size,slides:r.slides.size})).sort((a,b)=>b.objects-a.objects||a.name.localeCompare(b.name));}
export function replaceFont(deck,from,to){const source=normal(from),target=String(to||'').trim();if(!source||!target||source===normal(target))return 0;let changed=0;
 eachText(deck,e=>{const base=String(e.fontFamily||'Arial');if(e.runs?.length){for(const r of e.runs){const used=r.fontFamily||base;if(normal(used)===source){r.fontFamily=target;changed++}}if(normal(base)===source)e.fontFamily=target;}
 else if(normal(base)===source){e.fontFamily=target;changed++;}});
 return changed;
}
const compactObject=e=>({type:e.type,text:e.text||'',runs:e.runs||null,x:e.x,y:e.y,w:e.w,h:e.h,fontFamily:e.fontFamily,fontSize:e.fontSize,fill:e.fill,color:e.color,stroke:e.stroke,rotation:e.rotation,chartData:e.chartData,chartSeries:e.chartSeries,src:e.type==='image'?String(e.src||'').slice(0,100):undefined});
function comparableSlide(s){return {name:s.name,background:s.background,notes:s.notes,transition:s.transition,elements:(s.elements||[]).map(compactObject)}}
export function compareDecks(current,other){if(!Array.isArray(other?.slides)||!Array.isArray(current?.slides))throw Error('Invalid decks');
 const max=Math.max(current.slides.length,other.slides.length),results=[];
 for(let i=0;i<max;i++){
  const a=current.slides[i],b=other.slides[i];let status='same',detail=[];
  if(!a){status='added';detail=['비교 문서에 새 슬라이드 있음']}
  else if(!b){status='removed';detail=['비교 문서에 해당 슬라이드 없음']}
  else{
   if(a.name!==b.name)detail.push('슬라이드 이름 변경');
   if(a.background!==b.background)detail.push('배경 변경');
   if((a.notes||'')!==(b.notes||''))detail.push('발표자 노트 변경');
   if(a.transition!==b.transition)detail.push('전환 효과 변경');
   const len=Math.max(a.elements.length,b.elements.length);let text=0,layout=0,style=0,objects=0;
   for(let j=0;j<len;j++){
    const x=a.elements[j],y=b.elements[j];if(!x||!y){objects++;continue}
    const p=compactObject(x),q=compactObject(y);
    if(p.text!==q.text||JSON.stringify(p.runs)!==JSON.stringify(q.runs))text++;
    if(['x','y','w','h','rotation'].some(k=>p[k]!==q[k]))layout++;
    if(['fontFamily','fontSize','fill','color','stroke'].some(k=>p[k]!==q[k]))style++;
    if(p.type!==q.type||JSON.stringify(p.chartData)!==JSON.stringify(q.chartData)||JSON.stringify(p.chartSeries)!==JSON.stringify(q.chartSeries)||p.src!==q.src)objects++;
   }
   if(text)detail.push(`텍스트 ${text}개`);if(layout)detail.push(`위치·크기 ${layout}개`);if(style)detail.push(`서식 ${style}개`);if(objects)detail.push(`개체·차트 ${objects}개`);
   if(detail.length)status='changed';
  }
  results.push({index:i,status,detail,title:b?.name||a?.name||`슬라이드 ${i+1}`});
 }
 return {slides:results,changed:results.filter(x=>x.status!=='same').length,sourceCount:current.slides.length,compareCount:other.slides.length};
}
export function applyComparedSlide(deck,other,index,makeId){const from=other.slides[index];if(!from)throw Error('비교 문서에 슬라이드가 없어');const old=deck.slides[index];const next=copy(from);
 if(old){next.id=old.id;deck.slides[index]=next;}else{next.id=makeId?makeId():next.id;deck.slides.push(next)}
 return next.id;
}
export function sourceDiff(oldChart,newChart){const a=oldChart.chartData||[],b=newChart.chartData||[];
 const oldSeries=oldChart.chartSeries||[],newSeries=newChart.chartSeries||[];
 let changed=0;const max=Math.max(a.length,b.length);for(let i=0;i<max;i++)if(JSON.stringify(a[i])!==JSON.stringify(b[i]))changed++;
 for(let i=0;i<Math.max(oldSeries.length,newSeries.length);i++)if(JSON.stringify(oldSeries[i])!==JSON.stringify(newSeries[i]))changed++;
 return {changedRows:changed,oldRows:a.length,newRows:b.length,oldSeries:oldSeries.length,newSeries:newSeries.length,identical:changed===0};
}
export function filterChart(chart,mode='all',limit=5){const data=chart.chartRaw||{chartData:copy(chart.chartData||[]),chartSeries:copy(chart.chartSeries||[])};
 const labels=data.chartData.map((r,i)=>({index:i,label:r.label,total:data.chartSeries.reduce((sum,s)=>sum+(Number(s.values?.[i])||0),0)}));
 const count=Math.max(1,Math.min(100,Number(limit)||5));let indices=labels.map(x=>x.index);
 if(mode==='top')indices=labels.slice().sort((a,b)=>b.total-a.total).slice(0,count).map(x=>x.index);
 if(mode==='bottom')indices=labels.slice().sort((a,b)=>a.total-b.total).slice(0,count).map(x=>x.index);
 if(mode==='first')indices=indices.slice(0,count);
 chart.chartData=indices.map(i=>copy(data.chartData[i]));chart.chartSeries=data.chartSeries.map(s=>({...copy(s),values:indices.map(i=>s.values?.[i]??null)}));
 chart.chartFilter={mode,count};chart.chartRaw=copy(data);return indices.length;
}
// Editable presentation table: a documented shape-based snapshot, never a fake native PPTX table.
export function makeDataTable(chart,makeShape,createId,maxRows=8,conditional=true){
 const cols=(chart.chartSeries?.length?chart.chartSeries:[{name:'값',values:(chart.chartData||[]).map(x=>x.value)}]).slice(0,4);
 const cats=(chart.chartData||[]).slice(0,Math.min(12,Math.max(1,maxRows)));
 const rows=[[ '항목',...cols.map(x=>x.name)],...cats.map((r,i)=>[r.label,...cols.map(s=>s.values?.[i]??'')])];
 const width=810/Math.max(1,rows[0].length),height=Math.min(40,325/Math.max(1,rows.length)),groupId=createId(),elements=[];
 const avgs=cols.map(s=>{const nums=(s.values||[]).filter(x=>typeof x==='number'&&Number.isFinite(x));return nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:0});
 for(let row=0;row<rows.length;row++)for(let col=0;col<rows[row].length;col++){
  const cell=makeShape('rounded',75+col*width,150+row*height);cell.id=createId();cell.groupId=groupId;
  cell.w=width-3;cell.h=height-3;cell.radius=3;cell.fontSize=13;cell.text=String(rows[row][col]??'');cell.bold=row===0;
  cell.color=row===0?'#ffffff':'#293f57';cell.fill=row===0?'#2b5e96':row%2===0?'#f1f5fa':'#ffffff';
  if(row>0&&col>0&&conditional){const num=Number(rows[row][col]);if(rows[row][col]!==''&&Number.isFinite(num))cell.fill=num>=avgs[col-1]?'#e3f5ec':'#fff1ea'}
  elements.push(cell);
 }
 return {elements,groupId,rows:rows.length,cols:rows[0].length};
}

export function readableThemeText(fill,preferred='#17263f'){
 const luminance=hex=>{const rgb=String(hex).replace('#','').match(/.{2}/g);if(!rgb||rgb.length!==3)return 1;return rgb.map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4).reduce((n,x,i)=>n+x*[.2126,.7152,.0722][i],0)};
 const bg=luminance(fill),ratio=c=>{const v=luminance(c);return (Math.max(bg,v)+.05)/(Math.min(bg,v)+.05)};
 return [preferred,'#ffffff','#17263f'].sort((a,b)=>ratio(b)-ratio(a))[0];
}
export function previewTheme(deck,slideId,name){
 const target=deck.slides.find(s=>s.id===slideId);if(!target)throw Error('슬라이드를 찾을 수 없어');
 const draft={slides:[copy(target)]};applyTheme(draft,name,'all');return draft.slides[0];
}
