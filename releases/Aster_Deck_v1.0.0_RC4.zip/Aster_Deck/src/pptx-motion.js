// Independent PresentationML animation serializer and subset parser.
// Public specification: ISO/IEC 29500-1 §19.5, Microsoft Open XML docs.
// No Microsoft application code or third-party presentation code used.
const esc = s=>String(s??'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
const ms=n=>Math.round(Math.max(0,Math.min(15000,Number(n)||0))*1000);
const attr=(node,key,fallback='')=>node?.getAttribute(key)??fallback;
const subs=(root,name)=>Array.from(root?.getElementsByTagNameNS('*',name)||[]);
const point=(p)=>({x:Number(p?.x)||0,y:Number(p?.y)||0});
export function motionPath(step){
 const dx=Number(step.pathDx??160),dy=Number(step.pathDy??0),curve=Number(step.pathCurve??0);
 const coords=step.pathType==='curve'
  ?`M 0 0 C ${+(dx/3/960).toFixed(6)} ${+((dy/3+4*curve/3)/540).toFixed(6)} ${+((2*dx/3)/960).toFixed(6)} ${+((2*dy/3+4*curve/3)/540).toFixed(6)} ${+(dx/960).toFixed(6)} ${+(dy/540).toFixed(6)} E`
  :`M 0 0 L ${+(dx/960).toFixed(6)} ${+(dy/540).toFixed(6)} E`;
 return coords;
}
const behavior=(id,duration,shapeId,attributes='')=>`<p:cBhvr${attributes}><p:cTn id="${id}" dur="${duration}" fill="hold"/><p:tgtEl><p:spTgt spid="${shapeId}"/></p:tgtEl></p:cBhvr>`;
function effectXml(x,shapeId,id){
 const dur=ms(x.duration||.65),kind=x.kind||'entrance',change=kind==='exit'?'out':'in';
 const filter=({fade:'fade',fly:'fly',wipe:'wipe',zoom:'zoom'})[x.effect];
 const direction=({left:'l',right:'r',up:'t',down:'b'})[x.direction]||'r';
 if(filter){const more=x.effect==='fly'?` prLst="from(${direction})"`:x.effect==='wipe'?` prLst="from(${direction})"`:'';
  return `<p:animEffect transition="${change}" filter="${filter}"${more}>${behavior(id,dur,shapeId)}</p:animEffect>`;}
 if(x.effect==='spin')return `<p:animRot by="21600000">${behavior(id,dur,shapeId)}</p:animRot>`;
 if(x.effect==='pulse')return `<p:animScale>${behavior(id,dur,shapeId)}<p:by x="112000" y="112000"/></p:animScale>`;
 if(x.effect==='path')return `<p:animMotion origin="parent" path="${esc(motionPath(x))}" pathEditMode="relative">${behavior(id,dur,shapeId)}</p:animMotion>`;
 // Shake is a discrete local Aster effect; fall back to a recognized emphasis.
 if(x.effect==='shake')return `<p:animRot by="600000">${behavior(id,dur,shapeId)}</p:animRot>`;
 return `<p:animEffect transition="${change}" filter="fade">${behavior(id,dur,shapeId)}</p:animEffect>`;
}
/** A slide-level p:timing tree. Shape identifiers correspond to cNvPr@id. */
export function timingXml(slide,objectIds){
 const alive=new Map(Object.entries(objectIds||{}));let next=3;
 const events=(Array.isArray(slide.timeline)?slide.timeline:slide.elements?.filter(e=>e.animation?.effect&&e.animation.effect!=='none').map(e=>({...e.animation,elementId:e.id}))||[])
  .filter(x=>alive.has(x.elementId)&&x.effect&&x.effect!=='none');
 if(!events.length)return '';
 let prevId=0;
 const rows=events.map((x,index)=>{
  const outer=next++,inner=next++,sId=alive.get(x.elementId);
  const trigger=['click','with','after'].includes(x.trigger)?x.trigger:'click';
  const cond=trigger==='click'||!prevId?'<p:cond evt="onClick" delay="0"/>':`<p:cond evt="${trigger==='after'?'onEnd':'onBegin'}" delay="0"><p:tn val="${prevId}"/></p:cond>`;
  const delay=ms(x.delay||0);
  const condition=`<p:stCondLst>${cond}</p:stCondLst>`;
  const startDelay=delay?`<p:stCondLst><p:cond delay="${delay}"/></p:stCondLst>`:'';
  const behaviorXml=effectXml(x,sId,inner);
  prevId=outer;
  return `<p:par><p:cTn id="${outer}" fill="hold" nodeType="${trigger==='click'?'clickEffect':trigger==='after'?'afterEffect':'withEffect'}">${condition}<p:childTnLst><p:par><p:cTn id="${next++}" fill="hold">${startDelay}<p:childTnLst>${behaviorXml}</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>`;
 }).join('');
 return `<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst><p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>${rows}</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst><p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq></p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>`;
}
export function readTiming(doc, shapeIdToModelId){
 const root=subs(doc,'timing')[0];if(!root)return [];
 const effectNodes=['animEffect','animMotion','animRot','animScale'];
 const found=[];
 for(const tag of effectNodes){for(const node of subs(root,tag)){
  const spId=attr(subs(node,'spTgt')[0],'spid'),target=shapeIdToModelId[String(spId)];if(!target)continue;
  const outer=node.closest?.('p\\:par')||null;
  const p=node.parentNode?.parentNode?.parentNode?.parentNode; // under cTn/childTnLst, depending nesting
  const parentTimeline=(()=>{let curr=node;while(curr){if(curr.localName==='cTn'&&curr.hasAttribute('nodeType'))return curr;curr=curr.parentNode;}return null})();
  const nt=attr(parentTimeline,'nodeType');
  const trigger=nt==='withEffect'?'with':nt==='afterEffect'?'after':'click';
  const bhvr=subs(node,'cBhvr')[0];const time=subs(bhvr,'cTn')[0];
  let effect=tag==='animMotion'?'path':tag==='animRot'?'spin':tag==='animScale'?'pulse':attr(node,'filter','fade').split('(')[0];
  if(!['fade','fly','wipe','zoom','path','spin','pulse'].includes(effect))effect='fade';
  const duration=Number(attr(time,'dur',650))/1000;
  const x={id:`import_motion_${found.length+1}`,elementId:target,effect,kind:attr(node,'transition')==='out'?'exit':tag==='animEffect'?'entrance':'emphasis',trigger,duration:Number.isFinite(duration)?duration:.65,delay:0,easing:'ease-out',direction:'right'};
  if(effect==='path'){
   const path=attr(node,'path'),nums=(path.match(/-?\d+(?:\.\d+)?/g)||[]).map(Number);
   if(nums.length>=2){x.pathDx=Math.round(nums.at(-2)*960);x.pathDy=Math.round(nums.at(-1)*540)}
   if(/\bC\b/i.test(path))x.pathType='curve';
  }
  found.push({order:Number(attr(time,'id',0)),value:x});
 }}
 return found.sort((a,b)=>a.order-b.order).map(x=>x.value);
}
