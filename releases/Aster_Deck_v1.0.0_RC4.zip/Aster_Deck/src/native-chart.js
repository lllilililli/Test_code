// Independent chart/SpreadsheetML writer grounded in ISO/IEC 29500 / ECMA-376.
import {zipWrite} from './zip.js';
const esc=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const PALETTE=['#367BDA','#17A398','#905CDC','#EA8734','#DB5471','#677D98','#D3A22A','#4A8C73'];
export const chartPalette=PALETTE;
const validColor=(c,fallback)=>/^#[a-f0-9]{6}$/i.test(c||'')?c:fallback;
const hex=(v,fallback='#3978D9')=>validColor(v,fallback).slice(1).toUpperCase();
const nvalue=v=>v===null||v===undefined||String(v).trim()===''?null:Number.isFinite(Number(v))?Number(v):null;
export function chartRows(e){const rows=(e.chartData||[]).map(d=>({label:String(d.label??'').slice(0,120),value:nvalue(d.value)})).filter(d=>d.label&&d.value!==null).slice(0,100);return rows.length?rows:[{label:'항목 1',value:0}];}
export function chartSpec(e){
 const existing=Array.isArray(e.chartSeries)&&e.chartSeries.length>0;
 const rows=(e.chartData||[]).slice(0,100), categories=rows.map((d,i)=>String(d.label??`항목 ${i+1}`).slice(0,120));
 if(!categories.length){categories.push('항목 1')}
 const original=existing?e.chartSeries:[{name:'값',color:e.chartColor,values:rows.map(d=>d.value)}];
 const series=original.slice(0,12).map((s,i)=>({name:String(s.name||`계열 ${i+1}`).slice(0,80),color:validColor(s.color||e.chartColor,PALETTE[i%PALETTE.length]),values:categories.map((_,j)=>nvalue(s.values?.[j]??(!existing&&i===0?rows[j]?.value:null)))}));
 if(!series.length)series.push({name:'값',color:PALETTE[0],values:categories.map(()=>0)});
 return {categories,series:series.length?series:[{name:'값',color:PALETTE[0],values:[0]}],type:['bar','line','stacked','pie','doughnut'].includes(e.chartType)?e.chartType:'bar',legend:['none','top','bottom','left','right'].includes(e.chartLegend)?e.chartLegend:'bottom',labels:!!e.chartDataLabels,showXAxis:e.chartShowXAxis!==false,showYAxis:e.chartShowYAxis!==false,min:nvalue(e.chartAxisMin),max:nvalue(e.chartAxisMax)};
}
export function chartGraphic(e,id,rId){const emu=n=>Math.round(n*9525);return `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${id}" name="Aster editable chart"/><p:cNvGraphicFramePr/><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="${emu(e.x)}" y="${emu(e.y)}"/><a:ext cx="${emu(e.w)}" cy="${emu(e.h)}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="${rId}"/></a:graphicData></a:graphic></p:graphicFrame>`}
export function xlsxForChart(e){const {categories,series}=chartSpec(e),s='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
 const col=i=>{let out='';for(let n=i+1;n>0;n=Math.floor((n-1)/26))out=String.fromCharCode(65+(n-1)%26)+out;return out};
 const cell=(ref,value)=>value===null||value===undefined?'':typeof value==='number'?`<c r="${ref}"><v>${value}</v></c>`:`<c r="${ref}" t="inlineStr"><is><t>${esc(value)}</t></is></c>`;
 const headers=[cell('A1','항목'),...series.map((s,i)=>cell(col(i+1)+'1',s.name))].join('');
 const rows=categories.map((category,i)=>`<row r="${i+2}">${cell('A'+(i+2),category)}${series.map((s,j)=>cell(col(j+1)+(i+2),s.values[i])).join('')}</row>`).join('');
 const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="${s}"><dimension ref="A1:${col(series.length)}${categories.length+1}"/><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><sheetData><row r="1">${headers}</row>${rows}</sheetData></worksheet>`;
 const rel=(id,t,p)=>`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/${t}" Target="${p}"/>`;
 const rels=a=>`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${a}</Relationships>`;
 return zipWrite({'[Content_Types].xml':`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`,
 '_rels/.rels':rels(rel('rId1','officeDocument','xl/workbook.xml')),
 'xl/workbook.xml':`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="${s}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets><sheet name="Chart Data" sheetId="1" r:id="rId1"/></sheets></workbook>`,
 'xl/_rels/workbook.xml.rels':rels(rel('rId1','worksheet','worksheets/sheet1.xml')+rel('rId2','styles','styles.xml')),
 'xl/styles.xml':`<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="${s}"><fonts count="1"><font><sz val="11"/><name val="Arial"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>`,
 'xl/worksheets/sheet1.xml':sheet});
}
const colLetter=i=>{let a='';for(let n=i+1;n>0;n=Math.floor((n-1)/26))a=String.fromCharCode(65+(n-1)%26)+a;return a};
const tx=title=>`<c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr/><a:r><a:rPr lang="ko-KR" sz="1400"/><a:t>${esc(title)}</a:t></a:r></a:p></c:rich></c:tx>`;
const title=t=>`<c:title>${tx(t)}<c:overlay val="0"/></c:title>`;
export function chartXml(e,bookName){
 const spec=chartSpec(e),{categories,type}=spec,used=(type==='pie'||type==='doughnut')?spec.series.slice(0,1):spec.series;
 const catRange=`'Chart Data'!$A$2:$A$${categories.length+1}`;
 const cache=(values,string)=>`<c:${string?'str':'num'}Cache>${string?'':'<c:formatCode>General</c:formatCode>'}<c:ptCount val="${values.length}"/>${values.map((v,i)=>v===null?'':`<c:pt idx="${i}"><c:v>${string?esc(v):v}</c:v></c:pt>`).join('')}</c:${string?'str':'num'}Cache>`;
 const cat=`<c:cat><c:strRef><c:f>${esc(catRange)}</c:f>${cache(categories,true)}</c:strRef></c:cat>`;
 const dLbls=spec.labels?'<c:dLbls><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/></c:dLbls>':'';
 const ser=used.map((s,i)=>{
  const vRange=`'Chart Data'!$${colLetter(i+1)}$2:$${colLetter(i+1)}$${categories.length+1}`;
  const headerRange=`'Chart Data'!$${colLetter(i+1)}$1`;
  const srName=`<c:tx><c:strRef><c:f>${esc(headerRange)}</c:f>${cache([s.name],true)}</c:strRef></c:tx>`;
  const color=hex(s.color),sp=`<c:spPr><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:ln w="19050"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:ln></c:spPr>`;
  const dPt=(type==='pie'||type==='doughnut')?categories.map((_,j)=>`<c:dPt><c:idx val="${j}"/><c:spPr><a:solidFill><a:srgbClr val="${hex(PALETTE[j%PALETTE.length])}"/></a:solidFill></c:spPr></c:dPt>`).join(''):'';
  return `<c:ser><c:idx val="${i}"/><c:order val="${i}"/>${srName}${sp}${dPt}${type==='line'?'<c:marker><c:symbol val="circle"/><c:size val="6"/></c:marker>':''}${cat}<c:val><c:numRef><c:f>${esc(vRange)}</c:f>${cache(s.values,false)}</c:numRef></c:val>${type==='line'?'<c:smooth val="0"/>':''}</c:ser>`;
 }).join('');
 const pie=type==='pie'||type==='doughnut';
 const kind=pie?`<c:${type==='pie'?'pieChart':'doughnutChart'}><c:varyColors val="1"/>${ser}${dLbls}${type==='doughnut'?'<c:firstSliceAng val="0"/><c:holeSize val="60"/>':''}</c:${type==='pie'?'pieChart':'doughnutChart'}>`:
 type==='line'?`<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${ser}${dLbls}<c:axId val="1001"/><c:axId val="1002"/></c:lineChart>`:
 `<c:barChart><c:barDir val="col"/><c:grouping val="${type==='stacked'?'stacked':'clustered'}"/><c:varyColors val="0"/>${ser}${dLbls}<c:gapWidth val="125"/>${type==='stacked'?'<c:overlap val="100"/>':''}<c:axId val="1001"/><c:axId val="1002"/></c:barChart>`;
 const axisScale=`<c:scaling><c:orientation val="minMax"/>${spec.max!==null?`<c:max val="${spec.max}"/>`:''}${spec.min!==null?`<c:min val="${spec.min}"/>`:''}</c:scaling>`;
 const axes=pie?'':`<c:catAx><c:axId val="1001"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="${spec.showXAxis?0:1}"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="1002"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx><c:valAx><c:axId val="1002"/>${axisScale}<c:delete val="${spec.showYAxis?0:1}"/><c:axPos val="l"/>${e.chartGridlines!==false?'<c:majorGridlines/>':''}<c:numFmt formatCode="General" sourceLinked="1"/><c:tickLblPos val="nextTo"/><c:crossAx val="1001"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>`;
 const legMap={top:'t',bottom:'b',left:'l',right:'r'},legend=spec.legend==='none'?'':`<c:legend><c:legendPos val="${legMap[spec.legend]}"/><c:overlay val="0"/></c:legend>`;
 return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="ko-KR"/><c:chart>${e.chartTitle?title(e.chartTitle):''}<c:autoTitleDeleted val="0"/><c:plotArea><c:layout/>${kind}${axes}</c:plotArea>${legend}<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:externalData r:id="rId1"><c:autoUpdate val="0"/></c:externalData></c:chartSpace>`;
}
export function chartRelationship(bookName){return `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/package" Target="../embeddings/${bookName}"/></Relationships>`}
