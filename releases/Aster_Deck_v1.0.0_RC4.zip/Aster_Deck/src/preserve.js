// Aster Deck v0.8 — conservative OPC preservation, independently implemented.
// Never silently reconstitutes a file after encountering an unsupported edit.
import {zipRead,zipWrite,zipText} from './zip.js';
import {pxToEmu,pxToPptFontSize} from './text-layout.js';
const NS='http://schemas.openxmlformats.org/drawingml/2006/main';
const ALLOWED_SHAPE = new Set(['x','y','w','h','text','fontSize','fontFamily','bold','italic','color','align','textMarginX','textMarginY','lineSpacing','verticalAlign']);
const ALLOWED_SLIDE = new Set(['background']);
const own=(obj)=>Object.keys(obj||{});
function diffKeys(a,b,ignored=new Set()){return [...new Set([...own(a),...own(b)])].filter(k=>!ignored.has(k)&&JSON.stringify(a?.[k])!==JSON.stringify(b?.[k]));}
const findByName=(node,name)=>Array.from(node?.getElementsByTagNameNS('*',name)||[]);
const first=(node,name)=>findByName(node,name)[0];
const str=(node,name,fallback='')=>node?.getAttribute(name)??fallback;
const rgba=color=>String(color||'').replace('#','').trim().toUpperCase();
function error(detail){const e=new Error('원본 보존 저장을 중단했어: '+detail);e.code='UNSAFE_PRESERVATION';return e;}
export function preservationReport(before,after){
 const fail=[];const changed=[];
 if(!before||!after||before.slides?.length!==after.slides?.length)fail.push('슬라이드 추가·삭제는 원본 보존 저장에서 지원하지 않아.');
 if(JSON.stringify(before?.master)!==JSON.stringify(after?.master))fail.push('마스터 편집은 원본 보존 저장에서 지원하지 않아.');
 for(let i=0;i<Math.min(before?.slides?.length||0,after?.slides?.length||0);i++){
  const s=before.slides[i],t=after.slides[i];
  if(s.id!==t.id||s._pptxSlidePath!==t._pptxSlidePath){fail.push(`${i+1}번 슬라이드 순서가 바뀌었어.`);continue;}
  const changes=diffKeys(s,t,new Set(['elements']));
  if(changes.some(k=>!ALLOWED_SLIDE.has(k)))fail.push(`${i+1}번 슬라이드의 ${changes.filter(k=>!ALLOWED_SLIDE.has(k)).join(', ')} 속성은 직접 보존할 수 없어.`);
  if(s.elements.length!==t.elements.length){fail.push(`${i+1}번 슬라이드 개체가 추가·삭제됐어.`);continue;}
  for(let j=0;j<s.elements.length;j++){
   const e=s.elements[j],v=t.elements[j];
   if(e.id!==v.id||e._pptxShapeId!==v._pptxShapeId){fail.push(`${i+1}번 슬라이드 개체의 순서 또는 출처가 바뀌었어.`);continue;}
   const keys=diffKeys(e,v,new Set());if(!keys.length)continue;
   if(!e._pptxShapeId || !['text','rect','rounded','ellipse','star','arrow','line'].includes(e.type)){
    fail.push(`${i+1}번 슬라이드의 수정한 개체는 안전한 XML 부분 수정 대상이 아니야.`);continue;
   }
   if(keys.some(k=>!ALLOWED_SHAPE.has(k)))fail.push(`${i+1}번 슬라이드 개체의 ${keys.filter(k=>!ALLOWED_SHAPE.has(k)).join(', ')} 속성은 안전하게 보존할 수 없어.`);
   if(keys.includes('text') && (e.runs?.length>1 || v.runs?.length>1))fail.push(`${i+1}번 슬라이드의 여러 서식 구간 텍스트 변경은 부분 수정 대상이 아니야.`);
   changed.push({slideIndex:i,elementIndex:j,keys});
  }
 }
 if(before.title!==after.title)fail.push('원본 프레젠테이션 제목 변경은 아직 직접 반영하지 않아.');
 return {safe:fail.length===0,issues:[...new Set(fail)],changes:changed,changedSlides:[...new Set(changed.map(x=>x.slideIndex).concat((before.slides||[]).map((s,i)=>s.background!==after.slides?.[i]?.background?i:-1).filter(i=>i>=0)))]};
}
function applyTextShape(root,old,newShape,keys){
 const tx=first(root,'txBody');
 if(keys.includes('text')){
  if(!tx)throw error('원본에 텍스트 상자가 없어.');
  const values=findByName(tx,'t');
  if(values.length!==1 || String(newShape.text).includes('\n'))throw error('다중 문단이나 텍스트 구간은 부분 수정할 수 없어.');
  values[0].textContent=String(newShape.text??'');
 }
 if(keys.some(k=>['fontSize','fontFamily','bold','italic','color'].includes(k))){
  if(!tx)throw error('글꼴 정보가 없는 개체야.');
  const propNodes=findByName(tx,'rPr');if(!propNodes.length)throw error('글자 서식(rPr)이 없는 원본 개체야.');
  for(const rp of propNodes){
   if(keys.includes('fontSize'))rp.setAttribute('sz',String(pxToPptFontSize(newShape.fontSize)));
   if(keys.includes('bold'))rp.setAttribute('b',newShape.bold?'1':'0');
   if(keys.includes('italic'))rp.setAttribute('i',newShape.italic?'1':'0');
   if(keys.includes('fontFamily'))for(const face of ['latin','ea','cs']){let f=first(rp,face);if(!f){f=root.ownerDocument.createElementNS(NS,'a:'+face);rp.appendChild(f)}f.setAttribute('typeface',String(newShape.fontFamily||'Arial'));}
   if(keys.includes('color')){let fill=first(rp,'solidFill');if(!fill){fill=root.ownerDocument.createElementNS(NS,'a:solidFill');rp.appendChild(fill)}let c=first(fill,'srgbClr');if(!c){c=root.ownerDocument.createElementNS(NS,'a:srgbClr');fill.appendChild(c)}c.setAttribute('val',rgba(newShape.color));}
  }
 }
 if(keys.some(k=>['textMarginX','textMarginY','verticalAlign'].includes(k))){
  const bp=first(tx,'bodyPr');if(!bp)throw error('원본 텍스트 bodyPr이 없어.');
  if(keys.includes('textMarginX'))for(const side of ['lIns','rIns'])bp.setAttribute(side,String(pxToEmu(newShape.textMarginX)));
  if(keys.includes('textMarginY'))for(const side of ['tIns','bIns'])bp.setAttribute(side,String(pxToEmu(newShape.textMarginY)));
  if(keys.includes('verticalAlign'))bp.setAttribute('anchor',({top:'t',middle:'ctr',bottom:'b'})[newShape.verticalAlign]||'t');
 }
 if(keys.some(k=>['align','lineSpacing'].includes(k))){
  for(const para of findByName(tx,'p')){
   let pp=first(para,'pPr');if(!pp){pp=root.ownerDocument.createElementNS(NS,'a:pPr');para.insertBefore(pp,para.firstChild)}
   if(keys.includes('align'))pp.setAttribute('algn',({left:'l',center:'ctr',right:'r'})[newShape.align]||'l');
   if(keys.includes('lineSpacing')){let ln=first(pp,'lnSpc');if(!ln){ln=root.ownerDocument.createElementNS(NS,'a:lnSpc');pp.appendChild(ln)}let pct=first(ln,'spcPct');if(!pct){pct=root.ownerDocument.createElementNS(NS,'a:spcPct');ln.appendChild(pct)}pct.setAttribute('val',String(Math.round(Number(newShape.lineSpacing||1.2)*100000)));}
  }
 }
}
function patchOneSlide(xml,oldSlide,newSlide,changes){
 const doc=new DOMParser().parseFromString(xml,'application/xml');if(first(doc,'parsererror'))throw error('슬라이드 XML을 읽지 못했어.');
 if(oldSlide.background!==newSlide.background){const bp=first(doc,'bgPr'),c=first(bp,'srgbClr');if(!c)throw error('배경에 수정 가능한 RGB 색상이 없어.');c.setAttribute('val',rgba(newSlide.background));}
 for(const change of changes){
  const orig=oldSlide.elements[change.elementIndex],item=newSlide.elements[change.elementIndex];
  const target=findByName(doc,'cNvPr').find(x=>str(x,'id')===orig._pptxShapeId);
  if(!target)throw error('원본에서 개체 '+orig._pptxShapeId+'를 찾지 못했어.');
  let parent=target;while(parent && !['sp','cxnSp','pic'].includes(parent.localName))parent=parent.parentNode;
  if(!parent)throw error('개체의 Shape 노드를 찾지 못했어.');
  const pr=Array.from(parent.children).find(e=>e.localName==='spPr');const xfrm=Array.from(pr?.children||[]).find(e=>e.localName==='xfrm');
  if(change.keys.some(k=>['x','y','w','h'].includes(k))){
   const off=first(xfrm,'off'),ext=first(xfrm,'ext');if(!off||!ext)throw error('개체의 위치·크기 값을 찾지 못했어.');
   for(const [k,node,attr] of [['x',off,'x'],['y',off,'y'],['w',ext,'cx'],['h',ext,'cy']])if(change.keys.includes(k)){let v=item[k];const trans=orig._pptxTransform;if(trans){const factor=(k==='x'||k==='w')?trans.sx:trans.sy;const delta=k==='x'?trans.dx:k==='y'?trans.dy:0;v=(pxToEmu(v)-delta)/factor;node.setAttribute(attr,String(Math.round(v)));}else node.setAttribute(attr,String(pxToEmu(v)));}
  }
  applyTextShape(parent,orig,item,change.keys);
 }
 return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+new XMLSerializer().serializeToString(doc.documentElement);
}
export async function exportPreservedPptx(bytes,before,after){
 const report=preservationReport(before,after);
 if(!report.safe)throw error(report.issues.join(' / '));
 if(!report.changedSlides.length)return bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
 const parts=await zipRead(bytes);
 for(const i of report.changedSlides){
  const path=before.slides[i]._pptxSlidePath;
  if(!path||!parts[path])throw error('원본 슬라이드 파트 주소가 없어.');
  parts[path]=new TextEncoder().encode(patchOneSlide(zipText(parts,path),before.slides[i],after.slides[i],report.changes.filter(x=>x.slideIndex===i)));
 }
 return zipWrite(parts);
}
