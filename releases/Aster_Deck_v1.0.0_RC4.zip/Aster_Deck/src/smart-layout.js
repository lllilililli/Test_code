// Aster Deck v0.4.2 — geometry-only smart alignment and live connectors.
// No DOM dependencies. All coordinates are native 960×540 slide units.
import {picked,units,box,canEdit} from './arrange.js';
const finite=n=>Number.isFinite(n)?n:0;
const center=e=>({x:finite(e.x)+finite(e.w)/2,y:finite(e.y)+finite(e.h)/2});
export const isConnector=e=>e.type==='connector';
export function anchors(elements,edge){
 const a=elements.find(e=>e.id===edge.from),b=elements.find(e=>e.id===edge.to);
 if(!a||!b||a.id===b.id)return null;
 const ca=center(a),cb=center(b),horizontal=Math.abs(cb.x-ca.x)>=Math.abs(cb.y-ca.y);
 let start,end;
 if(horizontal){const right=cb.x>=ca.x;start={x:a.x+(right?a.w:0),y:ca.y};end={x:b.x+(right?0:b.w),y:cb.y};}
 else{const down=cb.y>=ca.y;start={x:ca.x,y:a.y+(down?a.h:0)};end={x:cb.x,y:b.y+(down?0:b.h)};}
 return {start,end,horizontal};
}
export function connectorPath(elements,edge){
 const anchor=anchors(elements,edge);if(!anchor)return null;
 const {start,end,horizontal}=anchor;
 const elbow=edge.route!=='straight';
 let points=elbow?(horizontal?[start,{x:(start.x+end.x)/2,y:start.y},{x:(start.x+end.x)/2,y:end.y},end]:[start,{x:start.x,y:(start.y+end.y)/2},{x:end.x,y:(start.y+end.y)/2},end]):[start,end];
 // Avoid degenerate segments; this also prevents superfluous zero-length arrowheads.
 points=points.filter((p,i)=>!i||p.x!==points[i-1]?.x||p.y!==points[i-1]?.y);
 return {points,d:points.map((p,i)=>`${i?'L':'M'}${Math.round(p.x*100)/100} ${Math.round(p.y*100)/100}`).join(' ')};
}
export function createConnector(elements,from,to,id,route='elbow'){
 const a=elements.find(e=>e.id===from),b=elements.find(e=>e.id===to);
 if(!a||!b||a.id===b.id||isConnector(a)||isConnector(b))return null;
 if(a.locked||b.locked)return null;
 return {id,type:'connector',from,to,route,x:0,y:0,w:1,h:1,stroke:'#4b648b',strokeWidth:3,locked:false,opacity:1};
}
export function connectedIds(elements,ids){const selected=new Set(ids);return elements.filter(e=>isConnector(e)&&(selected.has(e.from)||selected.has(e.to))).map(e=>e.id)}
export function removeDangling(elements){const ids=new Set(elements.filter(e=>!isConnector(e)).map(e=>e.id));for(let i=elements.length-1;i>=0;i--){const e=elements[i];if(isConnector(e)&&(!ids.has(e.from)||!ids.has(e.to)))elements.splice(i,1)}}
// Reflow groups as intact layout units. Scale down only when needed to fit,
// never stretch or change inter-object proportions inside an existing group.
export function smartLayout(elements,ids,mode='grid',canvas={w:960,h:540}){
 const chosen=picked(elements,ids).filter(e=>!isConnector(e));
 if(chosen.length<2||!canEdit(chosen))return false;
 const blocks=units(chosen,chosen.map(e=>e.id)).filter(u=>u.members.length);
 if(blocks.length<2)return false;
 if(!['horizontal','vertical','grid'].includes(mode))return false;
 const ordered=[...blocks].sort((a,b)=>mode==='vertical'?a.y-b.y||a.x-b.x:a.x-b.x||a.y-b.y);
 const n=ordered.length,cols=mode==='vertical'?1:mode==='horizontal'?n:Math.min(3,Math.ceil(Math.sqrt(n))),rows=Math.ceil(n/cols);
 const margin=48,gap=22,availableW=canvas.w-2*margin,availableH=canvas.h-2*margin;
 const cellW=(availableW-gap*(cols-1))/cols,cellH=(availableH-gap*(rows-1))/rows;
 if(cellW<=1||cellH<=1)return false;
 for(let i=0;i<n;i++){
  const u=ordered[i],col=i%cols,row=Math.floor(i/cols);
  const factor=Math.min(1,(cellW-18)/Math.max(1,u.w),(cellH-18)/Math.max(1,u.h));
  const width=u.w*factor,height=u.h*factor;
  const targetX=margin+col*(cellW+gap)+(cellW-width)/2,targetY=margin+row*(cellH+gap)+(cellH-height)/2;
  for(const e of u.members){e.x=Math.round((targetX+(e.x-u.x)*factor)*10)/10;e.y=Math.round((targetY+(e.y-u.y)*factor)*10)/10;e.w=Math.round(e.w*factor*10)/10;e.h=Math.round(e.h*factor*10)/10;}
 }
 return true;
}
// Snap the dragged selection against slide centers/edges and unrelated objects.
export function snapMove(elements,ids,proposed,canvas={w:960,h:540},threshold=7){
 const selected=new Set(picked(elements,ids).map(e=>e.id));
 const others=elements.filter(e=>!selected.has(e.id)&&!isConnector(e));
 const candidatesX=[{value:canvas.w/2,source:'슬라이드 중앙'},{value:48,source:'안전 여백'},{value:canvas.w-48,source:'안전 여백'}];
 const candidatesY=[{value:canvas.h/2,source:'슬라이드 중앙'},{value:48,source:'안전 여백'},{value:canvas.h-48,source:'안전 여백'}];
 for(const e of others){for(const x of [e.x,e.x+e.w/2,e.x+e.w])candidatesX.push({value:x,source:'개체'});for(const y of [e.y,e.y+e.h/2,e.y+e.h])candidatesY.push({value:y,source:'개체'})}
 const choose=(candidate,refs)=>{let best=null;for(const edge of candidate)for(const ref of refs){const delta=ref.value-edge;if(Math.abs(delta)<=threshold&&(!best||Math.abs(delta)<Math.abs(best.delta)))best={delta,value:ref.value,source:ref.source}}return best};
 const x=choose([proposed.x,proposed.x+proposed.w/2,proposed.x+proposed.w],candidatesX);
 const y=choose([proposed.y,proposed.y+proposed.h/2,proposed.y+proposed.h],candidatesY);
 return {dx:x?.delta||0,dy:y?.delta||0,guides:[...(x?[{axis:'x',value:x.value,source:x.source}]:[]),...(y?[{axis:'y',value:y.value,source:y.source}]:[])]};
}
