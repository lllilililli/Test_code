// Aster Deck text layout contract. Logical slide pixels use CSS's 96 px/in;
// DrawingML sz is expressed in 1/100 point (72 pt/in), geometry in EMU.
// Do not store PPTX font points in the internal Aster pixel document model.
export const FONT_POINTS_PER_PIXEL = 72 / 96;
export const EMU_PER_PIXEL = 914400 / 96;
export const pxToPptFontSize = px => Math.max(100, Math.round(Number(px || 24) * FONT_POINTS_PER_PIXEL * 100));
export const pptFontSizeToPx = hundredths => Number(hundredths || 1800) / (100 * FONT_POINTS_PER_PIXEL);
export const pxToEmu = px => Math.round(Number(px || 0) * EMU_PER_PIXEL);
export const emuToPx = value => Number(value || 0) / EMU_PER_PIXEL;
export function textLayout(e) {
 const text = e.type === 'text';
 const fallbackX = text ? 4 : 0;
 const fallbackY = text ? 2 : 0;
 return {
  marginX: Math.max(0, Number.isFinite(Number(e.textMarginX)) && e.textMarginX != null ? Number(e.textMarginX) : fallbackX),
  marginY: Math.max(0, Number.isFinite(Number(e.textMarginY)) && e.textMarginY != null ? Number(e.textMarginY) : fallbackY),
  lineSpacing: Math.max(0.8, Math.min(3, Number(e.lineSpacing) || 1.2)),
  verticalAlign: ['top','middle','bottom'].includes(e.verticalAlign) ? e.verticalAlign : text ? 'top' : 'middle',
  autoFit: ['none','shrink','resize'].includes(e.textAutoFit) ? e.textAutoFit : 'none',
 };
}
