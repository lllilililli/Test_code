// Aster Deck motion model. Clean-room implementation, independent of UI.
// Aster timelines use normalized controls; supported effects are also serialized to PresentationML.
export const EFFECTS={none:'없음',fade:'페이드',fly:'날아오기',zoom:'확대',wipe:'드러나기',spin:'회전',pulse:'강조 확대',shake:'흔들기',path:'모션 경로'};
export const KINDS={entrance:'등장',emphasis:'강조',exit:'퇴장'};
export const TRIGGERS={click:'클릭',with:'이전과 함께',after:'이전 다음'};
export const EASINGS={ease:'부드럽게',linear:'일정하게','ease-in':'서서히 가속','ease-out':'서서히 감속','ease-in-out':'가속·감속'};
export const DIRECTIONS={left:'왼쪽',right:'오른쪽',up:'위',down:'아래'};
let seq=0;
export function stepId(){return `motion_${Date.now().toString(36)}_${++seq}`}
export function newStep(elementId,effect='fade',kind='entrance'){
 return {id:stepId(),elementId,effect,kind,trigger:'click',duration:.65,delay:0,easing:'ease-out',direction:'right',pathType:'line',pathDx:180,pathDy:0,pathCurve:-55};
}
export function legacySteps(slide){return (slide.elements||[]).filter(e=>e.animation?.effect&&e.animation.effect!=='none').map(e=>({id:'legacy_'+e.id,elementId:e.id,effect:e.animation.effect,kind:'entrance',trigger:e.animation.trigger||'click',duration:Number(e.animation.duration)||.65,delay:Number(e.animation.delay)||0,easing:'ease-out',direction:'right'}));}
export function readSteps(slide){return Array.isArray(slide.timeline)?slide.timeline:legacySteps(slide);}
export function ensureTimeline(slide){if(!Array.isArray(slide.timeline))slide.timeline=legacySteps(slide);return slide.timeline;}
export function appendStep(slide,step){ensureTimeline(slide).push({...newStep(step.elementId,step.effect,step.kind),...step});return slide.timeline.at(-1)}
export function removeStep(slide,id){ensureTimeline(slide);slide.timeline=slide.timeline.filter(x=>x.id!==id);}
export function moveStep(slide,id,delta){const rows=ensureTimeline(slide),i=rows.findIndex(x=>x.id===id),to=i+delta;if(i<0||to<0||to>=rows.length)return false;[rows[i],rows[to]]=[rows[to],rows[i]];return true;}
export function moveStepTo(slide,id,targetId){const rows=ensureTimeline(slide),i=rows.findIndex(x=>x.id===id),j=rows.findIndex(x=>x.id===targetId);if(i<0||j<0||i===j)return false;const [item]=rows.splice(i,1);rows.splice(j,0,item);return true;}
export function cleanTimeline(slide){if(!Array.isArray(slide.timeline))return;const ids=new Set((slide.elements||[]).map(x=>x.id));slide.timeline=slide.timeline.filter(x=>ids.has(x.elementId));}
export function copyTimeline(slide,idMap){if(!Array.isArray(slide.timeline))return;slide.timeline=slide.timeline.map(x=>({...x,id:stepId(),elementId:idMap.get(x.elementId)||x.elementId}));}
export function schedule(slide){
 const ids=new Set((slide.elements||[]).map(x=>x.id)),raw=readSteps(slide).filter(x=>ids.has(x.elementId)&&x.effect!=='none');
 let cue=0,previous=null;
 const events=raw.map((x,i)=>{
  const trigger=TRIGGERS[x.trigger]?x.trigger:'click';
  if(trigger==='click')cue++;
  // For the first With/After item, cue 0 begins automatically on slide entry.
  const duration=Math.max(.08,Math.min(15,Number(x.duration)||.65));
  const delay=Math.max(0,Math.min(15,Number(x.delay)||0));
  const base=trigger==='after'&&previous&&previous.cue===cue?previous.end:trigger==='with'&&previous&&previous.cue===cue?previous.start:0;
  const start=base+delay;
  const event={...x,cue,order:i+1,start,end:start+duration,duration,delay,kind:KINDS[x.kind]?x.kind:'entrance',easing:EASINGS[x.easing]?x.easing:'ease-out',direction:DIRECTIONS[x.direction]?x.direction:'right'};
  previous=event;return event;
 });
 return {events,cues:cue,seconds:Math.max(0,...events.map(x=>x.end))};
}
export function stateAt(slide,cue){
 const result=new Map();for(const x of slide.elements||[])result.set(x.id,true);
 const events=schedule(slide).events;
 for(const x of events){if(x.kind==='entrance'&&!events.some(other=>other.elementId===x.elementId&&other.kind==='entrance'&&other.cue<x.cue))result.set(x.elementId,false);}
 for(const x of events){if(x.cue>cue)continue;if(x.kind==='entrance')result.set(x.elementId,true);if(x.kind==='exit')result.set(x.elementId,false);}
 return result;
}
// Motion coordinates are offsets from the center of the target, expressed in slide pixels.
export function pathPoint(step,t){
 const x=Number(step.pathDx??180),y=Number(step.pathDy??0),bend=step.pathType==='curve'?Number(step.pathCurve??-55):0;
 return {x:x*t,y:y*t+4*(1-t)*t*bend};
}
export function motionPathFrames(step,segments=32){
 return Array.from({length:segments+1},(_,i)=>{
  const t=i/segments,p=pathPoint(step,t);
  return {offset:t,transform:`translate(${p.x.toFixed(3)}px,${p.y.toFixed(3)}px)`};
 });
}
export function visualSchedule(slide){
 const rows=schedule(slide).events;
 let cursor=0,prevCue=null,cueFinish=0;
 const events=rows.map(row=>{
  if(prevCue!==null&&row.cue!==prevCue){cursor=cueFinish+.3;cueFinish=cursor;}
  prevCue=row.cue;
  const start=cursor+row.start,end=start+row.duration;
  cueFinish=Math.max(cueFinish,end);
  return {...row,visualStart:start,visualEnd:end};
 });
 return {events,seconds:Math.max(1,cueFinish)};
}
export function keyframes(x){
 const side={left:['-45px','0px'],right:['45px','0px'],up:['0px','-45px'],down:['0px','45px']}[x.direction]||['45px','0px'];
 const shift=x.direction==='left'?'translateX(-45px)':x.direction==='right'?'translateX(45px)':x.direction==='up'?'translateY(-45px)':'translateY(45px)';
 const start=x.kind==='exit'?1:0,end=x.kind==='exit'?0:1;
 switch(x.effect){
  case 'path':return motionPathFrames(x);
  case 'fade':return [{opacity:start},{opacity:end}];
  case 'fly':return x.kind==='exit'?[{opacity:1,transform:'translate(0,0)'},{opacity:0,transform:shift}]:[{opacity:0,transform:shift},{opacity:1,transform:'translate(0,0)'}];
  case 'zoom':return x.kind==='exit'?[{opacity:1,transform:'scale(1)'},{opacity:0,transform:'scale(.35)'}]:[{opacity:0,transform:'scale(.35)'},{opacity:1,transform:'scale(1)'}];
  case 'wipe':return x.kind==='exit'?[{clipPath:'inset(0 0 0 0)',opacity:1},{clipPath:'inset(0 100% 0 0)',opacity:0}]:[{clipPath:'inset(0 100% 0 0)',opacity:0},{clipPath:'inset(0 0 0 0)',opacity:1}];
  case 'spin':return x.kind==='exit'?[{opacity:1,transform:'rotate(0)'},{opacity:0,transform:'rotate(90deg)'}]:[{opacity:0,transform:'rotate(-90deg)'},{opacity:1,transform:'rotate(0)'}];
  case 'pulse':return [{transform:'scale(1)'},{transform:'scale(1.12)'},{transform:'scale(1)'}];
  case 'shake':return [{transform:'translateX(0)'},{transform:'translateX(-10px)'},{transform:'translateX(10px)'},{transform:'translateX(-7px)'},{transform:'translateX(7px)'},{transform:'translateX(0)'}];
  default:return [{opacity:start},{opacity:end}];
 }
}
