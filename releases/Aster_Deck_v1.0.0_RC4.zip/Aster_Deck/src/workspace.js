// Aster Deck workspace behavior. No third-party source or private Office implementation.
export const PREFS_KEY='aster.workspace.preferences.v096';
export const RECOVERY_KEY='aster.workspace.recovery.v096';
const safeParse=(raw,fallback)=>{try{return JSON.parse(raw)??fallback}catch{return fallback}};
export function normalizePrefs(p={}){
 return {slidesCollapsed:p.slidesCollapsed===true,theme:p.theme==='dark'?'dark':'light',leftWidth:Math.max(154,Math.min(350,Number(p.leftWidth)||222)),rightWidth:Math.max(235,Math.min(425,Number(p.rightWidth)||292)),recoveryEnabled:p.recoveryEnabled!==false};
}
export function loadPrefs(storage){try{return normalizePrefs(safeParse(storage.getItem(PREFS_KEY),{}))}catch{return normalizePrefs()}}
export function savePrefs(storage,prefs){try{storage.setItem(PREFS_KEY,JSON.stringify(normalizePrefs(prefs)));return true}catch{return false}}
export function thumbnailRange(total,top,height,rowHeight=121,margin=7){
 const count=Math.max(0,Math.floor(total)),row=Math.max(1,rowHeight),start=Math.max(0,Math.floor(Math.max(0,top)/row)-margin);
 const end=Math.min(count,Math.ceil((Math.max(0,top)+Math.max(0,height))/row)+margin);
 return {start,end};
}
export function createRecovery(storage,{key=RECOVERY_KEY,maxItems=3,maxBytes=2_500_000,now=()=>Date.now()}={}){
 const readAll=()=>{try{const data=safeParse(storage.getItem(key),[]);return Array.isArray(data)?data.filter(x=>x&&typeof x.id==='string'&&typeof x.body==='string'):[]}catch{return []}};
 const list=()=>readAll().map(({id,title,savedAt,bytes,slideCount})=>({id,title,savedAt,bytes,slideCount})).sort((a,b)=>b.savedAt-a.savedAt);
 const write=(deck)=>{
  if(!deck||deck.format!=='aster-deck'||!Array.isArray(deck.slides)||!deck.slides.length)return {ok:false,reason:'invalid'};
  let body;try{body=JSON.stringify(deck)}catch{return {ok:false,reason:'invalid'}};
  const bytes=new TextEncoder().encode(body).length;
  if(bytes>maxBytes)return {ok:false,reason:'too-large',bytes};
  const savedAt=now();const existing=readAll();let seq=0;while(existing.some(x=>x.id===`recovery-${savedAt}-${seq}`))seq++;const id=`recovery-${savedAt}-${seq}`;
  const item={id,title:String(deck.title||'제목 없는 문서').slice(0,160),slideCount:deck.slides.length,savedAt,bytes,body};
  const items=[item,...existing].slice(0,Math.max(1,maxItems));
  // Storage quota fallback: retain at least the newest recovery if possible.
  for(let n=items.length;n>=1;n--){try{storage.setItem(key,JSON.stringify(items.slice(0,n)));return {ok:true,id,bytes,retained:n}}catch{}}
  return {ok:false,reason:'storage',bytes};
 };
 const read=id=>{const item=readAll().find(x=>x.id===id);if(!item)return null;const deck=safeParse(item.body,null);return deck?.format==='aster-deck'&&Array.isArray(deck.slides)?deck:null};
 const remove=id=>{try{storage.setItem(key,JSON.stringify(readAll().filter(x=>x.id!==id)));return true}catch{return false}};
 const clear=()=>{try{storage.removeItem(key);return true}catch{return false}};
 return {write,list,read,remove,clear};
}
export function matchCommands(commands,q){
 const needle=String(q||'').trim().toLocaleLowerCase();
 const results=commands.filter(x=>!needle||`${x.label} ${x.id} ${x.shortcut||''}`.toLocaleLowerCase().includes(needle));
 return results.sort((a,b)=>{const aStarts=a.label.toLocaleLowerCase().startsWith(needle)?1:0,bStarts=b.label.toLocaleLowerCase().startsWith(needle)?1:0;return bStarts-aStarts||a.label.localeCompare(b.label,'ko')}).slice(0,30);
}

// Only offer actions valid for the right-click target; commands still enforce locks.
export function contextActions(kind,{items=[],slideIndex=0,slideCount=1,master=false,hasClipboard=false,hasObjects=false}={}){
 const action=(id,label,enabled=true)=>({id,label,enabled});
 if(kind==='slide')return [action('slide.add','새 슬라이드'),action('slide.duplicate','슬라이드 복제'),action('slide.up','한 칸 위로',slideIndex>0),action('slide.down','한 칸 아래로',slideIndex<slideCount-1),action('slide.delete','슬라이드 삭제',slideCount>1)];
 if(kind==='object'){
  const editable=items.length>0&&!items.some(e=>e.locked),groups=new Set(items.map(e=>e.groupId||e.id));
  return [action('edit.copy','개체 복사',items.length>0),action('object.duplicate','개체 복제',editable),action('object.delete','개체 삭제',editable),action('object.front','맨 앞으로',editable),action('object.back','맨 뒤로',editable),action('object.group','그룹화',editable&&groups.size>1),action('object.ungroup','그룹 해제',editable&&items.some(e=>e.groupId)),action('object.lock','잠금',items.some(e=>!e.locked)),action('object.unlock','잠금 해제',items.some(e=>e.locked)),action('object.properties','개체 속성')];
 }
 return [action('edit.paste','개체 붙여넣기',hasClipboard),action('insert.text','텍스트 상자'),action('insert.rect','사각형'),action('object.selectAll','모든 개체 선택',hasObjects),action('slide.add','새 슬라이드',!master),action('view.fit','화면 맞춤'),action('view.grid','격자 토글')];
}

// Export checkpoints describe requested downloads, never physical disk writes.
export function createExportTracker(initial){
 let epoch=0,sequence=0,completedSequence=0,baseline=JSON.stringify(initial),current=baseline,last=null;
 return {
  reset(deck){epoch++;baseline=current=JSON.stringify(deck);last=null},
  change(deck){current=JSON.stringify(deck)},
  capture(deck){return {epoch,sequence:++sequence,body:JSON.stringify(deck)}},
  complete(ticket,kind,at=Date.now()){
   if(ticket.epoch!==epoch||ticket.sequence<completedSequence)return false;
   completedSequence=ticket.sequence;
   baseline=ticket.body;last={kind,at};return true;
  },
  get dirty(){return current!==baseline},
  get last(){return last?{...last}:null}
 };
}
