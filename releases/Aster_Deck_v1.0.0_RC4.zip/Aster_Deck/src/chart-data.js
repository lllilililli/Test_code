// CSV / SpreadsheetML reader, implemented from public RFC4180 and ECMA-376 formats.
import {zipRead,zipText} from './zip.js';
export function parseDelimited(text, delimiter){
 const raw=String(text).replace(/^\uFEFF/,'');
 if(!delimiter){const first=raw.split(/\r?\n/,1)[0];const counts=[',','\t',';'].map(c=>[c,(first.match(new RegExp(c==='\t'?'\\t':c,'g'))||[]).length]);delimiter=counts.sort((a,b)=>b[1]-a[1])[0][0]}
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<raw.length;i++){
  const c=raw[i];if(quoted){if(c==='"'&&raw[i+1]==='"'){cell+='"';i++}else if(c==='"')quoted=false;else cell+=c}
  else if(c==='"'&&cell==='')quoted=true;
  else if(c===delimiter){row.push(cell);cell=''}
  else if(c==='\n'||c==='\r'){if(c==='\r'&&raw[i+1]==='\n')i++;row.push(cell);rows.push(row);row=[];cell=''}
  else cell+=c;
 }
 if(quoted)throw Error('CSV 따옴표가 닫히지 않았어');
 if(cell||row.length){row.push(cell);rows.push(row)}
 return rows.filter(row=>row.some(v=>v.trim()));
}
export function tableToChart(rows,labelIndex=0,valueIndex=1){
 if(labelIndex===valueIndex)throw Error('분류 열과 수치 열을 다르게 선택해 줘');
 const result=[];let skipped=0;
 for(const row of rows){const label=String(row[labelIndex]??'').trim(),str=String(row[valueIndex]??'').trim().replace(/,/g,'');const value=Number(str);
  if(!label||!str||!Number.isFinite(value)){skipped++;continue}
  result.push({label:label.slice(0,120),value});
 }
 if(!result.length)throw Error('숫자가 있는 데이터 행을 찾지 못했어');
 return {data:result.slice(0,100),skipped,limited:result.length>100};
}
const colIndex=s=>{let n=0;for(const c of s.toUpperCase())n=n*26+c.charCodeAt(0)-64;return n-1};
const descendants=(r,n)=>Array.from(r?.getElementsByTagNameNS('*',n)||[]);
const attr=(r,n)=>r?.getAttribute(n)||'';
const xmlDoc=x=>{const doc=new DOMParser().parseFromString(x,'application/xml');if(descendants(doc,'parsererror').length)throw Error('XLSX XML 오류');return doc};
export async function parseXlsx(bytes){
 const files=await zipRead(bytes),wb=zipText(files,'xl/workbook.xml');if(!wb)throw Error('유효한 XLSX가 아니야');
 const doc=xmlDoc(wb),sheet=descendants(doc,'sheet')[0];if(!sheet)throw Error('XLSX 시트가 비어 있어');
 const rid=sheet.getAttribute('r:id')||sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
 let target='worksheets/sheet1.xml';const relXml=zipText(files,'xl/_rels/workbook.xml.rels');if(relXml){for(const rel of descendants(xmlDoc(relXml),'Relationship'))if(attr(rel,'Id')===rid)target=attr(rel,'Target')}
 const name=target.startsWith('/')?target.slice(1):'xl/'+target.replace(/^\.\.\//,'');
 const sXml=zipText(files,name);if(!sXml)throw Error('XLSX 워크시트를 찾을 수 없어: '+name);
 const sharedXml=zipText(files,'xl/sharedStrings.xml');const shared=sharedXml?descendants(xmlDoc(sharedXml),'si').map(si=>descendants(si,'t').map(t=>t.textContent).join('')):[];
 const rows=[];for(const row of descendants(xmlDoc(sXml),'row')){
  const values=[];for(const cell of descendants(row,'c')){
   const ref=attr(cell,'r'),match=ref.match(/^([A-Za-z]+)/);if(!match)continue;
   const i=colIndex(match[1]);if(i<0||i>255)continue;
   const t=attr(cell,'t');let val='';if(t==='inlineStr')val=descendants(cell,'t').map(n=>n.textContent).join('');else{val=descendants(cell,'v')[0]?.textContent||'';if(t==='s')val=shared[Number(val)]??'';}
   values[i]=val;
  }if(values.some(v=>String(v??'').trim()))rows.push(Array.from({length:Math.min(values.length,50)},(_,i)=>values[i]??''));
 }
 return {rows,sheetName:attr(sheet,'name')||'Sheet1'};
}
export function chartCsv(rows){const q=s=>'"'+String(s).replace(/^([=+@]|-(?![0-9]))/,"'$1").replace(/"/g,'""')+'"';return '\uFEFF항목,값\r\n'+rows.map(d=>`${q(d.label)},${Number(d.value)}`).join('\r\n')+'\r\n'};

// Multi-series table mapping, with empty cells retained as null so chart gaps stay gaps.
export function tableToMultiChart(rows,labelIndex=0,valueIndices=[1],names=[]){
 const indices=[...new Set(valueIndices.map(Number))].filter(n=>Number.isInteger(n)&&n>=0&&n!==labelIndex).slice(0,12);
 if(!indices.length)throw Error('수치 열을 한 개 이상 선택해야 해');
 const categories=[],columns=indices.map(()=>[]);let skipped=0;
 for(const row of rows){const label=String(row[labelIndex]??'').trim();if(!label){skipped++;continue}
  const vals=indices.map(index=>{const v=String(row[index]??'').trim().replace(/,/g,'');return v===''||!Number.isFinite(Number(v))?null:Number(v)});
  if(vals.every(v=>v===null)){skipped++;continue}
  categories.push(label.slice(0,120));vals.forEach((v,i)=>columns[i].push(v));
 }
 if(!categories.length)throw Error('숫자가 있는 데이터 행을 찾지 못했어');
 const limited=categories.length>100;
 const chartData=categories.slice(0,100).map((label,i)=>({label,value:columns[0][i]}));
 const chartSeries=indices.map((col,i)=>({name:String(names[col]||`계열 ${i+1}`).slice(0,80),values:columns[i].slice(0,100)}));
 return {chartData,chartSeries,skipped,limited};
}
export function chartTable(e){
 const cats=(e.chartData||[]).map(r=>r.label);
 const series=e.chartSeries?.length?e.chartSeries:[{name:'값',values:(e.chartData||[]).map(r=>r.value)}];
 return [[ '항목',...series.map(s=>s.name)],...cats.map((label,i)=>[label,...series.map(s=>s.values?.[i]??'')])];
}
export function chartCsvMulti(e){const q=v=>'"'+String(v??'').replace(/^([=+@]|-(?![0-9]))/,"'$1").replace(/"/g,'""')+'"';return '\uFEFF'+chartTable(e).map((row,i)=>row.map((v,j)=>i>0&&j>0&&typeof v==='number'?String(v):q(v)).join(',')).join('\r\n')+'\r\n';}
