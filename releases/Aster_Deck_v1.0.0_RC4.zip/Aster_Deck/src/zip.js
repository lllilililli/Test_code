// Independently implemented minimal ZIP reader/writer from published APPNOTE structure.
const enc=new TextEncoder(),dec=new TextDecoder();
export const u8=s=>enc.encode(s);
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let j=0;j<8;j++)c=(c>>>1)^(c&1?0xedb88320:0)}return(c^0xffffffff)>>>0}
const U16=(v,n,x)=>v.setUint16(n,x,true),U32=(v,n,x)=>v.setUint32(n,x>>>0,true);
function concat(parts){let total=parts.reduce((n,b)=>n+b.length,0),o=new Uint8Array(total),p=0;for(const a of parts){o.set(a,p);p+=a.length}return o}
export function zipWrite(entries){const chunks=[],central=[];let offset=0;for(const [name,value] of Object.entries(entries)){const nb=u8(name),data=typeof value==='string'?u8(value):value,crc=crc32(data),lh=new Uint8Array(30+nb.length),l=new DataView(lh.buffer);U32(l,0,0x04034b50);U16(l,4,20);U16(l,6,0x800);U16(l,8,0);U32(l,14,crc);U32(l,18,data.length);U32(l,22,data.length);U16(l,26,nb.length);lh.set(nb,30);chunks.push(lh,data);
 const ch=new Uint8Array(46+nb.length),c=new DataView(ch.buffer);U32(c,0,0x02014b50);U16(c,4,20);U16(c,6,20);U16(c,8,0x800);U16(c,10,0);U32(c,16,crc);U32(c,20,data.length);U32(c,24,data.length);U16(c,28,nb.length);U32(c,42,offset);ch.set(nb,46);central.push(ch);offset+=lh.length+data.length;}
 const cd=concat(central),end=new Uint8Array(22),v=new DataView(end.buffer);U32(v,0,0x06054b50);U16(v,8,central.length);U16(v,10,central.length);U32(v,12,cd.length);U32(v,16,offset);return concat([...chunks,cd,end]);}
// Release-candidate safety budgets. These constrain untrusted PPTX/ZIP uploads, not export sizes.
export const ZIP_LIMITS=Object.freeze({maxArchive:300*1024*1024,maxEntry:64*1024*1024,maxTotal:256*1024*1024,maxEntries:10000});
export async function zipRead(buffer){
 const bytes=buffer instanceof Uint8Array?buffer:new Uint8Array(buffer);
 if(bytes.length>ZIP_LIMITS.maxArchive)throw Error('ZIP 파일이 300MB 제한을 초과했어.');
 if(bytes.length<22)throw Error('ZIP 파일이 잘렸어.');
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
 let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)
  if(v.getUint32(i,true)===0x06054b50 && i+22+v.getUint16(i+20,true)===bytes.length){end=i;break}
 if(end<0)throw Error('ZIP 끝 표시를 찾지 못했어.');
 const count=v.getUint16(end+10,true),cdSize=v.getUint32(end+12,true),cdOffset=v.getUint32(end+16,true);
 if(count===0xffff || cdOffset===0xffffffff || cdSize===0xffffffff)throw Error('ZIP64 형식은 아직 지원하지 않아.');
 if(count>ZIP_LIMITS.maxEntries)throw Error('ZIP 파일 항목 수 제한을 초과했어.');
 if(v.getUint16(end+8,true)!==count || v.getUint16(end+4,true)!==0 || v.getUint16(end+6,true)!==0)throw Error('분할 ZIP은 지원하지 않아.');
 if(cdOffset+cdSize>end)throw Error('ZIP 중앙 디렉터리 범위 오류');
 const out=Object.create(null);let pos=cdOffset,total=0;
 for(let i=0;i<count;i++){
  if(pos+46>end || v.getUint32(pos,true)!==0x02014b50)throw Error('ZIP 중앙 디렉터리 오류');
  const flags=v.getUint16(pos+8,true),method=v.getUint16(pos+10,true),crc=v.getUint32(pos+16,true);
  const size=v.getUint32(pos+20,true),expanded=v.getUint32(pos+24,true);
  const n=v.getUint16(pos+28,true),e=v.getUint16(pos+30,true),c=v.getUint16(pos+32,true),off=v.getUint32(pos+42,true);
  if(size===0xffffffff||expanded===0xffffffff||off===0xffffffff)throw Error('ZIP64 항목은 아직 지원하지 않아.');
  if(pos+46+n+e+c>cdOffset+cdSize)throw Error('ZIP 파일 이름/추가 데이터가 잘렸어.');
  if(flags&1)throw Error('암호화된 PPTX는 지원하지 않아.');
  if(![0,8].includes(method))throw Error('지원하지 않는 ZIP 압축 방식 '+method);
  if(expanded>ZIP_LIMITS.maxEntry || total+expanded>ZIP_LIMITS.maxTotal)throw Error('압축 해제 데이터 크기가 안전 제한을 초과했어.');
  total+=expanded;
  const name=dec.decode(bytes.subarray(pos+46,pos+46+n));
  if(!name||name.startsWith('/')||name.includes('\\')||name.split('/').includes('..')||Object.hasOwn(out,name))throw Error('ZIP 항목 이름이 올바르지 않아.');
  if(off+30>cdOffset||v.getUint32(off,true)!==0x04034b50)throw Error('ZIP 로컬 헤더 오류');
  const ln=v.getUint16(off+26,true),le=v.getUint16(off+28,true),start=off+30+ln+le;
  if(start+size>cdOffset)throw Error('ZIP 압축 데이터가 잘렸어.');
  let dat=bytes.slice(start,start+size);
  if(method===8){
   if(typeof DecompressionStream==='undefined')throw Error('압축된 PPTX를 읽을 수 없는 브라우저야.');
   try{
    const ds=new DecompressionStream('deflate-raw');
    const reader=new Blob([dat]).stream().pipeThrough(ds).getReader();
    const chunks=[];let produced=0;
    for(;;){const {done,value}=await reader.read();if(done)break;
     produced+=value.length;
     if(produced>expanded || produced>ZIP_LIMITS.maxEntry){await reader.cancel();throw Error('ZIP 압축 해제 크기가 선언값을 초과했어.');}
     chunks.push(value);
    }
    dat=new Uint8Array(produced);let at=0;for(const chunk of chunks){dat.set(chunk,at);at+=chunk.length}
   }catch(error){if(error.message.includes('초과'))throw error;throw Error('ZIP 압축 데이터가 손상되었어.');}
  }
  if(dat.length!==expanded)throw Error('ZIP 압축 해제 크기가 일치하지 않아: '+name);
  if(crc32(dat)!==crc)throw Error('ZIP CRC 무결성 검사에 실패했어: '+name);
  out[name]=dat;pos+=46+n+e+c;
 }
 if(pos!==cdOffset+cdSize)throw Error('ZIP 중앙 디렉터리 크기 오류');
 return out;
}
export const zipText=(entries,name)=>entries[name]?dec.decode(entries[name]):'';
