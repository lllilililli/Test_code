// Aster Deck document model. Independent implementation; all coordinates in 960×540 slide pixels.
export const VERSION='1.0.0-rc1';
export const W=960,H=540;
let serial=0;
export const uid=()=>('ad_'+Date.now().toString(36)+'_'+(++serial).toString(36));
export const clone=x=>structuredClone(x);
export const normalizeDeck=d=>{if(!d.master)d.master={background:'#ffffff',useBackground:false,elements:[]};for(const s of d.slides||[]){if(!s.transition)s.transition='none';}return d};
export const makeSlide=(name='새 슬라이드')=>({id:uid(),name,background:'#ffffff',notes:'',transition:'none',transitionDuration:0.55,hideMaster:false,elements:[],timeline:[]});
export const makeDeck=()=>({format:'aster-deck',version:3,title:'제목 없는 프레젠테이션',master:{background:'#ffffff',useBackground:false,elements:[]},slides:[makeSlide('슬라이드 1')]});
const fonts={title:44,body:26};
export function shape(type,x=115,y=110){
 const text=type==='text';const line=type==='line';
 return {id:uid(),type,x,y,w:text?470:line?240:200,h:text?96:line?4:120,text:text?'더블클릭하여 입력하세요':'',fontSize:text?32:23,fontFamily:'Arial',lineSpacing:1.2,textMarginX:text?4:0,textMarginY:text?2:0,verticalAlign:text?'top':'middle',textAutoFit:'none',color:'#243045',fill:text||line?'transparent':'#5583e7',stroke:line?'#334155':'transparent',strokeWidth:line?4:0,bold:false,italic:false,align:text?'left':'center',opacity:1,rotation:0,radius:type==='rounded'?22:0,src:'',shadow:false,animation:{effect:'none',trigger:'click',delay:0,duration:0.65}};
}
function addElem(s,type,x,y,w,h,opts={}){const e=shape(type,x,y);e.w=w;e.h=h;Object.assign(e,opts);s.elements.push(e);return e}
export function makeDemoDeck(){
 const d=makeDeck();d.title='Northern Lights · 오로라 이야기';d.slides=[];
 let s=makeSlide('표지 · 밤하늘의 빛');s.background='#132640';
 addElem(s,'ellipse',654,-124,450,450,{fill:'#284d7b',opacity:.43});addElem(s,'ellipse',746,80,240,240,{fill:'#4c819c',opacity:.23});
 addElem(s,'rect',70,74,60,7,{fill:'#f79f55'});
 addElem(s,'text',70,111,730,78,{text:'NORTHERN LIGHTS',fontSize:58,color:'#ffffff',bold:true});
 addElem(s,'text',71,201,660,112,{text:'하늘을 물들이는\n빛의 여정',fontSize:42,color:'#e3efff',bold:true});
 addElem(s,'text',74,361,670,48,{text:'태양에서 지구까지, 오로라가 만들어지는 과학',fontSize:22,color:'#b8c9e0'});
 addElem(s,'rect',0,513,960,27,{fill:'#3173c4'});addElem(s,'rect',280,513,320,27,{fill:'#8667d7'});addElem(s,'rect',600,513,360,27,{fill:'#f28952'});
 s.notes='발표 소개: 아름다운 오로라가 어떤 과정을 거쳐 만들어지는지 이야기합니다.';d.slides.push(s);
 s=makeSlide('목차 · 오늘 살펴볼 것');
 addElem(s,'text',68,52,780,68,{text:'오늘 살펴볼 내용',fontSize:42,color:'#16243a',bold:true});
 addElem(s,'text',69,121,780,30,{text:'A little science behind the magic',fontSize:20,color:'#8090a7'});
 const cards=[['01','태양풍','태양에서 출발하는 입자','#fff0e5','#ec7c30'],['02','자기장','지구를 지키는 보이지 않는 힘','#eaf1ff','#3875cf'],['03','빛의 충돌','하늘에서 시작되는 발광','#f3eaff','#9063d5']];
 cards.forEach((c,i)=>{let x=70+i*299;addElem(s,'rounded',x,207,265,220,{fill:c[3],radius:22});addElem(s,'text',x+23,227,90,45,{text:c[0],fontSize:31,color:c[4],bold:true});addElem(s,'text',x+23,293,230,44,{text:c[1],fontSize:29,color:'#1e2e48',bold:true});addElem(s,'text',x+23,350,215,60,{text:c[2],fontSize:18,color:'#60718a'});});d.slides.push(s);
 s=makeSlide('과정 · 태양에서 하늘까지');
 addElem(s,'text',66,55,840,62,{text:'From the Sun to your sky',fontSize:44,color:'#101a28'});
 const boxes=[{x:63,w:194,fill:'#ef7425',label:'Solar wind'},{x:289,w:194,fill:'#3175d5',label:'Magnetosphere'},{x:515,w:194,fill:'#9061d6',label:'Particles collide'}];
 boxes.forEach((b,i)=>{addElem(s,'rounded',b.x,213,b.w,116,{fill:b.fill,radius:23,shadow:true,text:b.label,color:'#fff',bold:true,fontSize:i===1?18:19});if(i<boxes.length-1)addElem(s,'arrow',b.x+196,253,34,36,{fill:'#253248'});});
 addElem(s,'arrow',710,253,35,36,{fill:'#253248'});
 addElem(s,'star',746,211,156,130,{fill:'#22a679',text:'LIGHT!',color:'#ffffff',fontSize:18,bold:true,shadow:true});
 addElem(s,'text',100,406,765,52,{text:'Oxygen glows green and red; nitrogen adds blue and purple fringes.',fontSize:21,color:'#27313f',italic:true,align:'center'});
 s.notes='태양에서 나온 하전 입자가 지구 자기장과 상호작용하고 대기 중 분자를 들뜨게 만들어 빛이 납니다.';d.slides.push(s);
 s=makeSlide('데이터 · 오로라의 색');s.background='#f8fafc';
 addElem(s,'text',66,52,860,64,{text:'왜 색깔이 다를까요?',fontSize:41,color:'#152439',bold:true});
 addElem(s,'text',68,118,800,30,{text:'다른 기체와 고도에서 서로 다른 빛이 만들어져요.',fontSize:19,color:'#64748b'});
 const colorCards=[['산소','초록색','#2caf85','가장 흔히 관찰되는 색'],['산소','붉은색','#df6575','높은 고도에서 나타남'],['질소','파랑·보라','#7863dd','빠른 입자와 만나 발광']];
 colorCards.forEach((c,i)=>{let x=69+i*300;addElem(s,'rounded',x,200,265,229,{fill:'#ffffff',radius:20,shadow:true});addElem(s,'ellipse',x+22,228,67,67,{fill:c[2]});addElem(s,'text',x+106,229,140,30,{text:c[0],fontSize:17,color:'#72819a'});addElem(s,'text',x+105,262,146,35,{text:c[1],fontSize:25,bold:true,color:'#152438'});addElem(s,'text',x+23,340,225,60,{text:c[3],fontSize:17,color:'#6c7c91'});});d.slides.push(s);
 s=makeSlide('마무리 · 감사합니다');s.background='#132640';
 addElem(s,'ellipse',700,-100,350,350,{fill:'#245480',opacity:.45});addElem(s,'rect',76,92,56,7,{fill:'#ed9662'});
 addElem(s,'text',72,155,810,100,{text:'THANK YOU',fontSize:73,color:'#ffffff',bold:true});
 addElem(s,'text',75,285,760,80,{text:'다음 밤하늘을 올려다볼 때,\n조금 다른 빛이 보일 거예요.',fontSize:29,color:'#ccdeef'});
 addElem(s,'rect',0,523,960,17,{fill:'#35a18c'});d.slides.push(s);
 return d;
}
export function validate(d){if(!d||d.format!=='aster-deck'||!Array.isArray(d.slides)||!d.slides.length)throw Error('지원하지 않는 문서입니다.');for(const s of [...d.slides,...(d.master?[d.master]:[])]){if(!Array.isArray(s.elements))throw Error('슬라이드 요소 형식 오류');for(const e of s.elements){if(!['text','rect','rounded','ellipse','image','star','arrow','line','chart','connector'].includes(e.type))throw Error('알 수 없는 요소 종류: '+e.type);for(const p of ['x','y','w','h'])if(!Number.isFinite(e[p]))throw Error('요소 좌표 오류');}}return d;}
export class Store{
 constructor(initial=makeDeck()){this.deck=clone(validate(normalizeDeck(clone(initial))));this.history=[];this.future=[];this.maxHistory=100;this.maxHistoryBytes=24*1024*1024;this.historyBytes=0;this.listeners=new Set()}
 subscribe(fn){this.listeners.add(fn);return()=>this.listeners.delete(fn)}
 notify(){for(const fn of this.listeners)fn(this.deck)}
 execute(fn){const before=JSON.stringify(this.deck),next=clone(this.deck);fn(next);validate(next);if(JSON.stringify(next)===before)return false;this.history.push(JSON.parse(before));this.historyBytes+=before.length;while(this.history.length>1&&(this.history.length>this.maxHistory||this.historyBytes>this.maxHistoryBytes))this.historyBytes-=JSON.stringify(this.history.shift()).length;this.deck=next;this.future=[];this.notify();return true}
 undo(){if(!this.history.length)return false;this.future.push(clone(this.deck));const past=this.history.pop();this.historyBytes-=JSON.stringify(past).length;this.deck=past;this.notify();return true}
 redo(){if(!this.future.length)return false;this.history.push(clone(this.deck));this.historyBytes+=JSON.stringify(this.deck).length;while(this.history.length>1&&(this.history.length>this.maxHistory||this.historyBytes>this.maxHistoryBytes))this.historyBytes-=JSON.stringify(this.history.shift()).length;this.deck=this.future.pop();this.notify();return true}
 load(deck){this.deck=clone(validate(normalizeDeck(clone(deck))));this.history=[];this.future=[];this.historyBytes=0;this.notify()}
}
export const effectiveBg=(deck,s)=>deck.master?.useBackground&&!s.hideMaster?deck.master.background:s.background;
export const allElements=(deck,s)=>[...(s.hideMaster?[]:deck.master?.elements||[]),...s.elements];
export function makeChart(){const e=shape('chart',170,145);e.w=600;e.h=310;e.fill='transparent';e.chartType='bar';e.chartTitle='분기별 성장';e.chartData=[{label:'1분기',value:32},{label:'2분기',value:58},{label:'3분기',value:44},{label:'4분기',value:76}];e.chartColor='#367bda';return e;}
export function addSlide(d,at=d.slides.length,layout='blank'){
 const s=makeSlide(`슬라이드 ${d.slides.length+1}`);
 if(layout==='title'){addElem(s,'text',80,157,800,100,{text:'슬라이드 제목',fontSize:54,bold:true,color:'#17263c',align:'center'});addElem(s,'text',110,274,740,56,{text:'부제목을 입력하세요',fontSize:27,color:'#718096',align:'center'})}
 if(layout==='section'){s.background='#1d3354';addElem(s,'rect',74,112,60,7,{fill:'#f39b56'});addElem(s,'text',74,182,790,100,{text:'새로운 이야기',fontSize:57,bold:true,color:'#ffffff'});addElem(s,'text',76,305,750,60,{text:'섹션 설명을 입력하세요',fontSize:25,color:'#cad7e8'})}
 if(layout==='twocol'){addElem(s,'text',62,50,830,76,{text:'슬라이드 제목',fontSize:41,bold:true});for(let i=0;i<2;i++){addElem(s,'rounded',62+i*439,159,411,300,{fill:i===0?'#eff4ff':'#f5efff',radius:20});addElem(s,'text',86+i*439,194,346,63,{text:i===0?'첫 번째 내용':'두 번째 내용',fontSize:31,bold:true});}}
 d.slides.splice(at,0,s);return s;
}
export function removeSlide(d,id){if(d.slides.length===1)return;d.slides=d.slides.filter(s=>s.id!==id)}
export function moveSlide(d,from,to){if(from<0||to<0||from>=d.slides.length||to>=d.slides.length)return;const [s]=d.slides.splice(from,1);d.slides.splice(to,0,s)}
export const byId=(d,id)=>d.slides.find(s=>s.id===id);
export function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),3000)}
export const safeFileName=n=>(n||'presentation').replace(/[\\/:*?"<>|]/g,'_');
